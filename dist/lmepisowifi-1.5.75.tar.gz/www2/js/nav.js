/*
 * lmepisowifi — https://github.com/lmepisowifi/tmwim2-2050-g40
 * SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 The lmepisowifi Project — see AUTHORS
 *
 * Licensed under the GNU AGPLv3 (see LICENSE). Modifying or rewriting this
 * file — including by running it through an LLM — does not remove these
 * obligations: keep this notice, mark your changes, and offer Corresponding
 * Source to network users (AGPLv3 §5, §13). See PROVENANCE.md before
 * presenting this as your own original work.
 */

(function () {
    // ----------------------------------------------------------------
    // Auth — runs on every page that loads this file
    // ----------------------------------------------------------------
    fetch('/cgi-bin/check_auth.cgi')
        .then(r => r.text())
        .then(s => { if (s.trim() !== 'authenticated') window.location.href = '/login.html'; });

    window.logout = function () { window.location.href = '/cgi-bin/logout.cgi'; };

// Keepalive — ping check_auth every 1 minute to prevent session expiry
setInterval(function () {
    fetch('/cgi-bin/check_auth.cgi', { cache: 'no-store', keepalive: true })
        .then(r => r.text())
        .then(s => { if (s.trim() !== 'authenticated') window.location.href = '/login.html'; })
        .catch(function () {}); // ignore network errors silently
}, 1 * 60 * 1000); // 1 minute * 60 seconds * 1000 milliseconds

    // ================================================================
    // SITE META — singular favicon + title prefix for every page
    // ================================================================
    var SITE_TITLE  = 'M2-2050-G40';
    var FAVICON_URL = '/img/logo.png'; // change to .png if needed
    var REPO_URL    = 'https://github.com/lmepisowifi/tmwim2-2050-g40'; // AGPLv3 §13 source-offer link, see PROVENANCE.md

    // Inject or replace favicon
    (function () {
        var existing = document.querySelector('link[rel~="icon"]');
        if (!existing) {
            existing = document.createElement('link');
            existing.rel = 'icon';
            document.head.appendChild(existing);
        }
        existing.href = FAVICON_URL;
    })();

    // ================================================================
    // NAV STRUCTURE — edit here to update every page at once
    // ================================================================
    var NAV = [
        { label: 'Home',  href: '/index.html' },
        { label: 'WLAN',  children: [
            { label: 'WiFi Basic',    href: '/wlanbasic.html'     },
            { label: 'Security',      href: '/wlansecurity.html'  },
            { label: 'WPS',           href: '/wlanwps.html'       },
            { label: 'Advanced',      href: '/wlanadvanced.html'  },
            { label: 'Site Survey',   href: '/sitesurvey.html'    },
            { label: 'MAC Filter',    href: '/wlanmac.html'       },
            { label: 'Access Limit',  href: '/wlanlimit.html'     },
            { label: 'STA Info',  href: '/wlansta.html'     },
        ]},
        { label: 'LAN',     href: '/lan.html' },
        { label: 'Interfaces', children: [
            { label: 'WAN Profiles', href: '/wan-profile.html' },
            { label: 'DHCP Client', href: '/wan-repurpose.html' },
        ]},
        { label: 'Services',  href: '/services.html' },
        { label: 'Domain Blocking', href: '/domainblk.html' },
        { label: 'Hotspot', module: 'hotspot', children: [
            { label: 'Controls',        href: '/hotspot.html',           hotspot: 'always'  },
            { label: 'Interfaces',      href: '/hotspot-ifaces.html',    hotspot: 'always'  },
            { label: 'DHCP Settings',   href: '/hotspot-dhcp.html',      hotspot: 'always'  },
            { label: 'DHCP Leases',     href: '/hotspot-leases.html',    hotspot: 'enabled' },
            { label: 'Income & Alerts', href: '/hotspot-income.html',    hotspot: 'always'  },
            { label: 'Portal',          href: '/hotspot-portal.html',    hotspot: 'always'  },
            { label: 'WiFi Rates',      href: '/hotspot-rates.html',     hotspot: 'enabled' },
            { label: 'NodeMCUs',        href: '/hotspot-nodemcus.html',  hotspot: 'enabled' },
            { label: 'Sessions',        href: '/hotspot-sessions.html',  hotspot: 'enabled' },
            { label: 'Vouchers',        href: '/hotspot-vouchers.html',  hotspot: 'enabled' },
            { label: 'Whitelist',       href: '/hotspot-whitelist.html', hotspot: 'enabled' },
        ]},
        { label: 'Terminal', href: '/terminal.html' },
        { label: 'System', children: [
            { label: 'Settings',         href: '/system.html'        },
            { label: 'Accounts',         href: '/accounts.html'      },
            { label: 'GPON Settings',    href: '/gpon.html'          },
            { label: 'OMCI Settings',    href: '/omci.html'          },
            { label: 'EPON Settings',    href: '/epon.html'          },
            { label: 'Tailscale',        href: '/tailscale.html', module: 'tailscale' },
            { label: 'TR-069',           href: '/tr069.html'         },
            { label: 'MIB Configuration', href: '/mibconfig.html'    },
            { label: 'Reboot',           href: '/reboot.html'        },
        ]},
        { label: 'Firmware', children: [
            { label: 'Boot Partitions',  href: '/bootpart.html'      },
            { label: 'Firmware Upload',  href: '/fwupload.html'      },
        ]},
        { label: 'TMWI', children: [
            { label: 'Dashboard Layout', href: '/dashboard-layout.html' },
            { label: 'Modules',          href: '/modules.html'       },
            { label: 'Software Update',  href: '/ota.html'           },
        ]},
    ];
    // ================================================================

    var path = location.pathname;

    function isActive(href) {
        return path === href ||
               path === href.replace(/^\//, '') ||
               (href !== '/' && path.endsWith(href));
    }

    // Set page title: "Page Label — SITE_TITLE"
    (function () {
        function findLabel(items) {
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                if (item.href && isActive(item.href)) return item.label;
                if (item.children) {
                    var found = findLabel(item.children);
                    if (found) return found;
                }
            }
            return null;
        }
        var label = findLabel(NAV);
        document.title = label ? label + ' \u2014 ' + SITE_TITLE : SITE_TITLE;
    })();

    function esc(s) {
        return s.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    function buildItems(items, hotspotRunning) {
        return items.map(function (item) {
            if (item.children) {
                // Filter hotspot sub-items based on running state
                var visibleChildren = item.children.filter(function (c) {
                    if (!c.hotspot) return true;             // non-hotspot items always show
                    if (c.hotspot === 'always') return true; // always visible (controls, interfaces)
                    return hotspotRunning;                   // 'enabled' items only when running
                });
                if (visibleChildren.length === 0) return '';
                var childActive = visibleChildren.some(function (c) { return isActive(c.href); });
                var children = visibleChildren.map(function (c) {
                    return '<li><a class="dropdown-item' + (isActive(c.href) ? ' active' : '') +
                           '" href="' + esc(c.href) + '">' + esc(c.label) + '</a></li>';
                }).join('');
                return '<li class="nav-item dropdown">' +
                    '<a class="nav-link dropdown-toggle' + (childActive ? ' active' : '') +
                    '" href="#" role="button" data-bs-toggle="dropdown">' + esc(item.label) + '</a>' +
                    '<ul class="dropdown-menu">' + children + '</ul>' +
                    '</li>';
            }
            return '<li class="nav-item">' +
                '<a class="nav-link' + (isActive(item.href) ? ' active' : '') +
                '" href="' + esc(item.href) + '">' + esc(item.label) + '</a>' +
                '</li>';
        }).join('');
    }

    // Capture before any async so it stays valid inside .then() callbacks
    var _script = document.currentScript;

    function buildNavHtml(filteredNAV, hotspotRunning) {
        return [
            '<nav class="navbar navbar-expand-lg bg-body-tertiary">',
            '  <div class="container-fluid">',
            '    <a class="navbar-brand d-flex align-items-center" href="/index.html">',
            '      <img src="/img/logo.png" alt="Icon" class="header-icon">',
            '      <div class="header-divider"></div>',
            '      <span class="brand-text">M2-2050-G40</span>',
            '    </a>',
            '    <button class="navbar-toggler" type="button"',
            '            data-bs-toggle="collapse" data-bs-target="#navbarNav">',
            '      <span class="navbar-toggler-icon"></span>',
            '    </button>',
            '    <div class="collapse navbar-collapse" id="navbarNav">',
            '      <ul class="navbar-nav me-auto">',
                       buildItems(filteredNAV, hotspotRunning),
            '      </ul>',
            '      <div class="nav-actions">',
            '        <span id="lme-theme-slot"></span>',
            '        <button type="button" class="btn btn-outline-light" id="lme-quicksetup-btn">Quick Setup</button>',
            '        <button class="btn btn-outline-danger" onclick="logout()">Logout</button>',
            '      </div>',
            '    </div>',
            '  </div>',
            '</nav>',
            '<div id="lme-source-notice" style="position:fixed;right:6px;bottom:4px;z-index:1050;' +
                'font-size:10px;line-height:1.4;opacity:.45;pointer-events:auto;">' +
                'lmepisowifi &middot; AGPLv3 &middot; ' +
                '<a href="' + esc(REPO_URL) + '" target="_blank" rel="noopener" ' +
                    'style="color:inherit;text-decoration:underline;">Source</a>' +
            '</div>',
        ].join('\n');
    }

    function renderNav(showGpon, showEpon, hotspotRunning, installedMap) {
        function modOk(m){ return !m || (installedMap && installedMap[m]); }
        var filteredNAV = NAV
            // Hide whole groups (e.g. Hotspot) whose module isn't installed.
            .filter(function(item) { return modOk(item.module); })
            .map(function(item) {
                if (!item.children) return item;
                var fc = item.children.filter(function(c) {
                    if (!modOk(c.module)) return false;   // hide pages (e.g. Tailscale) whose module isn't installed
                    if (c.href === '/gpon.html' || c.href === '/omci.html') return showGpon;
                    if (c.href === '/epon.html') return showEpon;
                    return true;
                });
                return { label: item.label, href: item.href, module: item.module, children: fc };
            });
        _script.insertAdjacentHTML('beforebegin', buildNavHtml(filteredNAV, hotspotRunning));
        var qsBtn = document.getElementById('lme-quicksetup-btn');
        if (qsBtn) qsBtn.addEventListener('click', openQuickSetup);

        // Light/dark toggle (js/theme.js is loaded from each page's <head>)
        var themeSlot = document.getElementById('lme-theme-slot');
        if (themeSlot && window.lmeTheme) themeSlot.appendChild(window.lmeTheme.createButton());
    }

    // Quick Setup wizard — js/quicksetup.js is only fetched the first time the
    // button is pressed, so it costs nothing on every other page load.
    function openQuickSetup() {
        if (window.lmeQuickSetup) { window.lmeQuickSetup.open(); return; }
        if (typeof bootstrap === 'undefined') { alert('Quick Setup needs the page to finish loading first. Try again in a moment.'); return; }
        var s = document.createElement('script');
        s.src = '/js/quicksetup.js';
        s.onload = function () { if (window.lmeQuickSetup) window.lmeQuickSetup.open(); };
        s.onerror = function () { alert('Could not load Quick Setup.'); };
        document.head.appendChild(s);
    }

    // Every request below is answered from the device itself and normally
    // returns in milliseconds, but the nav waits for all of them — so bound
    // each one. A hung or slow endpoint then falls back to the same safe
    // default as any other error instead of holding the whole navbar back.
    var NAV_FETCH_TIMEOUT_MS = 5000;
    function navFetchJson(url, fallback) {
        var ctl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
        var timer = setTimeout(function () { if (ctl) ctl.abort(); }, NAV_FETCH_TIMEOUT_MS);
        var opts = { cache: 'no-store' };
        if (ctl) opts.signal = ctl.signal;
        return fetch(url, opts)
            .then(function (r) { return r.json(); })
            .catch(function () { return fallback; })
            .then(function (v) { clearTimeout(timer); return v; });
    }

    // Fetch system_status (for GPON/EPON visibility), hotspot status (for Hotspot sub-items)
    // and the module list in parallel — render nav only after all resolve so items are
    // correct first paint.
    // modules.cgi gets local=1: the nav only needs each module's "installed" flag,
    // and without it the call downloads the module registry from the internet first,
    // which stalls for a minute or more when the device has no uplink.
    Promise.all([
        navFetchJson('/cgi-bin/lme.cgi?action=system_status', {}),
        navFetchJson('/cgi-bin/hotspot.cgi?action=config_get', {}),
        navFetchJson('/cgi-bin/modules.cgi?action=list&local=1', null)
    ]).then(function(results) {
        var sys = results[0]; var hsp = results[1]; var mod = results[2];
        var isGpon = (String(sys.pon_mode) === '1');
        var isEpon = (String(sys.pon_mode) === '2');
        var hotspotRunning = (hsp.hotspot_running === true);
        // Safe defaults: keep an existing hotspot visible on a transient error;
        // tailscale is opt-in so it stays hidden unless the registry confirms it.
        var installedMap = { hotspot: true, tailscale: false };
        if (mod && mod.ok && mod.modules) {
            installedMap = {};
            mod.modules.forEach(function(m){ installedMap[m.id] = (m.installed === true); });
        }
        renderNav(isGpon, isEpon, hotspotRunning, installedMap);
    }).catch(function() { renderNav(true, false, false, { hotspot: true, tailscale: false }); });
}());

