#!/bin/sh
# ---------------------------------------------------------------------------
# lmepisowifi — https://github.com/lmepisowifi/tmwim2-2050-g40
# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2026 The lmepisowifi Project — see AUTHORS
#
# Licensed under the GNU AGPLv3 (see LICENSE). Modifying or rewriting this
# file — including by running it through an LLM — does not remove these
# obligations: keep this notice, mark your changes, and offer Corresponding
# Source to network users (AGPLv3 §5, §13). See PROVENANCE.md before
# presenting this as your own original work.
# ---------------------------------------------------------------------------

# repurposeaswan.sh — Set up an interface as a DHCP WAN + watchdog
# Usage: repurposeaswan.sh <interface> [default_route]
#
#   <interface>      required — the interface to repurpose
#   [default_route]  optional — "1" (default when omitted, for backward
#                     compatibility with older startup.sh entries that only
#                     ever passed one argument) or "0". Controls whether
#                     THIS interface receives the kernel default route +
#                     NAT masquerade once it gets a DHCP lease. Multiple
#                     interfaces can run this script concurrently (each
#                     instance is fully namespaced by $TARGET_IFACE); only
#                     the one(s) with default_route=1 touch the default
#                     route — see /tmp/repurpose_defroute_<iface>.
#
# Runs as a daemon; write PID to /tmp/repurpose_<iface>.pid.
# DHCP anti-leak (ebtables/iptables physdev) is applied immediately, before
# udhcpc ever runs, and re-asserted every tick — see _apply_dhcp_antileak.
# A background `ip monitor link` watcher reacts to br0 re-enslavement
# near-instantly, backstopped by the 15s poll below for builds where
# `ip monitor` isn't supported.
# Watchdog loop (every 15s) checks:
#   0. DHCP anti-leak rules still in place
#   0b. Interface exists at all (if not: wait quietly, don't spin)
#   1. br0 re-binding (fixes it immediately if detected)
#   2. Interface UP state
#   3. udhcpc still alive
# /tmp/repurpose_active is a shared registry (one interface name per line —
# multiple concurrently-repurposed interfaces each add their own line).
# Exits cleanly when this interface's own line is removed from that file
# (e.g. by revertwan.sh), or when the file itself is gone.

if [ -z "$1" ]; then
    echo "Usage: $0 <interface> [default_route]" >&2
    exit 1
fi

# [fix: fused interface name] Shared registry / startup.sh helpers. The
# registry used to be written inline here (and in revertwan.sh and
# wan-repurpose.cgi), which could fuse two names into one that is not a real
# interface (e.g. "eth0.5.0wlan0-vxd"); see repurpose_lib.sh.
_RP_DIR="/lmepisowifi/www2/sh"
case "$0" in */*) _RP_DIR="${0%/*}" ;; esac
if [ ! -r "$_RP_DIR/repurpose_lib.sh" ]; then
    echo "$0: $_RP_DIR/repurpose_lib.sh not found (deploy it together with this script)" >&2
    exit 1
fi
. "$_RP_DIR/repurpose_lib.sh"

TARGET_IFACE="$1"
DEFAULT_ROUTE="${2:-1}"
case "$DEFAULT_ROUTE" in 1) DEFAULT_ROUTE=1 ;; *) DEFAULT_ROUTE=0 ;; esac

# [fix: fused interface name] Only the supported interfaces may run a
# watchdog. A name that is not one — typically a fused "eth0.5.0wlan0-vxd"
# persisted in startup.sh by an earlier build — can never exist as a netdev, so
# its watchdog would just loop forever ("was UNKNOWN — brought back UP",
# "udhcpc died — restarting"). Recover whatever valid interfaces it contains,
# repair startup.sh, and stop. This runs BEFORE any pid/registry/log file is
# created under the bad name.
if ! rp_valid_iface "$TARGET_IFACE"; then
    rp_recover_invalid_iface "$TARGET_IFACE" "$DEFAULT_ROUTE" "$0"
    exit 0
fi

SCRIPT_PATH="/tmp/udhcpc_${TARGET_IFACE}.script"
STATE_FILE="/tmp/repurpose_active"
DEFROUTE_FILE="/tmp/repurpose_defroute_${TARGET_IFACE}"
PID_FILE="/tmp/repurpose_${TARGET_IFACE}.pid"
UDHCPC_PID="/var/run/udhcpc.${TARGET_IFACE}.pid"
LOG="/tmp/repurpose_${TARGET_IFACE}.log"
WATCHDOG_INTERVAL=15
SDK_STARTUP_WAIT_MAX=300   # hard cap (s) on waiting for the SDK's `startup` to finish

# ── Helper: true if TARGET_IFACE currently has its own line in STATE_FILE ────
_in_state_registry() {
    [ -f "$STATE_FILE" ] && busybox grep -qx "$TARGET_IFACE" "$STATE_FILE" 2>/dev/null
}

# ── Helper: remove only TARGET_IFACE's own line from STATE_FILE ──────────────
# Never truncates or removes other interfaces' entries — safe to call while
# other repurposeaswan.sh instances are running for different interfaces.
# [fix: fused interface name] now locked + atomic, via repurpose_lib.sh.
_remove_self_from_registry() {
    rp_registry_remove "$TARGET_IFACE"
}

# ── Write PID + register in the shared state file + record our default-route
# flag immediately. Idempotent add: if this interface's line is already
# present (e.g. re-launched by the CGI, which pre-registers synchronously
# before backgrounding this script) it is not duplicated.
# [fix: fused interface name] rp_registry_add is locked, rewrites the file
# whole + atomically and always starts a fresh line, so two watchdogs launched
# together at boot (startup.sh backgrounds them in parallel) cannot splice
# their names together.
echo $$ > "$PID_FILE"
rp_registry_add "$TARGET_IFACE"
printf '%s' "$DEFAULT_ROUTE" > "$DEFROUTE_FILE"
printf '[%s] repurposeaswan started  iface=%s  pid=%s  default_route=%s\n' \
    "$(busybox date)" "$TARGET_IFACE" "$$" "$DEFAULT_ROUTE" > "$LOG"

# ── Create the udhcpc handler (single-quoted heredoc — no expansion) ──────────
busybox cat > "$SCRIPT_PATH" << 'UDHCPC_HANDLER_EOF'
#!/bin/sh
# udhcpc handler — generated by repurposeaswan.sh
mib_get() { mib get "$1" 2>/dev/null | busybox cut -d= -f2- | busybox tr -d '\r\n'; }

# ── Self-lease guard ─────────────────────────────────────────────────────
# True if the offered lease actually came from this device's OWN LAN DHCP
# server (dhcp_control.sh / /bin/udhcpd -S bound to br0) rather than a
# genuine upstream — i.e. the DHCP leak this handler exists to catch.
# Checks $serverid (DHCP option 54, if udhcpc exposes it) and $router,
# since a self-lease from our own udhcpd will carry our own LAN_IP as
# either or both.
_is_self_lease() {
    _OWN_LAN_IP=$(mib_get LAN_IP_ADDR)
    [ -z "$_OWN_LAN_IP" ] && return 1
    [ "$serverid" = "$_OWN_LAN_IP" ] && return 0
    [ "$router" = "$_OWN_LAN_IP" ] && return 0
    return 1
}

case "$1" in
    deconfig)
        ip addr flush dev "$interface" 2>/dev/null
        ;;
    bound|renew)
        if _is_self_lease; then
            printf '[%s] SELF-LEASE DETECTED on %s — lease server/gateway (%s/%s) matches our own LAN_IP (%s). This is the DHCP leak: refusing to configure, flushing, and forcing a fresh discover.\n' \
                "$(busybox date)" "$interface" "$serverid" "$router" "$_OWN_LAN_IP" \
                >> "/tmp/repurpose_${interface}.log" 2>/dev/null
            ip addr flush dev "$interface" 2>/dev/null
            # Kill our own udhcpc so the parent watchdog's liveness check
            # restarts it fresh rather than silently renewing a bogus lease.
            [ -f "/var/run/udhcpc.${interface}.pid" ] && \
                kill "$(busybox cat "/var/run/udhcpc.${interface}.pid" 2>/dev/null)" 2>/dev/null
            exit 0
        fi
        ip addr flush dev "$interface" 2>/dev/null
        # $subnet is dotted-decimal (e.g. 255.255.255.0); ip(8) accepts it.
        # Fall back to /24 only when udhcpc leaves $subnet empty.
        ip addr add "$ip/${subnet:-24}" dev "$interface" 2>/dev/null
        # Only interfaces flagged default_route=1 touch the kernel default
        # route / NAT masquerade. Missing flag file = "1" (matches the old,
        # pre-multi-interface behaviour where the single repurposed WAN
        # always became the default route unconditionally).
        _drf="/tmp/repurpose_defroute_${interface}"
        _use_defroute=$(busybox cat "$_drf" 2>/dev/null | busybox tr -d '\r\n')
        _use_defroute="${_use_defroute:-1}"
        if [ -n "$router" ]; then
            if [ "$_use_defroute" = "1" ]; then
                # Clear EVERY existing default route first — not just one
                # already tied to $interface. This box can have a stale/dead
                # default route left over from the device's own native WAN
                # path (e.g. "default via ... dev br0 linkdown") that has
                # nothing to do with repurposeaswan.sh; a dev-scoped delete
                # leaves that stale route in place and the kernel then
                # refuses (or ECMP-splits) the `ip route add` below, since a
                # default route already exists at the same metric.
                while ip route del default 2>/dev/null; do :; done
                ip route add default via "$router" dev "$interface" 2>/dev/null
                # Persist gateway so the watchdog can restore it if the route is stolen
                printf '%s' "$router" > "/tmp/repurpose_gw_${interface}"
                # Idempotent: delete first, then add, so repeated renewals don't stack rules
                iptables -t nat -D POSTROUTING -o "$interface" -j MASQUERADE 2>/dev/null
                iptables -t nat -A POSTROUTING -o "$interface" -j MASQUERADE 2>/dev/null
            else
                # Not the default-route interface: make sure it never holds
                # the default route or a masquerade rule (covers the case
                # where it used to be the default and was just switched off).
                ip route del default via "$router" dev "$interface" 2>/dev/null
                iptables -t nat -D POSTROUTING -o "$interface" -j MASQUERADE 2>/dev/null
                rm -f "/tmp/repurpose_gw_${interface}"
            fi
        fi
        ;;
esac
exit 0
UDHCPC_HANDLER_EOF
busybox chmod +x "$SCRIPT_PATH"

# ── Helper: true if $TARGET_IFACE is currently enslaved to br0 ────────────────
_in_br0() {
    _M=$(ip link show "$TARGET_IFACE" 2>/dev/null \
        | busybox sed -n 's/.* master \([^ ]*\) .*/\1/p' \
        | busybox tr -d '\r\n')
    [ "$_M" = "br0" ]
}

# ── Helper: remove from br0 if enslaved; log the fix ─────────────────────────
# Returns 0 (success) if a fix was applied, 1 if nothing to do.
_fix_br0() {
    if _in_br0; then
        ip link set "$TARGET_IFACE" nomaster 2>/dev/null
        ip link set "$TARGET_IFACE" up 2>/dev/null
        printf '[%s] FIXED br0 re-enslavement — removed %s from br0 + brought UP\n' \
            "$(busybox date)" "$TARGET_IFACE" >> "$LOG"
        return 0
    fi
    return 1
}

# ── Helper: resolve the /24 subnet TARGET_IFACE is currently on ──────────────
# Mirrors lmehspt.sh's resolve_br0_gateway() logic (assume /24, take the
# interface's own IPv4 and zero the last octet) so the repurposed-WAN's own
# local network (e.g. 192.168.69.0/24) can be blocked for hotspot clients,
# the same way br0's subnet is blocked. Echoes nothing if no IPv4 yet.
_resolve_iface_subnet() {
    local _rif="$1" _rip
    _rip=$(ip -4 addr show "$_rif" 2>/dev/null | busybox grep -o 'inet [0-9.]*' | busybox awk '{print $2}' | head -1)
    if [ -z "$_rip" ]; then
        _rip=$(ifconfig "$_rif" 2>/dev/null | busybox grep -o 'inet \(addr:\)\?[0-9.]*' | busybox grep -o '[0-9.]*' | head -1)
    fi
    [ -n "$_rip" ] && printf '%s' "$_rip" | busybox sed 's/\.[^.]*$/.0\/24/'
}

# ── Helper: current hotspot bridge name (falls back to "br1") ────────────────
_hotspot_br() {
    _hb=$(grep -m1 '^HOTSPOT_BR=' /tmp/coin_config.env 2>/dev/null \
        | sed 's/^HOTSPOT_BR="//;s/"$//')
    printf '%s' "${_hb:-br1}"
}

# ── Helper: true if ebtables is available on this firmware ───────────────────
_HAVE_EBTABLES=""
_have_ebtables() {
    if [ -z "$_HAVE_EBTABLES" ]; then
        if ebtables --version >/dev/null 2>&1 || busybox ebtables --version >/dev/null 2>&1; then
            _HAVE_EBTABLES=1
        else
            _HAVE_EBTABLES=0
        fi
    fi
    [ "$_HAVE_EBTABLES" = "1" ]
}

# ── Helper: apply/refresh DHCP anti-leak rules for TARGET_IFACE ──────────────
# Closes the "LAN DHCP leaking into repurposed WAN" bug: br0's own LAN DHCP
# server (dhcp_control.sh's /bin/udhcpd -S, bound to br0) must never answer a
# DHCPDISCOVER that arrives via TARGET_IFACE's physical port, and its own
# DHCPOFFER/DHCPACK broadcasts must never be flooded back out that port —
# in either direction, in case TARGET_IFACE is ever transiently still bridge-
# flooded (e.g. mid re-enslavement, before _fix_br0 catches it).
#
# Always applied, unconditionally — unlike LAN_ISOLATE below this is a
# correctness fix, not a visibility policy, so it doesn't honour that toggle.
#
# ebtables governs the bridge's own forwarding/flooding decisions, which is
# the right layer regardless of whether the leak is a software re-enslavement
# race or the frame never really left the bridge's flood domain; the iptables
# physdev-matched rules are a second layer for br_netfilter-routed paths.
# physdev is confirmed present on this firmware (see lmehspt.sh's anti-tether
# module list). Idempotent delete-then-insert — safe to call every tick.
_apply_dhcp_antileak() {
    if _have_ebtables; then
        ebtables -D FORWARD -o "$TARGET_IFACE" -p ipv4 --ip-proto udp --ip-sport 67 -j DROP 2>/dev/null
        ebtables -I FORWARD 1 -o "$TARGET_IFACE" -p ipv4 --ip-proto udp --ip-sport 67 -j DROP 2>/dev/null
        ebtables -D FORWARD -i "$TARGET_IFACE" -p ipv4 --ip-proto udp --ip-dport 67 -j DROP 2>/dev/null
        ebtables -I FORWARD 1 -i "$TARGET_IFACE" -p ipv4 --ip-proto udp --ip-dport 67 -j DROP 2>/dev/null
        ebtables -D INPUT -i "$TARGET_IFACE" -p ipv4 --ip-proto udp --ip-dport 67 -j DROP 2>/dev/null
        ebtables -I INPUT 1 -i "$TARGET_IFACE" -p ipv4 --ip-proto udp --ip-dport 67 -j DROP 2>/dev/null
    fi
    iptables -t filter -D FORWARD -m physdev --physdev-out "$TARGET_IFACE" -p udp --sport 67 -j DROP 2>/dev/null
    iptables -t filter -I FORWARD 1 -m physdev --physdev-out "$TARGET_IFACE" -p udp --sport 67 -j DROP
    iptables -t filter -D FORWARD -m physdev --physdev-in "$TARGET_IFACE" -p udp --dport 67 -j DROP 2>/dev/null
    iptables -t filter -I FORWARD 1 -m physdev --physdev-in "$TARGET_IFACE" -p udp --dport 67 -j DROP
    # Non-bridge fallback, in case TARGET_IFACE is ever seen as a plain
    # routed interface rather than a bridge port on some firmware states.
    iptables -t filter -D INPUT -i "$TARGET_IFACE" -p udp --dport 67 -j DROP 2>/dev/null
    iptables -t filter -I INPUT 1 -i "$TARGET_IFACE" -p udp --dport 67 -j DROP
}

_remove_dhcp_antileak() {
    if _have_ebtables; then
        ebtables -D FORWARD -o "$TARGET_IFACE" -p ipv4 --ip-proto udp --ip-sport 67 -j DROP 2>/dev/null
        ebtables -D FORWARD -i "$TARGET_IFACE" -p ipv4 --ip-proto udp --ip-dport 67 -j DROP 2>/dev/null
        ebtables -D INPUT -i "$TARGET_IFACE" -p ipv4 --ip-proto udp --ip-dport 67 -j DROP 2>/dev/null
    fi
    iptables -t filter -D FORWARD -m physdev --physdev-out "$TARGET_IFACE" -p udp --sport 67 -j DROP 2>/dev/null
    iptables -t filter -D FORWARD -m physdev --physdev-in "$TARGET_IFACE" -p udp --dport 67 -j DROP 2>/dev/null
    iptables -t filter -D INPUT -i "$TARGET_IFACE" -p udp --dport 67 -j DROP 2>/dev/null
}

# ── Helper: true if TARGET_IFACE is a wlan*-vxd that is disabled in the MIB ──
# VXD interfaces live at slot 5 of their radio's MBSSIB table:
#   wlan0-vxd → WLAN_MBSSIB_TBL.5.wlanDisabled
#   wlan1-vxd → WLAN1_MBSSIB_TBL.5.wlanDisabled
# Non-VXD interfaces (LAN ports, main wlan0/wlan1) always return false —
# they have no per-MBSSIB slot 5 disable bit owned by wlanbasic.cgi.
_vxd_mib_disabled() {
    local _tbl
    case "$TARGET_IFACE" in
        wlan0-vxd) _tbl="WLAN_MBSSIB_TBL"  ;;
        wlan1-vxd) _tbl="WLAN1_MBSSIB_TBL" ;;
        *)          return 1                  ;;
    esac
    _VD=$(mib get "${_tbl}.5.wlanDisabled" 2>/dev/null \
        | busybox grep '=' \
        | busybox cut -d'=' -f2- \
        | busybox tr -d '\r\n')
    [ "${_VD:-0}" = "1" ]
}

# ── Helper: true if our udhcpc PID is alive ───────────────────────────────────
_udhcpc_alive() {
    if [ -f "$UDHCPC_PID" ]; then
        _UP=$(busybox tr -d '\r\n' < "$UDHCPC_PID" 2>/dev/null)
        [ -n "$_UP" ] && kill -0 "$_UP" 2>/dev/null && return 0
    fi
    # Fallback: process name scan
    busybox ps 2>/dev/null \
        | busybox grep "udhcpc" \
        | busybox grep -q "$TARGET_IFACE"
}

# ── Helper: start (or restart) udhcpc ────────────────────────────────────────
# Kills any existing instance for this interface first so we never end up
# with two udhcpc processes racing each other on the same interface (the old
# behaviour was to start a second one on top of the still-running one).
_start_udhcpc() {
    if [ -f "$UDHCPC_PID" ]; then
        _SU_OLD=$(busybox tr -d '\r\n' < "$UDHCPC_PID" 2>/dev/null)
        [ -n "$_SU_OLD" ] && kill "$_SU_OLD" 2>/dev/null
    fi
    busybox sleep 1   # let it die before we grab the PID file
    busybox udhcpc \
        -i "$TARGET_IFACE" \
        -s "$SCRIPT_PATH" \
        -b \
        -p "$UDHCPC_PID" \
        2>/dev/null
    printf '[%s] udhcpc (re)started for %s\n' \
        "$(busybox date)" "$TARGET_IFACE" >> "$LOG"
}

# ── Helper: force a DHCP rediscover after a carrier/br0 event ────────────────
# Called when the watchdog detects the cable was just plugged in (carrier 0→1)
# or that the vendor daemon re-enslaved the interface to br0 (and we just freed
# it). In both cases udhcpc is likely still alive but stuck in background-retry
# mode with a long inter-attempt gap, so it won't discover on its own for a
# long time. We flush stale addresses and start a fresh instance immediately.
_kick_udhcpc() {
    ip addr flush dev "$TARGET_IFACE" 2>/dev/null
    _start_udhcpc
    printf '[%s] KICK: udhcpc restarted for %s (br0/carrier event)\n' \
        "$(busybox date)" "$TARGET_IFACE" >> "$LOG"
}

# ── Helper: true if the Realtek SDK's `startup` program is still running ─────
# `startup` ("startup&" from /etc/init.d/rc22 or rc32, before rc35 where this
# script is launched from) applies the MIB at boot: LAN ports -> WAN -> each
# radio (set_mib, ifconfig up, `brctl addif br0 X`) -> everything else, and its
# main() ends with pthread_exit(), so the process is gone exactly when all of
# that has finished. It is also the thing that puts TARGET_IFACE into br0, so
# pulling the interface out (`nomaster`) while it is still running races it —
# it can simply re-enslave the port right after. Wait on the process itself,
# not a proxy like "is it in br0 yet". Not running (finished, or this is a
# runtime re-launch from the web UI) simply means there is nothing to wait for.
# Keep in sync with wait_for_sdk_startup() in lmehspt.sh.
_sdk_startup_running() {
    busybox pidof startup >/dev/null 2>&1
}

# ── Helper: true while TARGET_IFACE is an UP netdev the SDK has not yet put in br0
# i.e. the SDK is between `ifconfig X up` and `brctl addif br0 X`. A down
# interface (e.g. a disabled wlan*-vxd) never joins br0, so it isn't awaited.
_target_awaiting_br0() {
    local _fl
    [ -d "/sys/class/net/$TARGET_IFACE" ] || return 1
    [ -d "/sys/class/net/br0/brif/$TARGET_IFACE" ] && return 1
    read -r _fl < "/sys/class/net/$TARGET_IFACE/flags" 2>/dev/null || return 1
    [ $((_fl & 1)) -eq 1 ]      # IFF_UP
}

# ── Helper: wait for the SDK to finish setting up, then for the interface ─────
_wait_for_interface_ready() {
    local max_wait=20 waited=0 sdk_waited=0

    # Stage 1: SDK startup gate — nothing below happens until the SDK has
    # finished applying the MIB and setting up every interface.
    if _sdk_startup_running; then
        printf '[%s] SDK startup (MIB + interface setup) still running - holding off on %s\n' \
            "$(busybox date)" "$TARGET_IFACE" >> "$LOG"
        while _sdk_startup_running; do
            if [ "$sdk_waited" -ge "$SDK_STARTUP_WAIT_MAX" ]; then
                printf '[%s] SDK startup still running after %ss - continuing anyway\n' \
                    "$(busybox date)" "$SDK_STARTUP_WAIT_MAX" >> "$LOG"
                max_wait=90     # SDK hung past the cap: give stragglers longer
                break
            fi
            busybox sleep 1
            sdk_waited=$((sdk_waited + 1))
        done
        printf '[%s] SDK startup wait over after %ss\n' \
            "$(busybox date)" "$sdk_waited" >> "$LOG"
    fi

    # Stage 2: belt and braces, only if we actually had to wait on the SDK (so
    # its interface setup JUST ended): confirm TARGET_IFACE landed in br0,
    # bounded so a port that never joins can't stall boot. When startup was
    # already done before we looked (or this is a runtime re-launch, where the
    # interface is legitimately out of br0 already) there is nothing to race.
    if [ "$sdk_waited" -gt 0 ]; then
        while [ "$waited" -lt "$max_wait" ] && _target_awaiting_br0; do
            busybox sleep 1
            waited=$((waited + 1))
        done
    fi

    # Settle delay
    busybox sleep 3
}

# ── Initial setup ──────────────────────────────────────────────────────────────
printf '[%s] Waiting for interface %s to become ready...\n' \
    "$(busybox date)" "$TARGET_IFACE" >> "$LOG"

_wait_for_interface_ready

printf '[%s] Interface %s ready. Initial setup: nomaster → up → udhcpc\n' \
    "$(busybox date)" "$TARGET_IFACE" >> "$LOG"

ip link set "$TARGET_IFACE" nomaster 2>/dev/null
ip link set "$TARGET_IFACE" up

# ── DHCP anti-leak ───────────────────────────────────────────────────────────
# Applied BEFORE udhcpc ever sends a DISCOVER (previously this ran only as
# part of the LAN_ISOLATE block further below, AFTER _start_udhcpc — leaving
# a real window where the interface was out of br0 and udhcpc was already
# live, but nothing yet blocked br0's own DHCP server from reaching it).
_apply_dhcp_antileak
printf '[%s] DHCP anti-leak rules applied for %s\n' \
    "$(busybox date)" "$TARGET_IFACE" >> "$LOG"

_start_udhcpc

# ── LAN isolation ──────────────────────────────────────────────────────────
# Block the device on this repurposed WAN port from reaching any br0 LAN
# device. www2 (port 8080) listens on 0.0.0.0 and is hit via INPUT, so no
# FORWARD exception is needed — the admin UI remains reachable.
# Honour the LAN_ISOLATE toggle from coin_config.env (default: on).
_LAN_ISOLATE=$(grep -m1 '^LAN_ISOLATE=' /tmp/coin_config.env 2>/dev/null \
    | sed 's/^LAN_ISOLATE="//;s/"$//')
if [ "${_LAN_ISOLATE:-1}" = "1" ]; then
    iptables -t filter -D FORWARD -i "$TARGET_IFACE" -o br0 -j DROP 2>/dev/null
    iptables -t filter -I FORWARD 1 -i "$TARGET_IFACE" -o br0 -j DROP
    iptables -t filter -D INPUT -i "$TARGET_IFACE" -p tcp --dport 8080 -j ACCEPT 2>/dev/null
    iptables -t filter -I INPUT 1 -i "$TARGET_IFACE" -p tcp --dport 8080 -j ACCEPT
    # Block hotspot clients from reaching the repurposed-WAN's own upstream
    # subnet directly (its gateway + sibling devices, e.g. 192.168.69.0/24).
    # The rule above only stops that network from reaching INTO br0 — it does
    # nothing to stop br1 clients from addressing that subnet themselves,
    # since their traffic egresses via TARGET_IFACE, not br0. Destination-based
    # so ordinary internet-bound traffic (routed *through* the gateway, not
    # *to* it) is unaffected.
    _RPW_HOTSPOT_BR=$(_hotspot_br)
    _RPW_SUBNET=$(_resolve_iface_subnet "$TARGET_IFACE")
    if [ -n "$_RPW_SUBNET" ]; then
        iptables -t filter -D FORWARD -i "$_RPW_HOTSPOT_BR" -d "$_RPW_SUBNET" -j DROP 2>/dev/null
        iptables -t filter -I FORWARD 1 -i "$_RPW_HOTSPOT_BR" -d "$_RPW_SUBNET" -j DROP
        printf '%s\n' "$_RPW_SUBNET" > "/tmp/repurpose_subnet_${TARGET_IFACE}.mark"
    fi
    printf '[%s] LAN isolation rules applied for %s\n' \
        "$(busybox date)" "$TARGET_IFACE" >> "$LOG"
fi
# ──────────────────────────────────────────────────────────────────────────

printf '[%s] Setup complete — watchdog interval=%ds\n' \
    "$(busybox date)" "$WATCHDOG_INTERVAL" >> "$LOG"

# Seed carrier baseline so the watchdog can detect 0→1 transitions.
# Read after initial setup: if cable is already connected at this point
# the watchdog won't fire a spurious kick on the very first tick.
_LAST_CARRIER=$(busybox cat "/sys/class/net/$TARGET_IFACE/carrier" 2>/dev/null | busybox tr -d '\r\n')
_LAST_CARRIER="${_LAST_CARRIER:-0}"
_IFACE_MISSING=0   # 1 while the netdev does not exist (see watchdog step 0b)

# ── Event-driven re-enslavement watcher (near-instant, backstops the poll) ──
# The 15s poll in the loop below can leave up to a 15s window where a
# vendor-daemon re-enslavement to br0 goes unnoticed — plenty of time for a
# DHCP handshake to complete and leak a lease. `ip monitor link` reacts to
# the netlink event immediately instead. Best-effort only: some busybox `ip`
# builds don't support `monitor`, in which case this exits right away and
# the poll below is the sole safety net (unchanged behaviour).
MONITOR_PID_FILE="/tmp/repurpose_${TARGET_IFACE}.monitor.pid"
(
    busybox ip monitor link dev "$TARGET_IFACE" 2>/dev/null | while read -r _monline; do
        if _fix_br0; then
            _apply_dhcp_antileak
            _kick_udhcpc
            printf '[%s] event-driven re-enslavement caught: %s\n' \
                "$(busybox date)" "$_monline" >> "$LOG"
        fi
    done
) &
echo $! > "$MONITOR_PID_FILE"

_stop_monitor() {
    [ -f "$MONITOR_PID_FILE" ] || return
    _MPID=$(busybox tr -d '\r\n' < "$MONITOR_PID_FILE" 2>/dev/null)
    [ -n "$_MPID" ] && kill "$_MPID" 2>/dev/null
    rm -f "$MONITOR_PID_FILE"
}

# ── Watchdog loop ──────────────────────────────────────────────────────────────
while true; do
    busybox sleep "$WATCHDOG_INTERVAL"

    # ── Exit condition: state file gone or our own line removed from it ───────
    # (revertwan.sh removes only this interface's line — other concurrently
    # repurposed interfaces' lines are untouched and keep running.)
    if ! _in_state_registry; then
        printf '[%s] No longer in state registry — exiting\n' \
            "$(busybox date)" >> "$LOG"
        _stop_monitor
        rm -f "$PID_FILE" "$DEFROUTE_FILE"
        exit 0
    fi

    # ── VXD MIB disable check ─────────────────────────────────────────────────
    # When the user disables a wlan*-vxd interface via wlanbasic.cgi, it sets
    # WLAN*_MBSSIB_TBL.5.wlanDisabled=1 and calls wlan_apply, which instructs
    # the driver to bring the VXD kernel interface down.  Without this check the
    # watchdog would detect the DOWN state at check 2 and fight the driver by
    # immediately forcing it UP again — every 15 seconds, indefinitely.
    # Read the authoritative MIB bit so the decision is not affected by
    # transient kernel interface states.
    if _vxd_mib_disabled; then
        printf '[%s] %s: wlanDisabled=1 in MIB — stopping repurpose watchdog\n' \
            "$(busybox date)" "$TARGET_IFACE" >> "$LOG"
        _stop_monitor
        _remove_self_from_registry
        rm -f "$PID_FILE" "$DEFROUTE_FILE" "/tmp/repurpose_gw_${TARGET_IFACE}"
        exit 0
    fi

    # ── 0. DHCP anti-leak re-assertion ─────────────────────────────────────────
    # Cheap and idempotent; refreshed every tick so the leak stays closed even
    # if something upstream (an OTA'd firmware reset, a factory-default
    # re-apply, etc.) flushes iptables/ebtables between ticks.
    _apply_dhcp_antileak

    # ── 0b. Interface must exist in the kernel ────────────────────────────────
    # [fix: fused interface name] If the netdev is not there (a wlan*-vxd whose
    # radio is off / mid-reconfigure, a LAN VLAN not created yet) there is
    # nothing to bring UP and nothing for udhcpc to bind to. Previously every
    # tick then logged "was UNKNOWN — brought back UP" + "udhcpc died —
    # restarting" and respawned udhcpc, forever. Now: say so ONCE, then wait.
    # When it comes back, redo the setup and kick DHCP straight away.
    _kicked_this_tick=0
    if [ ! -d "/sys/class/net/$TARGET_IFACE" ]; then
        if [ "$_IFACE_MISSING" != "1" ]; then
            _IFACE_MISSING=1
            printf '[%s] Interface %s does not exist (yet) — waiting for it to appear, not restarting udhcpc\n' \
                "$(busybox date)" "$TARGET_IFACE" >> "$LOG"
        fi
        _LAST_CARRIER=0
        continue
    fi
    if [ "$_IFACE_MISSING" = "1" ]; then
        _IFACE_MISSING=0
        printf '[%s] Interface %s appeared — re-running setup\n' \
            "$(busybox date)" "$TARGET_IFACE" >> "$LOG"
        ip link set "$TARGET_IFACE" nomaster 2>/dev/null
        ip link set "$TARGET_IFACE" up 2>/dev/null
        _kick_udhcpc
        _kicked_this_tick=1
    fi

    # ── 1. br0 binding check (highest priority) ───────────────────────────────
    # _fix_br0 returns 0 when it actually had to remove the interface from br0
    # (vendor networking daemon re-enslaved it on link-up — the main reason
    # plugging in a cable after setup failed to obtain an IP).  On that event
    # kick udhcpc immediately; don't wait for the liveness check below, because
    # udhcpc is still alive — just silently stuck in background-retry mode.
    if _fix_br0; then
        _kick_udhcpc
        _kicked_this_tick=1
    fi

    # ── 2. Interface UP check ─────────────────────────────────────────────────
    # [fix: fused interface name] Judge "up" by the administrative IFF_UP flag,
    # not the `state` word of `ip link show`: virtual / vendor-driver netdevs
    # (VLAN sub-ports, wlan*-vxd) routinely report operstate UNKNOWN, or DOWN
    # with no cable, while being perfectly up — that logged a bogus "was
    # UNKNOWN — brought back UP" every tick. IFF_UP is exactly what
    # `ip link set ... up` changes (same test _target_awaiting_br0 uses).
    _FL=""
    read -r _FL < "/sys/class/net/$TARGET_IFACE/flags" 2>/dev/null
    if [ -z "$_FL" ] || [ $((_FL & 1)) -ne 1 ]; then
        ip link set "$TARGET_IFACE" up 2>/dev/null
        printf '[%s] Interface %s was administratively down (flags=%s) — brought back UP\n' \
            "$(busybox date)" "$TARGET_IFACE" "${_FL:-unreadable}" >> "$LOG"
    fi

    # ── 3. udhcpc liveness check ──────────────────────────────────────────────
    if ! _udhcpc_alive; then
        printf '[%s] udhcpc died — restarting\n' \
            "$(busybox date)" >> "$LOG"
        _start_udhcpc
        _kicked_this_tick=1
    fi

    # ── 4. Default route maintenance ──────────────────────────────────────────
    # If the system (vendor firmware, nas* interface, etc.) steals the default
    # route away from our repurposed WAN, restore it from the saved gw file.
    # Only applies to the interface(s) flagged default_route=1 — re-checked
    # live every tick so flipping the switch off in the UI (which deletes the
    # gw file) sticks even between watchdog ticks, and so a flag flip doesn't
    # require waiting for a fresh DHCP renewal to take effect.
    _DEFROUTE_NOW=$(busybox cat "$DEFROUTE_FILE" 2>/dev/null | busybox tr -d '\r\n')
    _DEFROUTE_NOW="${_DEFROUTE_NOW:-1}"
    _GW_FILE="/tmp/repurpose_gw_${TARGET_IFACE}"
    if [ "$_DEFROUTE_NOW" = "1" ] && [ -f "$_GW_FILE" ]; then
        _GW=$(busybox tr -d '\r\n' < "$_GW_FILE" 2>/dev/null)
        if [ -n "$_GW" ]; then
            _CUR=$(ip route show default 2>/dev/null | head -1)
            case "$_CUR" in
                *"dev $TARGET_IFACE"*) ;; # already correct
                *)
                    while ip route del default 2>/dev/null; do :; done
                    ip route add default via "$_GW" dev "$TARGET_IFACE" 2>/dev/null
                    printf '[%s] RESTORED default route via %s dev %s\n' \
                        "$(busybox date)" "$_GW" "$TARGET_IFACE" >> "$LOG"
                    ;;
            esac
        fi
    fi

    # ── 5. LAN isolation watchdog — honour LAN_ISOLATE toggle ────────────────
    _LI=$(grep -m1 '^LAN_ISOLATE=' /tmp/coin_config.env 2>/dev/null \
        | sed 's/^LAN_ISOLATE="//;s/"$//')
    _RPW_MARK="/tmp/repurpose_subnet_${TARGET_IFACE}.mark"
    _RPW_OLD_SUBNET=$(busybox cat "$_RPW_MARK" 2>/dev/null)
    if [ "${_LI:-1}" = "1" ]; then
        iptables -t filter -D FORWARD -i "$TARGET_IFACE" -o br0 -j DROP 2>/dev/null
        iptables -t filter -I FORWARD 1 -i "$TARGET_IFACE" -o br0 -j DROP
        _RPW_HOTSPOT_BR=$(_hotspot_br)
        _RPW_SUBNET=$(_resolve_iface_subnet "$TARGET_IFACE")
        if [ -n "$_RPW_OLD_SUBNET" ] && [ "$_RPW_OLD_SUBNET" != "$_RPW_SUBNET" ]; then
            iptables -t filter -D FORWARD -i "$_RPW_HOTSPOT_BR" -d "$_RPW_OLD_SUBNET" -j DROP 2>/dev/null
        fi
        if [ -n "$_RPW_SUBNET" ]; then
            iptables -t filter -D FORWARD -i "$_RPW_HOTSPOT_BR" -d "$_RPW_SUBNET" -j DROP 2>/dev/null
            iptables -t filter -I FORWARD 1 -i "$_RPW_HOTSPOT_BR" -d "$_RPW_SUBNET" -j DROP
            printf '%s\n' "$_RPW_SUBNET" > "$_RPW_MARK"
        else
            rm -f "$_RPW_MARK"
        fi
    else
        iptables -t filter -D FORWARD -i "$TARGET_IFACE" -o br0 -j DROP 2>/dev/null
        [ -n "$_RPW_OLD_SUBNET" ] && iptables -t filter -D FORWARD -i "$(_hotspot_br)" -d "$_RPW_OLD_SUBNET" -j DROP 2>/dev/null
        rm -f "$_RPW_MARK"
    fi
    # ──────────────────────────────────────────────────────────────────────────

    # ── 6. Carrier state tracking (cable plug-in detection) ───────────────────
    # Belt-and-suspenders for cases where the vendor daemon does NOT re-enslave
    # the interface to br0 on link-up (rare but possible — e.g. when a WLAN
    # interface associates with an AP, or when the LAN switchd handles link
    # events without touching br0).  A 0→1 carrier transition that wasn't
    # already handled by the br0 fix above means cable just appeared —
    # kick udhcpc so we get a lease right away instead of waiting for its
    # next background-retry interval (which can be several minutes).
    _CUR_CARRIER=$(busybox cat "/sys/class/net/$TARGET_IFACE/carrier" 2>/dev/null \
        | busybox tr -d '\r\n')
    _CUR_CARRIER="${_CUR_CARRIER:-0}"
    if [ "$_CUR_CARRIER" = "1" ] && [ "$_LAST_CARRIER" = "0" ] \
       && [ "$_kicked_this_tick" = "0" ]; then
        printf '[%s] Carrier came up on %s (no br0 event) — kicking udhcpc\n' \
            "$(busybox date)" "$TARGET_IFACE" >> "$LOG"
        ip link set "$TARGET_IFACE" up 2>/dev/null
        _kick_udhcpc
    fi
    _LAST_CARRIER="$_CUR_CARRIER"
done
