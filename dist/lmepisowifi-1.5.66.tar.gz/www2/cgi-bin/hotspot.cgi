#!/bin/sh
# ---------------------------------------------------------------------------
# lmepisowifi — https://github.com/lmepisowifi/tmwim2-2050-g40
# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2026 The lmepisowifi Project — see AUTHORS
#
# Licensed under the GNU AGPLv3 (see LICENSE). Modifying or rewriting this
# file — including by running it through an LLM — does not remove these
# obligations: keep this notice, mark your changes, and offer Corresponding
# Source to network users (AGPLv3 §5, §13). See PROVENANCE.md before
# presenting this as your own original work.
# ---------------------------------------------------------------------------


SESSION_TIMEOUT=600

# ---------------------------------------------------------------
# Auth gate — same pattern as lme.cgi
# ---------------------------------------------------------------
BROWSER_SESSION=$(echo "$HTTP_COOKIE" | busybox sed -n 's/.*session=\([^;]*\).*/\1/p' | busybox tr -d '\r\n')
# Sanitize: session IDs are sha256 hex. Strip anything else to block
# path traversal (e.g. Cookie: session=../../config/foo) into rm/mv/cat.
BROWSER_SESSION=$(echo "$BROWSER_SESSION" | busybox tr -cd 'a-fA-F0-9')
SESSION_FILE="/tmp/sessions/$BROWSER_SESSION"

if [ -z "$BROWSER_SESSION" ] || [ ! -f "$SESSION_FILE" ]; then
    printf "Status: 302 Found\r\n"
    printf "Location: /login.html\r\n\r\n"
    exit 0
fi

LAST=$(cat "$SESSION_FILE" 2>/dev/null | busybox tr -d '\r\n')
NOW=$(date +%s)
[ -z "$LAST" ] && LAST=$NOW

if [ $((NOW - LAST)) -gt $SESSION_TIMEOUT ]; then
    rm -f "$SESSION_FILE"
    printf "Status: 302 Found\r\n"
    printf "Location: /login.html\r\n\r\n"
    exit 0
fi

_SESS_TMP=$(mktemp /tmp/sessions/.tmp.XXXXXX)
echo "$NOW" > "$_SESS_TMP"
busybox mv "$_SESS_TMP" "$SESSION_FILE"

# Clamp body size once for every action below: reject non-numeric and cap
# to 64KB so a malicious Content-Length can't force an oversized read (DoS).
case "${CONTENT_LENGTH:-0}" in *[!0-9]*|"") CONTENT_LENGTH=0 ;; esac
# portal_upload and portal_audio_upload allow larger base64 payloads (up to ~15 MB)
_ACT_PRE=$(echo "$QUERY_STRING" | grep -o 'action=[^&]*' | sed 's/action=//')
if [ "$_ACT_PRE" = "portal_upload" ] || [ "$_ACT_PRE" = "portal_audio_upload" ]; then
    [ "$CONTENT_LENGTH" -gt 15728640 ] && CONTENT_LENGTH=15728640
elif [ "$_ACT_PRE" = "portal_css_save" ] || [ "$_ACT_PRE" = "portal_css_draft" ]; then
    # base64 of a <=24 KB stylesheet is ~33 KB (a bit more once +/= are
    # %-encoded). Anything cut short by this cap fails the css_len cross-check
    # in _pcss_read_post instead of being saved as a truncated stylesheet.
    [ "$CONTENT_LENGTH" -gt 61440   ] && CONTENT_LENGTH=61440
elif [ "$_ACT_PRE" = "users_import" ]; then
    # A url-encoded users.txt (colons/spaces expand to %XX) needs more room
    # than the default cap for any deployment beyond a handful of users.
    [ "$CONTENT_LENGTH" -gt 1048576  ] && CONTENT_LENGTH=1048576
else
    [ "$CONTENT_LENGTH" -gt 65536   ] && CONTENT_LENGTH=65536
fi
# ---------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------
BB="busybox"
HDATA="/lmepisowifi/hotspot_data"
SESSION_DATA="/tmp/active_sessions.txt"
USERS_FILE="$HDATA/users.txt"
WHITELIST_FILE="$HDATA/whitelist.txt"
# One MAC per line: whoever's CURRENT paused USERS_FILE entry was paused by
# lmehspt.sh's inactivity watchdog (system/automatic) rather than an admin
# Kick or a customer's own Pause Time tap (both manual) — see
# pause_session()'s comment in lmehspt.sh for the full explanation. Kick and
# users_import below clear a MAC's line here since both are manual pauses.
AUTO_PAUSED_FILE="$HDATA/auto_paused.txt"
# Below-minimum-tier coin balances banked per-MAC by coin_result.sh — see
# that file's COIN_BANK_FILE comment for the full explanation.
COIN_BANK_FILE="$HDATA/coin_bank.txt"
# WiFi Rates expiry/validity bucket tracking - see ratevalidity.sh.
[ -f /lmepisowifi/hotspot/ratevalidity.sh ] && . /lmepisowifi/hotspot/ratevalidity.sh

_unlock() { rm -f /tmp/hotspot_session.lock/pid 2>/dev/null; rmdir /tmp/hotspot_session.lock 2>/dev/null; }
_lock() {
    local i=0
    while ! mkdir /tmp/hotspot_session.lock 2>/dev/null; do
        # Only steal the lock once its holder is provably dead (see
        # lmehspt.sh's _lock for the full explanation) - a flat 5s wait was
        # force-breaking a live holder's lock under normal polling load and
        # letting two writers stomp the same USERS_FILE.tmp at once. This
        # must match the protocol used by coin_result.sh/login.sh/logout.sh/
        # status.sh/lmehspt.sh exactly (including writing our own pid below)
        # or THIS script's lock is the one that ends up looking "dead" to
        # them after just ~1s and gets stolen out from under it mid-write.
        if [ "$((i % 10))" -eq 0 ] && [ "$i" -gt 0 ]; then
            if [ "$i" -ge 300 ]; then
                $BB rm -f /tmp/hotspot_session.lock/pid 2>/dev/null
                rmdir /tmp/hotspot_session.lock 2>/dev/null
            else
                _HPID=$($BB cat /tmp/hotspot_session.lock/pid 2>/dev/null)
                if [ -z "$_HPID" ] || ! kill -0 "$_HPID" 2>/dev/null; then
                    $BB rm -f /tmp/hotspot_session.lock/pid 2>/dev/null
                    rmdir /tmp/hotspot_session.lock 2>/dev/null
                fi
            fi
        fi
        $BB sleep 0.1 2>/dev/null || sleep 0.1
        i=$((i + 1))
    done
    $BB echo $$ > /tmp/hotspot_session.lock/pid 2>/dev/null
    trap _unlock EXIT INT TERM
}

# Stages "${USERS_FILE}.tmp" with every line except the one starting "$1 ",
# WITHOUT committing it - callers that need to append a replacement line
# first (kick/add_time/reset_time all do) can do so before calling
# _users_file_commit. Refuses (returns 1, tmp file removed) if grep
# couldn't actually read USERS_FILE in the first place. `grep -v` exit
# status: 0 = some lines kept, 1 = every line was a genuine match (also
# what a truly-empty file returns - normal for a fresh/just-touched file),
# 2+ = read/access error. Without this check, a single transient flash
# read glitch produces an empty tmp file that then gets committed over
# USERS_FILE unconditionally, wiping every user's balance in one request.
# Call this INSIDE _lock.
_users_file_stage_excl() {
    local mac="$1" existed=0 rc=0
    [ -e "$USERS_FILE" ] && existed=1
    $BB grep -v "^${mac} " "$USERS_FILE" > "${USERS_FILE}.tmp" 2>/dev/null || rc=$?
    if [ "$existed" -eq 1 ] && [ "$rc" -gt 1 ]; then
        rm -f "${USERS_FILE}.tmp" 2>/dev/null
        logger -t lmehspt "users.txt: refused overwrite after read error (rc=$rc) - kept existing file" 2>/dev/null
        return 1
    fi
    return 0
}
# Same guard as _users_file_stage_excl above, but for VOUCHER_FILE (admin
# voucher add/delete). Without the existed/rc check, a transient flash read
# glitch here would produce an empty tmp file that then gets moved over
# VOUCHER_FILE unconditionally, deleting every voucher in the database in
# one request. Returns 1 (VOUCHER_FILE left untouched) on a genuine read
# error; caller must not report success in that case.
_voucher_file_replace_excl() {
    local code="$1" existed=0 rc=0
    [ -e "$VOUCHER_FILE" ] && existed=1
    $BB grep -v "^${code} " "$VOUCHER_FILE" > "${VOUCHER_FILE}.tmp" 2>/dev/null || rc=$?
    if [ "$existed" -eq 0 ] || [ "$rc" -le 1 ]; then
        $BB mv "${VOUCHER_FILE}.tmp" "$VOUCHER_FILE"
        # Force this out to flash now rather than leaving it to the page
        # cache's own timing - see the matching comment in login.sh.
        sync
        return 0
    fi
    rm -f "${VOUCHER_FILE}.tmp" 2>/dev/null
    logger -t lmehspt "vouchers.txt: refused overwrite after read error (rc=$rc) - kept existing file" 2>/dev/null
    return 1
}
# Same idea again, for NODEMCU_EXTRA_FILE (additional coin acceptor units).
# Rows are ID|TITLE|IP|MAC|PORT|PSK|ENABLED, so the match key is the leading
# "ID|" rather than a space-delimited code.
_nodemcu_file_replace_excl() {
    local id="$1" existed=0 rc=0
    [ -e "$NODEMCU_EXTRA_FILE" ] && existed=1
    $BB grep -v "^${id}|" "$NODEMCU_EXTRA_FILE" > "${NODEMCU_EXTRA_FILE}.tmp" 2>/dev/null || rc=$?
    if [ "$existed" -eq 0 ] || [ "$rc" -le 1 ]; then
        $BB mv "${NODEMCU_EXTRA_FILE}.tmp" "$NODEMCU_EXTRA_FILE"
        sync
        return 0
    fi
    rm -f "${NODEMCU_EXTRA_FILE}.tmp" 2>/dev/null
    logger -t lmehspt "nodemcus_extra.txt: refused overwrite after read error (rc=$rc) - kept existing file" 2>/dev/null
    return 1
}
# True if $1 (an IP) already belongs to some OTHER configured node than $2
# (pass the id being edited, or "0" on add when there's nothing to exclude
# yet). Catches the admin accidentally pointing two units at the same
# address, which would otherwise silently break DHCP/ARP/firewall for
# whichever one loses the race.
_nodemcu_ip_in_use() {
    local ip="$1" exclude="$2" n1ip
    n1ip="${NODEMCU_IP:-$(read_lmehspt_var NODEMCU_IP)}"
    [ "$exclude" != "1" ] && [ "$ip" = "$n1ip" ] && return 0
    [ -f "$NODEMCU_EXTRA_FILE" ] || return 1
    $BB awk -F'|' -v ip="$ip" -v ex="$exclude" \
        '$1!=ex && $3==ip {f=1} END{exit !f}' "$NODEMCU_EXTRA_FILE"
}
# _nodemcu_conn ID  → sets NIP/NPT/CPSK for the given unit id (primary via
# coin_config.env for #1, NODEMCU_EXTRA_FILE's id|title|ip|mac|port|psk|enabled
# rows for #2+). Same resolution nodemcus_get/coin_reset already do inline for
# the primary, just parameterized by id so a signed admin action (nodemcu_setfreq
# below) can target ANY configured unit, not only the primary.
_nodemcu_conn() {
    if [ "$1" = "1" ]; then
        load_coin_env
        NIP="${NODEMCU_IP:-$(read_lmehspt_var NODEMCU_IP)}"
        NPT="${NODEMCU_PORT:-$(read_lmehspt_var NODEMCU_PORT)}"
        CPSK="${COIN_PSK:-$(read_lmehspt_var COIN_PSK)}"
        [ -z "$NPT" ] && NPT=8080
        return
    fi
    NIP=""; NPT="8080"; CPSK=""
    [ -f "$NODEMCU_EXTRA_FILE" ] || return
    _row=$($BB awk -F'|' -v id="$1" '$1==id{print;exit}' "$NODEMCU_EXTRA_FILE" 2>/dev/null)
    [ -z "$_row" ] && return
    NIP=$(printf '%s' "$_row" | $BB awk -F'|' '{print $3}')
    NPT=$(printf '%s' "$_row" | $BB awk -F'|' '{print $5}')
    CPSK=$(printf '%s' "$_row" | $BB awk -F'|' '{print $6}')
    [ -z "$NPT" ] && NPT=8080
}
# Same idea, but for the paused-session update sites which filter with awk
# instead of grep (need to drop only the "$mac paused ..." line, keeping
# any active line for the same mac untouched - grep -v "^$mac " would wrongly
# drop both). Plain awk exits 0 whether or not any line matched, so unlike
# grep there's no "1 = legitimately nothing matched" case to allow through -
# any nonzero exit here reliably means awk couldn't process the file.
_users_file_stage_excl_paused() {
    local mac="$1" existed=0 rc=0
    [ -e "$USERS_FILE" ] && existed=1
    $BB awk -v m="$mac" '$1==m && $2=="paused"{next}{print}' "$USERS_FILE" > "${USERS_FILE}.tmp" 2>/dev/null || rc=$?
    if [ "$existed" -eq 1 ] && [ "$rc" -ne 0 ]; then
        rm -f "${USERS_FILE}.tmp" 2>/dev/null
        logger -t lmehspt "users.txt: refused overwrite after awk read error (rc=$rc) - kept existing file" 2>/dev/null
        return 1
    fi
    return 0
}
_users_file_commit() {
    $BB mv "${USERS_FILE}.tmp" "$USERS_FILE"
    # Rename is atomic/crash-consistent on ubifs, but that only guarantees
    # you never see a half-written file - it says nothing about whether
    # this specific write has actually reached the NAND yet vs. still
    # sitting dirty in the page cache. Force it out now so a power-cut
    # moments after an admin kick/add_time/remove_time/remove_user can't
    # silently roll this request back.
    sync
    # See the matching comment on _users_file_replace_excl in lmehspt.sh:
    # this tells the runtime self-heal that an empty USERS_FILE right now
    # is expected (e.g. an admin just removed the last/only user), not a
    # sign of corruption to restore from backup.
    if [ -s "$USERS_FILE" ]; then rm -f /tmp/hotspot_users_empty_expected 2>/dev/null; else : > /tmp/hotspot_users_empty_expected 2>/dev/null; fi
}

_fmt_secs() {
    # Guard against blank or empty variables
    local s="${1:-0}"
    
    # Strip negative signs if present
    s="${s#-}"
    
    # Force to 0 if containing non-numeric characters
    case "$s" in
        ""|*[!0-9]*) s=0 ;;
    esac

    local d=$(( s / 86400 )) 
    local h=$(( (s % 86400) / 3600 )) 
    local m=$(( (s % 3600) / 60 )) 
    
    if [ "$d" -gt 0 ]; then printf '%dd %dh %dm' "$d" "$h" "$m"
    elif [ "$h" -gt 0 ]; then printf '%dh %dm' "$h" "$m"
    else printf '%dm' "$m"; fi
}
VOUCHER_FILE="$HDATA/vouchers.txt"
NODEMCU_EXTRA_FILE="$HDATA/nodemcus_extra.txt"
NODEMCU_ORDER_FILE="$HDATA/nodemcus_order.txt"
# Drop a node id from the saved display-order file (best effort - the order
# file is advisory; nodemcus_get and coin.sh both re-filter it against the
# live set of ids, so a stale entry can never hide or duplicate a unit).
_order_remove_id() {
    [ -f "$NODEMCU_ORDER_FILE" ] || return 0
    $BB grep -vx "$1" "$NODEMCU_ORDER_FILE" > "${NODEMCU_ORDER_FILE}.tmp" 2>/dev/null \
        && $BB mv "${NODEMCU_ORDER_FILE}.tmp" "$NODEMCU_ORDER_FILE"
    rm -f "${NODEMCU_ORDER_FILE}.tmp" 2>/dev/null
}

# ── DHCP pool / NodeMCU IP helpers ──────────────────────────────────────────
# NodeMCU static IPs occupy the addresses BELOW the DHCP dynamic pool: from one
# past the gateway up to one before the pool start. e.g. gateway .1 + DHCP
# start .5  =>  usable NodeMCU IPs .2 .3 .4  (so at most 3 units).
_valid_ipv4() {
    printf '%s' "$1" | $BB awk -F. '
        NF!=4 { exit 1 }
        { for(i=1;i<=4;i++){ if($i!~/^[0-9]+$/ || $i+0>255) exit 1 } exit 0 }'
}
_dhcp_prefix()   { printf '%s' "${PORTAL_IP:-$(read_lmehspt_var PORTAL_IP)}" | $BB sed 's/\.[^.]*$//'; }
_dhcp_gw_octet() { printf '%s' "${PORTAL_IP:-$(read_lmehspt_var PORTAL_IP)}" | $BB sed 's/.*\.//'; }
_dhcp_start_octet() {
    _v="${DHCP_START:-$(read_lmehspt_var DHCP_START)}"
    case "$_v" in ''|*[!0-9]*) _v=5 ;; esac
    printf '%s' "$_v"
}
# Usable NodeMCU slot count = start - gateway - 1  (clamped at 0).
_nodemcu_pool_size() {
    _gw=$(_dhcp_gw_octet); _st=$(_dhcp_start_octet)
    _n=$(( _st - _gw - 1 )); [ "$_n" -lt 0 ] && _n=0
    printf '%s' "$_n"
}
# Usable NodeMCU IPs, ascending, one per line.
_nodemcu_pool_ips() {
    _pfx=$(_dhcp_prefix); _gw=$(_dhcp_gw_octet); _st=$(_dhcp_start_octet)
    _o=$(( _gw + 1 ))
    while [ "$_o" -lt "$_st" ]; do printf '%s.%s\n' "$_pfx" "$_o"; _o=$(( _o + 1 )); done
}
# IPs already taken by configured NodeMCUs (primary + extras), one per line.
_nodemcu_used_ips() {
    _pip="${NODEMCU_IP:-$(read_lmehspt_var NODEMCU_IP)}"
    [ -n "$_pip" ] && printf '%s\n' "$_pip"
    [ -f "$NODEMCU_EXTRA_FILE" ] && $BB awk -F'|' '$1 ~ /^[0-9]+$/ && $3!="" {print $3}' "$NODEMCU_EXTRA_FILE"
}
# Lowest usable pool IP not in use; empty when the pool is full.
_next_free_nodemcu_ip() {
    _used=$(_nodemcu_used_ips)
    for _ip in $(_nodemcu_pool_ips); do
        printf '%s\n' "$_used" | $BB grep -qx "$_ip" || { printf '%s' "$_ip"; return 0; }
    done
}
# Count of configured NodeMCUs (primary counts only when it has an IP).
_nodemcu_count() {
    _c=0
    _pip="${NODEMCU_IP:-$(read_lmehspt_var NODEMCU_IP)}"
    [ -n "$_pip" ] && _c=1
    [ -f "$NODEMCU_EXTRA_FILE" ] && _c=$(( _c + $($BB awk -F'|' '$1 ~ /^[0-9]+$/ {n++} END{print n+0}' "$NODEMCU_EXTRA_FILE") ))
    printf '%s' "$_c"
}
# Reassign every NodeMCU a pool IP (lowest-first, primary then extras order) so
# they stay valid after the pool moves. Caller must have confirmed count <=
# pool size and set the in-memory PORTAL_IP / DHCP_START to the NEW values.
_dhcp_renormalize_ips() {
    set -- $(_nodemcu_pool_ips)
    _i=1
    _pip="${NODEMCU_IP:-$(read_lmehspt_var NODEMCU_IP)}"
    if [ -n "$_pip" ]; then
        eval "_new=\${$_i}"
        save_coin_env_var NODEMCU_IP "$_new"; set_lmehspt_var NODEMCU_IP "$_new"; set_globals_var NODEMCU_IP "$_new"
        _i=$(( _i + 1 ))
    fi
    if [ -f "$NODEMCU_EXTRA_FILE" ]; then
        : > /tmp/nm_renorm.tmp
        while IFS='|' read -r _rid _rt _rip _rm _rp _rk _re; do
            case "$_rid" in ''|*[!0-9]*) continue ;; esac
            eval "_new=\${$_i}"
            printf '%s|%s|%s|%s|%s|%s|%s\n' "$_rid" "$_rt" "$_new" "$_rm" "$_rp" "$_rk" "$_re" >> /tmp/nm_renorm.tmp
            _i=$(( _i + 1 ))
        done < "$NODEMCU_EXTRA_FILE"
        $BB mv /tmp/nm_renorm.tmp "$NODEMCU_EXTRA_FILE"; sync
    fi
}
# ── DHCP dynamic lease helpers (leases page: list/renew/delete) ────────────
# busybox udhcpd's lease file is a binary struct dump (see upstream
# networking/udhcp/dhcpd.h):
#   [8-byte big-endian "written_at" unix time]
#   then repeating 36-byte records: expires(4,BE) + lease_nip(4,BE) +
#   mac(6) + hostname(20) + pad(2)
# "expires" on disk is REMAINING seconds as of written_at, not absolute
# time (busybox rewrites it that way on every flush so a device with no
# RTC across reboots doesn't lose leases). We never trust this layout
# blind: every write below is cross-checked against `busybox dumpleases`
# (the same binary's own parser) before a byte is touched, and falls back
# to "unsupported"/"not_found" rather than risk corrupting the file.
LEASES_FILE="/tmp/udhcpd.leases"
LEASE_REC_SIZE=36

# Is $1 a compiled-in busybox applet? (bare `busybox` lists its applets.)
_bb_has() { $BB 2>&1 | $BB grep -qw "$1"; }

# Lowercase, colon-stripped MACs of every configured NodeMCU (static
# leases) — dumpleases dumps the raw file regardless of static_lease
# config, so a MAC that's since been pinned static can leave a stale
# dynamic-looking row in the file. Hide those rather than offer
# renew/delete on a unit that's actually served statically.
_static_lease_macs() {
    _slm="${NODEMCU_MAC:-$(read_lmehspt_var NODEMCU_MAC)}"
    [ -n "$_slm" ] && printf '%s\n' "$_slm" | $BB tr 'A-F' 'a-f' | $BB tr -d ':'
    [ -f "$NODEMCU_EXTRA_FILE" ] && $BB awk -F'|' '$1 ~ /^[0-9]+$/ && $4!="" {print $4}' "$NODEMCU_EXTRA_FILE" \
        | $BB tr 'A-F' 'a-f' | $BB tr -d ':'
}

# Decimal value of the big-endian uint32 at byte offset $2 in file $1.
_read_be32() {
    $BB dd if="$1" bs=1 skip="$2" count=4 2>/dev/null \
        | $BB od -An -tu1 -v \
        | $BB awk '{print ($1*16777216)+($2*65536)+($3*256)+$4}'
}

# Overwrite the 4 bytes at byte offset $2 in file $1 with decimal value
# $3, big-endian, in place — every other byte in the file is untouched.
_write_be32() {
    _wf="$1"; _woff="$2"; _wval="$3"
    _wb0=$(( (_wval / 16777216) % 256 )); _wb1=$(( (_wval / 65536) % 256 ))
    _wb2=$(( (_wval / 256)      % 256 )); _wb3=$(( _wval           % 256 ))
    $BB printf "\\$(printf '%03o' "$_wb0")\\$(printf '%03o' "$_wb1")\\$(printf '%03o' "$_wb2")\\$(printf '%03o' "$_wb3")" \
        | $BB dd of="$_wf" bs=1 seek="$_woff" count=4 conv=notrunc 2>/dev/null
}

# Lowercase hex (no separators) of the 6 MAC bytes at byte offset $2 in
# file $1.
_read_mac_hex() {
    $BB dd if="$1" bs=1 skip="$2" count=6 2>/dev/null | $BB od -An -tx1 -v | $BB tr -d ' \n'
}

# Header size in bytes: 8 for every busybox in real-world use (the
# "written_at" format), 0 for the pre-written_at format some very old
# builds used. Empty = file size doesn't cleanly divide either way —
# treat as unreadable rather than guess.
_lease_header_size() {
    _lfsz=$($BB wc -c < "$LEASES_FILE" 2>/dev/null); _lfsz=${_lfsz:-0}
    [ "$_lfsz" -eq 0 ] && { printf ''; return; }
    if [ "$_lfsz" -ge 8 ] && [ $(( (_lfsz - 8) % LEASE_REC_SIZE )) -eq 0 ]; then
        printf '8'
    elif [ $(( _lfsz % LEASE_REC_SIZE )) -eq 0 ]; then
        printf '0'
    else
        printf ''
    fi
}

# Dedicated lock for lease-file edits — separate from the session _lock
# above (a different resource; sharing that one would serialize unrelated
# kicks/add_time calls behind a udhcpd restart for no reason).
_dhcp_lease_unlock() { rm -f /tmp/hotspot_dhcp_lease.lock/pid 2>/dev/null; rmdir /tmp/hotspot_dhcp_lease.lock 2>/dev/null; }
_dhcp_lease_lock() {
    _dli=0
    while ! mkdir /tmp/hotspot_dhcp_lease.lock 2>/dev/null; do
        if [ "$((_dli % 10))" -eq 0 ] && [ "$_dli" -gt 0 ]; then
            _DLPID=$($BB cat /tmp/hotspot_dhcp_lease.lock/pid 2>/dev/null)
            if [ -z "$_DLPID" ] || ! kill -0 "$_DLPID" 2>/dev/null || [ "$_dli" -ge 100 ]; then
                rm -f /tmp/hotspot_dhcp_lease.lock/pid 2>/dev/null
                rmdir /tmp/hotspot_dhcp_lease.lock 2>/dev/null
            fi
        fi
        $BB sleep 0.1 2>/dev/null || sleep 0.1
        _dli=$(( _dli + 1 ))
    done
    $BB echo $$ > /tmp/hotspot_dhcp_lease.lock/pid 2>/dev/null
}

# Kill + relaunch udhcpd WITHOUT wiping the lease file (unlike the
# hotspot_dhcp_reload path elsewhere, which intentionally wipes every
# lease because the pool itself moved). Caller must already have
# `load_coin_env`'d and sourced lmehspt.sh --lib so start_dhcp() is in
# scope.
_dhcp_restart_preserving_leases() {
    [ -f /tmp/hotspot_dhcp.pid ] && kill -9 "$(cat /tmp/hotspot_dhcp.pid)" 2>/dev/null
    for _rpid in $($BB ps ww | $BB grep "hotspot_dhcp.conf" | $BB grep -v grep | $BB awk '{print $1}'); do
        kill -9 "$_rpid" 2>/dev/null
    done
    start_dhcp
}

LMEHSPT="/lmepisowifi/lmehspt.sh"
COIN_CONFIG="/tmp/coin_config.env"
GLOBALS_ENV="/lmepisowifi/globals.env"

ok_json()  { printf "Status: 200 OK\r\nContent-Type: application/json\r\n\r\n%s" "$1"; exit 0; }
err_json() { printf "Status: 200 OK\r\nContent-Type: application/json\r\n\r\n{\"ok\":false,\"error\":\"%s\"}" "$1"; exit 0; }

# Read a var, preferring globals.env (persistent, PRESERVED across OTA) over
# lmehspt.sh's top-of-file hardcoded default (a COMPONENT wholesale-replaced
# by every OTA — see ota.sh's COMPONENTS list). globals.env is checked first
# and used whenever the key exists there at all, even set to "" — an empty
# value there means the admin deliberately cleared it (e.g. nodemcu_del
# blanking NODEMCU_IP/NODEMCU_MAC/COIN_PSK) and must NOT be second-guessed by
# falling back to lmehspt.sh's shipped default, or an OTA that refreshes
# lmehspt.sh would silently resurrect the deleted primary NodeMCU with
# GitHub's default IP/MAC/PSK. lmehspt.sh is only consulted when the key has
# never been written to globals.env at all (pre-first-seed, or a key with no
# default.env entry).
read_lmehspt_var() {
    if $BB grep -q "^$1=" "$GLOBALS_ENV" 2>/dev/null; then
        $BB grep -m1 "^$1=" "$GLOBALS_ENV" 2>/dev/null \
            | $BB sed 's/^[^=]*="\(.*\)"/\1/' \
            | $BB sed "s/^[^=]*='\(.*\)'/\1/" \
            | $BB sed 's/^[^=]*=\(.*\)/\1/'
        return
    fi
    $BB grep -m1 "^$1=" "$LMEHSPT" 2>/dev/null \
        | $BB sed 's/^[^=]*="\(.*\)"/\1/' \
        | $BB sed "s/^[^=]*='\(.*\)'/\1/" \
        | $BB sed 's/^[^=]*=\(.*\)/\1/'
}

# ---------------------------------------------------------------------------
# Value safety for the env files below.
#
# set_lmehspt_var / save_coin_env_var / set_globals_var / set_tgbot_var write
#     KEY="value"
# into files a root shell later SOURCES or EXECUTES (lmehspt.sh,
# coin_config.env, globals.env, telegram_bot.env) -- coin_config.env is even
# sourced again inside the same request (load_coin_env). A value holding " $ `
# or \ therefore either corrupts the file (hotspot fails to start at the next
# boot: "Unterminated quoted string") or runs as root (value $(cmd)); "|" is
# the sed delimiter two of the writers use, and control characters (CR/LF)
# split the line. env_val_safe() refuses all of those. UTF-8 bytes are fine.
# ---------------------------------------------------------------------------
env_val_safe() {
    case "$1" in *'"'*|*'$'*|*'`'*|*'\'*|*'|'*) return 1 ;; esac
    # Map control chars to '#' and compare: any difference = a control char was
    # present. (Deleting them and testing for empty would be defeated by
    # $(...) stripping a trailing newline.)
    [ "$(printf '%s' "$1" | $BB tr '\000-\037\177' '#')" = "$1" ]
}

# Cosmetic free text (device title): drop the unsafe characters instead of
# rejecting, the same convention notify_set's san() already uses.
env_text_san() { printf '%s' "$1" | $BB tr -d '|"\\$\140\000-\037\177'; }

# Per-key format check for config_set. $1 = KEY, $2 = non-empty value.
cfg_val_ok() {
    env_val_safe "$2" || return 1      # first, so a multi-line value can't slip
                                       # past the single-line greps below
    case "$1" in
        GLOBAL_RATE|PER_USER_RATE|PER_USER_BURST|UNAUTH_RATE)
            # tc rate / size, interpolated unquoted into tc commands: 50mbit, 10k, 1.5mbit
            printf '%s' "$2" | $BB grep -qE '^[0-9]+(\.[0-9]+)?[A-Za-z]{0,8}$' ;;
        INACTIVITY_TIMEOUT|COIN_TIMEOUT|COIN_STRIKE_THRESHOLD|COIN_COOLDOWN|VOUCHER_STRIKE_THRESHOLD|VOUCHER_COOLDOWN)
            printf '%s' "$2" | $BB grep -qE '^[0-9]{1,7}$' ;;
        NODEMCU_PORT|PORTAL_PORT)
            printf '%s' "$2" | $BB grep -qE '^[0-9]{1,5}$' && [ "$2" -ge 1 ] && [ "$2" -le 65535 ] ;;
        AUTO_PAUSE_ENABLED|AUTO_RESUME_ENABLED|RELOAD_AFTER_TIME_ADDED_ENABLED|EQUAL_SHARING_ENABLED|NODEMCU_1_ENABLED)
            [ "$2" = "0" ] || [ "$2" = "1" ] ;;
        QOS_QDISC)
            # Strict enum: this lands in lmehspt.sh / globals.env / coin_config.env.
            [ "$2" = "auto" ] || [ "$2" = "fq_codel" ] || [ "$2" = "sfq" ] ;;
        NODEMCU_IP|PORTAL_IP)
            _valid_ipv4 "$2" ;;
        NODEMCU_MAC)
            printf '%s' "$2" | $BB grep -qE '^[0-9A-Fa-f]{12}$' ;;
        COIN_RATES)
            # "PESO:MINUTES" or "PESO:MINUTES:VALIDITY", space separated. Also
            # echoed raw into JSON that the unauthenticated portal reads.
            printf '%s' "$2" | $BB grep -qE '^[0-9.]+(:[0-9.]+){1,2}( [0-9.]+(:[0-9.]+){1,2})*$' ;;
        NODEMCU_1_TITLE)
            [ "${#2}" -le 64 ] ;;
        COIN_PSK)
            [ "${#2}" -le 127 ] ;;       # NodeMCU firmware's psk[128] buffer
        *)  return 1 ;;                  # unknown key: refuse
    esac
}

# Safely rewrite a var in lmehspt.sh
set_lmehspt_var() {
    local var="$1" val="$2"
    local esc
    env_val_safe "$val" || return 1
    esc=$(printf '%s' "$val" | $BB sed 's/[\/&]/\\&/g')
    $BB sed -i "s|^${var}=.*|${var}=\"${esc}\"|" "$LMEHSPT"
}

# Write / update a key in coin_config.env (runtime hot-reload)
save_coin_env_var() {
    local var="$1" val="$2"
    env_val_safe "$val" || return 1
    touch "$COIN_CONFIG"
    $BB grep -v "^${var}=" "$COIN_CONFIG" > /tmp/coin_cfg_upd.tmp 2>/dev/null
    echo "${var}=\"${val}\"" >> /tmp/coin_cfg_upd.tmp
    $BB mv /tmp/coin_cfg_upd.tmp "$COIN_CONFIG"
}

load_coin_env() { [ -f "$COIN_CONFIG" ] && . "$COIN_CONFIG"; }

# Write / update a key in /lmepisowifi/globals.env (persistent flash store).
# Adds the key if absent; replaces it if present.  Same sed pattern as
# set_lmehspt_var so the two files stay in sync after every UI save.
set_globals_var() {
    local var="$1" val="$2"
    local esc
    env_val_safe "$val" || return 1
    esc=$(printf '%s' "$val" | $BB sed 's/[\\/&]/\\&/g')
    if $BB grep -q "^${var}=" "$GLOBALS_ENV" 2>/dev/null; then
        $BB sed -i "s|^${var}=.*|${var}=\"${esc}\"|" "$GLOBALS_ENV"
    else
        printf '%s="%s"\n' "$var" "$val" >> "$GLOBALS_ENV"
    fi
}

# Is the hotspot watchdog currently alive?
hotspot_running() {
    [ -f /tmp/hotspot_watchdog.pid ] || return 1
    local pid; pid=$(cat /tmp/hotspot_watchdog.pid)
    $BB kill -0 "$pid" 2>/dev/null
}

# Is the interactive Telegram router bot (notify.sh --bot) currently
# running? Same pidfile-based check as hotspot_running() above.
bot_running() {
    [ -f /tmp/telegram_bot.pid ] || return 1
    local pid; pid=$(cat /tmp/telegram_bot.pid)
    $BB kill -0 "$pid" 2>/dev/null
}

esc_json() { printf '%s' "$1" | $BB sed 's/\\/\\\\/g; s/"/\\"/g'; }

# Resolve a wlan* netdev name to its WLAN(1)_MBSSIB_TBL row and report
# whether wlanbasic has it disabled. Naming per lmehspt.sh/wan-repurpose.cgi:
#   wlan0 / wlan1        → main AP   (idx 0)
#   wlan{0,1}-vap0..vap3 → VAPs      (idx 1-4)
#   wlan{0,1}-vxd        → repeater  (idx 5)
# Echoes "1" (disabled) or "0" (enabled); unknown/non-wlan names → "0".
wlan_iface_disabled() {
    case "$1" in
        wlan0)      WTBL="WLAN_MBSSIB_TBL";  WIDX=0 ;;
        wlan0-vap0) WTBL="WLAN_MBSSIB_TBL";  WIDX=1 ;;
        wlan0-vap1) WTBL="WLAN_MBSSIB_TBL";  WIDX=2 ;;
        wlan0-vap2) WTBL="WLAN_MBSSIB_TBL";  WIDX=3 ;;
        wlan0-vap3) WTBL="WLAN_MBSSIB_TBL";  WIDX=4 ;;
        wlan0-vxd)  WTBL="WLAN_MBSSIB_TBL";  WIDX=5 ;;
        wlan1)      WTBL="WLAN1_MBSSIB_TBL"; WIDX=0 ;;
        wlan1-vap0) WTBL="WLAN1_MBSSIB_TBL"; WIDX=1 ;;
        wlan1-vap1) WTBL="WLAN1_MBSSIB_TBL"; WIDX=2 ;;
        wlan1-vap2) WTBL="WLAN1_MBSSIB_TBL"; WIDX=3 ;;
        wlan1-vap3) WTBL="WLAN1_MBSSIB_TBL"; WIDX=4 ;;
        wlan1-vxd)  WTBL="WLAN1_MBSSIB_TBL"; WIDX=5 ;;
        *) printf '0'; return ;;
    esac
    WDIS=$(mib get "${WTBL}.${WIDX}.wlanDisabled" 2>/dev/null \
        | $BB grep "=" | $BB cut -d'=' -f2- | $BB tr -d '\r\n')
    [ -z "$WDIS" ] && WDIS=1
    printf '%s' "$WDIS"
}

# Reports whether a wlan* netdev is currently in client/STA mode rather than
# AP mode, per the same wlanMode convention wan-repurpose.cgi reads:
#   Main AP (wlan0/wlan1, idx 0): wlanMode=1 means infrastructure client.
#   VXD (wlan{0,1}-vxd, idx 5):   inherently the client/repeater interface —
#                                 always treated as client mode.
#   VAPs (wlan{0,1}-vap0..vap3):  AP-mode only, never client mode.
# Echoes "1" (client mode) or "0" (AP mode); unknown/non-wlan names → "0".
wlan_iface_is_client() {
    case "$1" in
        wlan0)  CTBL="WLAN_MBSSIB_TBL"  ;;
        wlan1)  CTBL="WLAN1_MBSSIB_TBL" ;;
        wlan0-vxd|wlan1-vxd) printf '1'; return ;;
        *) printf '0'; return ;;
    esac
    CMODE=$(mib get "${CTBL}.0.wlanMode" 2>/dev/null \
        | $BB grep "=" | $BB cut -d'=' -f2- | $BB tr -d '\r\n')
    [ -z "$CMODE" ] && CMODE=0
    printf '%s' "$CMODE"
}

# General-purpose application/x-www-form-urlencoded decoder.
# Decodes ANY %XX sequence (not a hardcoded subset) plus + as space.
# Verified under busybox awk: spaces encoded as %20 decode correctly;
# a bare % not followed by two hex digits passes through unchanged.
urldecode() {
    $BB awk '
    BEGIN {
        for (i = 0; i <= 255; i++) hx[sprintf("%02x", i)] = sprintf("%c", i)
        for (i = 0; i <= 255; i++) hx[sprintf("%02X", i)] = sprintf("%c", i)
    }
    {
        s = $0
        gsub(/\+/, " ", s)
        n = split(s, a, "%")
        out = a[1]
        for (i = 2; i <= n; i++) {
            h = substr(a[i], 1, 2)
            if (length(a[i]) >= 2 && (h in hx)) {
                out = out hx[h] substr(a[i], 3)
            } else {
                out = out "%" a[i]
            }
        }
        print out
    }'
}

# ---------------------------------------------------------------
# Route on QUERY_STRING action
# ---------------------------------------------------------------
QS="$QUERY_STRING"

# ================================================================
# GET ?action=config_get
# Returns all config vars (coin_config.env takes priority over lmehspt.sh)
# ================================================================
if echo "$QS" | $BB grep -q "action=config_get"; then
    load_coin_env

    GR="${GLOBAL_RATE:-$(read_lmehspt_var GLOBAL_RATE)}"
    PUR="${PER_USER_RATE:-$(read_lmehspt_var PER_USER_RATE)}"
    PUB="${PER_USER_BURST:-$(read_lmehspt_var PER_USER_BURST)}"
    UAR="${UNAUTH_RATE:-$(read_lmehspt_var UNAUTH_RATE)}"
    IT="${INACTIVITY_TIMEOUT:-$(read_lmehspt_var INACTIVITY_TIMEOUT)}"
    AP="${AUTO_PAUSE_ENABLED:-$(read_lmehspt_var AUTO_PAUSE_ENABLED)}"
    AP_BOOL="false"; [ "${AP:-1}" = "1" ] && AP_BOOL="true"
    AR="${AUTO_RESUME_ENABLED:-$(read_lmehspt_var AUTO_RESUME_ENABLED)}"
    AR_BOOL="false"; [ "${AR:-0}" = "1" ] && AR_BOOL="true"
    RL="${RELOAD_AFTER_TIME_ADDED_ENABLED:-$(read_lmehspt_var RELOAD_AFTER_TIME_ADDED_ENABLED)}"
    RL_BOOL="false"; [ "${RL:-0}" = "1" ] && RL_BOOL="true"
    ES="${EQUAL_SHARING_ENABLED:-$(read_lmehspt_var EQUAL_SHARING_ENABLED)}"
    ES_BOOL="false"; [ "${ES:-0}" = "1" ] && ES_BOOL="true"
    QD="${QOS_QDISC:-$(read_lmehspt_var QOS_QDISC)}"
    case "$QD" in auto|fq_codel|sfq) ;; *) QD="auto" ;; esac
    # What lmehspt.sh's setup_qos() actually settled on (and why), published to
    # a tmpfs file on every QoS rebuild; empty until the first rebuild after boot.
    QDS="${QOS_QDISC_STATUS:-/tmp/hotspot_qdisc_status}"
    QDA=$($BB sed -n 's/^active=//p' "$QDS" 2>/dev/null | $BB head -n 1)
    QDN=$($BB sed -n 's/^note=//p'   "$QDS" 2>/dev/null | $BB head -n 1)
    CE="${COIN_ENABLED:-$(read_lmehspt_var COIN_ENABLED)}"
    VE="${VOUCHER_ENABLED:-$(read_lmehspt_var VOUCHER_ENABLED)}"
    NIP="${NODEMCU_IP:-$(read_lmehspt_var NODEMCU_IP)}"
    NMC="${NODEMCU_MAC:-$(read_lmehspt_var NODEMCU_MAC)}"
    NPT="${NODEMCU_PORT:-$(read_lmehspt_var NODEMCU_PORT)}"
    NTL="${NODEMCU_1_TITLE:-$(read_lmehspt_var NODEMCU_1_TITLE)}"
    NEN="${NODEMCU_1_ENABLED:-$(read_lmehspt_var NODEMCU_1_ENABLED)}"
    NEN_BOOL="true"; [ "${NEN:-1}" = "0" ] && NEN_BOOL="false"
    CT="${COIN_TIMEOUT:-$(read_lmehspt_var COIN_TIMEOUT)}"
    CR="${COIN_RATES:-$(read_lmehspt_var COIN_RATES)}"
    CPSK="${COIN_PSK:-$(read_lmehspt_var COIN_PSK)}"
    CST="${COIN_STRIKE_THRESHOLD:-$(read_lmehspt_var COIN_STRIKE_THRESHOLD)}"
    CCD="${COIN_COOLDOWN:-$(read_lmehspt_var COIN_COOLDOWN)}"
    CSE="${COIN_STRIKE_ENABLED:-$(read_lmehspt_var COIN_STRIKE_ENABLED)}"
    CSE_BOOL="true"; [ "${CSE:-1}" = "0" ] && CSE_BOOL="false"
    CQE="${COIN_QUEUE_ENABLED:-$(read_lmehspt_var COIN_QUEUE_ENABLED)}"
    CQE_BOOL="true"; [ "${CQE:-1}" = "0" ] && CQE_BOOL="false"
    PIP="${PORTAL_IP:-$(read_lmehspt_var PORTAL_IP)}"
    PPT="${PORTAL_PORT:-$(read_lmehspt_var PORTAL_PORT)}"
    HBR="${HOTSPOT_BR:-$(read_lmehspt_var HOTSPOT_BR)}"
    HIF="${HOTSPOT_INTERFACES:-$(read_lmehspt_var HOTSPOT_INTERFACES)}"
    AT="${ANTI_TETHER:-$(read_lmehspt_var ANTI_TETHER)}"
    AT_BOOL="false"; [ "${AT:-0}" = "1" ] && AT_BOOL="true"
    LI="${LAN_ISOLATE:-$(read_lmehspt_var LAN_ISOLATE)}"
    LI_BOOL="true"; [ "${LI:-1}" = "0" ] && LI_BOOL="false"
    MRF="${MAC_RANDOMIZATION_FIX:-$(read_lmehspt_var MAC_RANDOMIZATION_FIX)}"
    MRF_BOOL="true"; [ "${MRF:-1}" = "0" ] && MRF_BOOL="false"
    HI="${HOTSPOT_ISOLATE:-$(read_lmehspt_var HOTSPOT_ISOLATE)}"
    HI_BOOL="true"; [ "${HI:-1}" = "0" ] && HI_BOOL="false"
    POB="${PAUSE_ON_BOOT:-$(read_lmehspt_var PAUSE_ON_BOOT)}"
    POB_BOOL="true"; [ "${POB:-1}" = "0" ] && POB_BOOL="false"
    CRI="${COIN_REQUIRE_INTERNET:-$(read_lmehspt_var COIN_REQUIRE_INTERNET)}"
    CRI_BOOL="true"; [ "${CRI:-0}" = "0" ] && CRI_BOOL="false"
    VRI="${VOUCHER_REQUIRE_INTERNET:-$(read_lmehspt_var VOUCHER_REQUIRE_INTERNET)}"
    VRI_BOOL="true"; [ "${VRI:-0}" = "0" ] && VRI_BOOL="false"
    VSE="${VOUCHER_STRIKE_ENABLED:-$(read_lmehspt_var VOUCHER_STRIKE_ENABLED)}"
    VSE_BOOL="false"; [ "${VSE:-0}" = "1" ] && VSE_BOOL="true"
    VST="${VOUCHER_STRIKE_THRESHOLD:-$(read_lmehspt_var VOUCHER_STRIKE_THRESHOLD)}"
    VCD="${VOUCHER_COOLDOWN:-$(read_lmehspt_var VOUCHER_COOLDOWN)}"

    HSP_RUNNING="false"; hotspot_running && HSP_RUNNING="true"
    COIN_ON="false"; [ -f /tmp/coin_enabled ] && COIN_ON="true"
    VOUCHER_ON="true"; [ "${VE:-1}" = "0" ] && VOUCHER_ON="false"
    INET_UP="false"; [ -f "${INTERNET_UP_FILE:-/tmp/internet_up}" ] && INET_UP="true"

    ok_json "{\"ok\":true,
\"global_rate\":\"$(esc_json "$GR")\",
\"per_user_rate\":\"$(esc_json "$PUR")\",
\"per_user_burst\":\"$(esc_json "$PUB")\",
\"unauth_rate\":\"$(esc_json "$UAR")\",
\"inactivity_timeout\":\"$(esc_json "$IT")\",
\"auto_pause_enabled\":$AP_BOOL,
\"auto_resume_enabled\":$AR_BOOL,
\"reload_after_time_added\":$RL_BOOL,
\"equal_sharing_enabled\":$ES_BOOL,
\"qos_qdisc\":\"$(esc_json "$QD")\",
\"qos_qdisc_active\":\"$(esc_json "$QDA")\",
\"qos_qdisc_note\":\"$(esc_json "$QDN")\",
\"coin_enabled\":\"$(esc_json "$CE")\",
\"coin_on\":$COIN_ON,
\"voucher_on\":$VOUCHER_ON,
\"nodemcu_ip\":\"$(esc_json "$NIP")\",
\"nodemcu_mac\":\"$(esc_json "$NMC")\",
\"nodemcu_port\":\"$(esc_json "$NPT")\",
\"nodemcu_1_title\":\"$(esc_json "$NTL")\",
\"nodemcu_1_enabled\":$NEN_BOOL,
\"coin_timeout\":\"$(esc_json "$CT")\",
\"coin_rates\":\"$(esc_json "$CR")\",
\"coin_psk\":\"$(esc_json "$CPSK")\",
\"coin_strike_threshold\":\"$(esc_json "$CST")\",
\"coin_cooldown\":\"$(esc_json "$CCD")\",
\"coin_strike_enabled\":$CSE_BOOL,
\"coin_queue_enabled\":$CQE_BOOL,
\"portal_ip\":\"$(esc_json "$PIP")\",
\"portal_port\":\"$(esc_json "$PPT")\",
\"hotspot_br\":\"$(esc_json "$HBR")\",
\"hotspot_interfaces\":\"$(esc_json "$HIF")\",
\"anti_tether\":$AT_BOOL,
\"lan_isolate\":$LI_BOOL,
\"mac_randomization_fix\":$MRF_BOOL,
\"hotspot_isolate\":$HI_BOOL,
\"pause_on_boot\":$POB_BOOL,
\"coin_require_internet\":$CRI_BOOL,
\"voucher_require_internet\":$VRI_BOOL,
\"voucher_strike_enabled\":$VSE_BOOL,
\"voucher_strike_threshold\":\"$(esc_json "$VST")\",
\"voucher_cooldown\":\"$(esc_json "$VCD")\",
\"internet_up\":$INET_UP,
\"hotspot_running\":$HSP_RUNNING}"
fi

# ================================================================
# POST ?action=config_set  (form-encoded body, any subset of config keys)
# Writes to coin_config.env AND lmehspt.sh.
# Uses application/x-www-form-urlencoded — same convention as lme.cgi and
# wlanmac.cgi — instead of hand-rolled JSON regex that breaks on " or \ in PSK.
# ================================================================
if echo "$QS" | $BB grep -q "action=config_set"; then
    read -n "$CONTENT_LENGTH" POST_DATA

    # form-encoded field extractor — uses urldecode() for full %XX support
    fget() {
        printf '%s' "$POST_DATA" \
            | $BB tr '&' '\n' \
            | $BB grep "^$1=" \
            | $BB sed 's/^[^=]*=//' \
            | urldecode \
            | head -1
    }

    apply_if() {
        local key="$1" val="$2"
        [ -z "$val" ] && return
        save_coin_env_var "$key" "$val"
        set_lmehspt_var "$key" "$val"
        set_globals_var  "$key" "$val"
    }

    # Validate EVERY submitted field before writing ANY of them: a bad value
    # must not leave the three config files half-updated, and none of these
    # values may reach a root-sourced file unchecked (see env_val_safe above).
    for _m in GLOBAL_RATE:global_rate PER_USER_RATE:per_user_rate PER_USER_BURST:per_user_burst UNAUTH_RATE:unauth_rate INACTIVITY_TIMEOUT:inactivity_timeout AUTO_PAUSE_ENABLED:auto_pause_enabled AUTO_RESUME_ENABLED:auto_resume_enabled RELOAD_AFTER_TIME_ADDED_ENABLED:reload_after_time_added EQUAL_SHARING_ENABLED:equal_sharing_enabled QOS_QDISC:qos_qdisc NODEMCU_IP:nodemcu_ip NODEMCU_MAC:nodemcu_mac NODEMCU_PORT:nodemcu_port NODEMCU_1_TITLE:nodemcu_1_title NODEMCU_1_ENABLED:nodemcu_1_enabled COIN_TIMEOUT:coin_timeout COIN_RATES:coin_rates COIN_PSK:coin_psk COIN_STRIKE_THRESHOLD:coin_strike_threshold COIN_COOLDOWN:coin_cooldown VOUCHER_STRIKE_THRESHOLD:voucher_strike_threshold VOUCHER_COOLDOWN:voucher_cooldown PORTAL_IP:portal_ip PORTAL_PORT:portal_port; do
        _k=${_m%%:*}; _f=${_m#*:}
        _v=$(fget "$_f")
        [ -z "$_v" ] && continue
        cfg_val_ok "$_k" "$_v" || err_json "invalid_$_f"
    done

    # Capture old NodeMCU values before overwriting so we can detect a change
    OLD_NIP=$(read_lmehspt_var NODEMCU_IP)
    OLD_NMC=$(read_lmehspt_var NODEMCU_MAC)
    OLD_NEN=$(read_lmehspt_var NODEMCU_1_ENABLED)

    apply_if "GLOBAL_RATE"         "$(fget global_rate)"
    apply_if "PER_USER_RATE"       "$(fget per_user_rate)"
    apply_if "PER_USER_BURST"      "$(fget per_user_burst)"
    apply_if "UNAUTH_RATE"         "$(fget unauth_rate)"
    apply_if "INACTIVITY_TIMEOUT"  "$(fget inactivity_timeout)"
    apply_if "AUTO_PAUSE_ENABLED"  "$(fget auto_pause_enabled)"
    apply_if "AUTO_RESUME_ENABLED" "$(fget auto_resume_enabled)"
    apply_if "RELOAD_AFTER_TIME_ADDED_ENABLED" "$(fget reload_after_time_added)"
    apply_if "EQUAL_SHARING_ENABLED" "$(fget equal_sharing_enabled)"
    apply_if "QOS_QDISC"           "$(fget qos_qdisc)"
    apply_if "NODEMCU_IP"          "$(fget nodemcu_ip)"
    apply_if "NODEMCU_MAC"         "$(fget nodemcu_mac)"
    apply_if "NODEMCU_PORT"        "$(fget nodemcu_port)"
    apply_if "NODEMCU_1_TITLE"     "$(fget nodemcu_1_title)"
    apply_if "NODEMCU_1_ENABLED"   "$(fget nodemcu_1_enabled)"
    apply_if "COIN_TIMEOUT"        "$(fget coin_timeout)"
    apply_if "COIN_RATES"          "$(fget coin_rates)"
    apply_if "COIN_PSK"            "$(fget coin_psk)"
    apply_if "COIN_STRIKE_THRESHOLD" "$(fget coin_strike_threshold)"
    apply_if "COIN_COOLDOWN"       "$(fget coin_cooldown)"
    apply_if "VOUCHER_STRIKE_THRESHOLD" "$(fget voucher_strike_threshold)"
    apply_if "VOUCHER_COOLDOWN"    "$(fget voucher_cooldown)"
    apply_if "PORTAL_IP"           "$(fget portal_ip)"
    apply_if "PORTAL_PORT"         "$(fget portal_port)"

    # Restart DHCP when the NodeMCU static-lease entry changed OR it was
    # enabled/disabled — start_dhcp() in lmehspt.sh bakes NODEMCU_IP/MAC (and
    # now whether the lease is emitted at all) into udhcpd.conf once; without
    # a restart the change won't take effect until the next hotspot start.
    NEW_NIP=$(read_lmehspt_var NODEMCU_IP)
    NEW_NMC=$(read_lmehspt_var NODEMCU_MAC)
    NEW_NEN=$(read_lmehspt_var NODEMCU_1_ENABLED)
    if [ "$OLD_NIP" != "$NEW_NIP" ] || [ "$OLD_NMC" != "$NEW_NMC" ] || [ "${OLD_NEN:-1}" != "${NEW_NEN:-1}" ]; then
        [ -f /tmp/hotspot_dhcp.pid ] && kill -9 "$(cat /tmp/hotspot_dhcp.pid)" 2>/dev/null
        load_coin_env
        LMEHSPT_LIB_ONLY=1
        . /lmepisowifi/lmehspt.sh --lib
        # busybox udhcpd re-issues whatever a MAC's leases-file entry already
        # says regardless of a freshly (re)written static_lease line — wipe
        # its memory so the restarted daemon has no stale record to fall
        # back on. Same fix apply_portal_ip_change already relies on for
        # subnet changes; this is the same class of staleness on a MAC swap.
        rm -f /tmp/udhcpd.leases
        start_dhcp

        # Flush the kernel's ARP/neighbor cache for the old and new NodeMCU
        # IPs. coin_result.sh's Guard 2 authenticates every coin-grant POST
        # by looking up who currently owns NODEMCU_IP in /proc/net/arp.
        # Swapping in a new NodeMCU (new MAC, same IP) leaves a STALE entry
        # pointing at the OLD device's MAC — and unlike a missing entry, a
        # stale-but-present one is never re-resolved on its own (Guard 2
        # only re-pings on a cache miss, not a mismatch), so every grant
        # from the new device gets silently rejected until the kernel
        # eventually garbage-collects the entry or the box reboots. Deleting
        # it here forces a genuine cache miss so the very next request
        # re-resolves the correct MAC immediately instead of binding on reboot.
        ip neigh del "$OLD_NIP" dev "$HOTSPOT_BR" 2>/dev/null
        $BB arp -d "$OLD_NIP" 2>/dev/null
        if [ "$NEW_NIP" != "$OLD_NIP" ]; then
            ip neigh del "$NEW_NIP" dev "$HOTSPOT_BR" 2>/dev/null
            $BB arp -d "$NEW_NIP" 2>/dev/null
        fi
        # Force the device off its current association so it re-DHCPs against
        # the just-restarted daemon right away instead of only picking up the
        # new static lease whenever its own renewal timer next fires.
        kick_sta_mac "$NEW_NMC"
        # Proactively re-resolve so the cache already reflects the new device
        # by the time it makes its first request, rather than relying solely
        # on Guard 2's own on-demand ping-and-retry.
        ping -c 1 -W 1 "$NEW_NIP" >/dev/null 2>&1
    fi
    touch /tmp/hotspot_qos_reload
    ok_json "{\"ok\":true}"
fi

# ================================================================
# POST ?action=qos_apply
# Signals the watchdog to rebuild QoS with the freshly-saved rates.
# Using a trigger file (rather than deleting qdiscs directly from the CGI)
# ensures the watchdog always uses the correct WAN_INT — which may differ
# from the default br0 when the repurpose-as-WAN feature is active.
# The watchdog detects the file on its next tick (≤ 1s) and calls
# setup_qos() + restore_qos_sessions() with the updated coin_config.env.
# ================================================================
if echo "$QS" | $BB grep -q "action=qos_apply"; then
    touch /tmp/hotspot_qos_reload
    ok_json "{\"ok\":true,\"msg\":\"QoS reload queued — rates active within 2s\"}"
fi

# ================================================================
# POST ?action=hotspot_start
# Launches lmehspt.sh in background; marks HOTSPOT_ENABLED=1
# ================================================================
if echo "$QS" | $BB grep -q "action=hotspot_start"; then
    if hotspot_running; then
        ok_json "{\"ok\":true,\"running\":true,\"msg\":\"already running\"}"
    fi
    set_lmehspt_var "HOTSPOT_ENABLED" "1"
    save_coin_env_var "HOTSPOT_ENABLED" "1"
    /lmepisowifi/lmehspt.sh >/tmp/lmehspt_start.log 2>&1 &
    # Poll for the watchdog PID file instead of a fixed sleep — wait_for_wlan_ready
    # can block 90-180s at first boot, so sleep 2 would report false "not running"
    # and risk a second concurrent start if the user clicks the button again.
    # We report "starting" when still not up after 15s so the UI toast is honest.
    _waited=0
    while [ $_waited -lt 15 ]; do
        hotspot_running && break
        $BB sleep 1
        _waited=$(( _waited + 1 ))
    done
    RUNNING="false"; hotspot_running && RUNNING="true"
    MSG="started"
    [ "$RUNNING" = "false" ] && MSG="starting — WLAN still initialising, check again in a moment"
    ok_json "{\"ok\":true,\"running\":$RUNNING,\"msg\":\"$MSG\"}"
fi

# ================================================================
# POST ?action=hotspot_stop
# Kills the watchdog, tears down iptables/tc, marks HOTSPOT_ENABLED=0
# ================================================================
if echo "$QS" | $BB grep -q "action=hotspot_stop"; then
    set_lmehspt_var "HOTSPOT_ENABLED" "0"
    save_coin_env_var "HOTSPOT_ENABLED" "0"

    # Kill watchdog
    if [ -f /tmp/hotspot_watchdog.pid ]; then
        kill -9 "$(cat /tmp/hotspot_watchdog.pid)" 2>/dev/null
        rm -f /tmp/hotspot_watchdog.pid
    fi
    # Kill DHCP server
    if [ -f /tmp/hotspot_dhcp.pid ]; then
        kill -9 "$(cat /tmp/hotspot_dhcp.pid)" 2>/dev/null
        rm -f /tmp/hotspot_dhcp.pid
    fi
    # Kill portal httpd
    load_coin_env
    PIP="${PORTAL_IP:-192.168.99.1}"
    PPT="${PORTAL_PORT:-808}"
    for pid in $($BB ps | $BB grep httpd | $BB grep -v grep | $BB grep -F "$PIP:$PPT" | $BB awk '{print $1}'); do
        kill -9 "$pid" 2>/dev/null
    done

    # Source lmehspt.sh in --lib mode to get all its functions without
    # running the main boot sequence, then call cleanup_old_hotspot() directly.
    # This tears down tc on both WAN_INT and HOTSPOT_BR, removes iptables chains
    # (HOTSPOT nat + HOTSPOT_FWD filter + mangle marks), kills DHCP, shuts down
    # the portal httpd, brings down br1, and returns enslaved interfaces to br0
    # — exactly the same logic the script itself uses, with zero drift risk.
    LMEHSPT_LIB_ONLY=1
    . /lmepisowifi/lmehspt.sh --lib
    cleanup_old_hotspot

    ok_json "{\"ok\":true,\"running\":false}"
fi

# ================================================================
# GET ?action=sessions
# ================================================================
if echo "$QS" | $BB grep -q "action=sessions"; then
    _lock
    UPTIME=$($BB awk '{print int($1)}' /proc/uptime)
    OUT="["; SEP=""; SEEN_MACS=" "
    if [ -f "$SESSION_DATA" ]; then
        while read -r mac expiry total; do
            [ -n "$mac" ] || continue
            rem=$(( expiry - UPTIME ))
            [ "$rem" -le 0 ] && continue
            [ -z "$total" ] && total=$rem
            used=$(( total - rem )); [ "$used" -lt 0 ] && used=0
            ip=""
            [ -f /tmp/hotspot_ip_map.txt ] && ip=$($BB grep "^$mac " /tmp/hotspot_ip_map.txt | $BB awk '{print $2}' | head -1)
            [ -z "$ip" ] && ip=$($BB awk -v m="$mac" '$4==m{print $1;exit}' /proc/net/arp 2>/dev/null)
            bank=0
            [ -f "$COIN_BANK_FILE" ] && bank=$($BB awk -v m="$mac" '$1==m{print $2;exit}' "$COIN_BANK_FILE")
            case "$bank" in ''|*[!0-9]*) bank=0 ;; esac
            OUT="${OUT}${SEP}{\"mac\":\"$mac\",\"ip\":\"${ip:-?}\",\"remaining\":$rem,\"total\":$total,\"used\":$used,\"paused\":false,\"available_coins\":$bank}"
            SEP=","
            SEEN_MACS="${SEEN_MACS}${mac} "
        done < "$SESSION_DATA"
    fi
    if [ -f "$USERS_FILE" ]; then
        while read -r mac status rem total fmt; do
            [ -n "$mac" ] && [ "$status" = "paused" ] || continue
            [ -z "$total" ] && total=$rem
            used=$(( total - rem )); [ "$used" -lt 0 ] && used=0
            ip=$($BB awk -v m="$mac" '$4==m{print $1;exit}' /proc/net/arp 2>/dev/null)
            bank=0
            [ -f "$COIN_BANK_FILE" ] && bank=$($BB awk -v m="$mac" '$1==m{print $2;exit}' "$COIN_BANK_FILE")
            case "$bank" in ''|*[!0-9]*) bank=0 ;; esac
            OUT="${OUT}${SEP}{\"mac\":\"$mac\",\"ip\":\"${ip:-?}\",\"remaining\":$rem,\"total\":$total,\"used\":$used,\"paused\":true,\"available_coins\":$bank}"
            SEP=","
            SEEN_MACS="${SEEN_MACS}${mac} "
        done < "$USERS_FILE"
    fi
    # A MAC that inserted coins below the minimum tier has no active/paused
    # session at all until it crosses one — nothing above would otherwise
    # surface it, so the admin would have no way to see the balance is
    # sitting there. Give it its own row instead.
    if [ -f "$COIN_BANK_FILE" ]; then
        while read -r mac bank; do
            [ -n "$mac" ] || continue
            case "$bank" in ''|*[!0-9]*) bank=0 ;; esac
            [ "$bank" -gt 0 ] || continue
            case "$SEEN_MACS" in *" ${mac} "*) continue ;; esac
            ip=$($BB awk -v m="$mac" '$4==m{print $1;exit}' /proc/net/arp 2>/dev/null)
            OUT="${OUT}${SEP}{\"mac\":\"$mac\",\"ip\":\"${ip:-?}\",\"remaining\":0,\"total\":0,\"used\":0,\"paused\":false,\"coins_only\":true,\"available_coins\":$bank}"
            SEP=","
        done < "$COIN_BANK_FILE"
    fi
    _unlock
    ok_json "${OUT}]"
fi

# ================================================================
# POST ?action=kick   body: mac=xx:xx:xx:xx:xx:xx
# ================================================================
if echo "$QS" | $BB grep -q "action=kick"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    # The browser sends mac=encodeURIComponent("aa:bb:..") so the colons arrive
    # as %3A. Decode it (urldecode) before matching, otherwise the literal
    # "aa%3abb%3a.." never matches the colon-form MAC stored in the session
    # files / ip_map and the kick silently no-ops. tr -cd also strips any stray
    # chars so the value is safe to use in grep regex and iptables --mac-source.
    MAC=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*mac=\([^&]*\).*/\1/p' | urldecode | $BB tr 'A-Z' 'a-z' | $BB tr -cd 'a-f0-9:')
    [ -z "$MAC" ] && err_json "missing_mac"

    ACTIVITY_FILE="/tmp/hotspot_activity.txt"
    UPTIME=$($BB awk '{print int($1)}' /proc/uptime)
    PAUSED="false"

    _lock
    # Kick == PAUSE: move the device out of RAM active and into the flash master database
    # as paused with its REMAINING time preserved.
    if [ -f "$SESSION_DATA" ] && $BB grep -q "^$MAC " "$SESSION_DATA"; then
        LINE=$($BB grep "^$MAC " "$SESSION_DATA" | head -1)
        K_EXP=$(printf '%s' "$LINE" | $BB awk '{print $2}')
        K_TOT=$(printf '%s' "$LINE" | $BB awk '{print $3}')
        REM=$(( K_EXP - UPTIME )); [ "$REM" -lt 0 ] && REM=0
        [ -z "$K_TOT" ] && K_TOT=$REM

        # remove from active
        $BB grep -v "^$MAC " "$SESSION_DATA" > /tmp/kick_s.tmp; $BB mv /tmp/kick_s.tmp "$SESSION_DATA"

        # Freeze this MAC's expiring (rate-validity) bucket, if it has one
        # — see ratevalidity.sh. No-op for a purely no-expiry balance.
        rv_freeze "$MAC" "$UPTIME" "$REM"

        # add/replace in master db as paused
        mkdir -p "$HDATA"; touch "$USERS_FILE"
        if _users_file_stage_excl "$MAC"; then
            [ "$REM" -gt 0 ] && echo "$MAC paused $REM $K_TOT $(_fmt_secs "$REM")" >> "${USERS_FILE}.tmp"
            _users_file_commit
        fi
        # Kick is a MANUAL pause (see the notify template's reason below) —
        # drop any stale "system auto-paused this MAC" marker so
        # AUTO_RESUME_ENABLED can't silently resume it.
        [ -f "$AUTO_PAUSED_FILE" ] && { $BB grep -vx "$MAC" "$AUTO_PAUSED_FILE" > /tmp/kick_ap.tmp 2>/dev/null; $BB mv /tmp/kick_ap.tmp "$AUTO_PAUSED_FILE"; }
        PAUSED="true"
    fi
    _unlock

    # Cut internet access immediately (whether they were active or already paused)
    iptables -t nat    -D HOTSPOT     -m mac --mac-source "$MAC" -j RETURN 2>/dev/null
    iptables -t filter -D HOTSPOT_FWD -m mac --mac-source "$MAC" -j ACCEPT 2>/dev/null

    # Reset activity bookkeeping + ip map (their paused entry in $PAUSED_DATA stays)
    [ -f "$ACTIVITY_FILE" ] && { $BB grep -v "^$MAC " "$ACTIVITY_FILE" > /tmp/kick_a.tmp 2>/dev/null; $BB mv /tmp/kick_a.tmp "$ACTIVITY_FILE"; }
    [ -f /tmp/hotspot_ip_map.txt ] && { $BB grep -v "^$MAC " /tmp/hotspot_ip_map.txt > /tmp/kick_i.tmp; $BB mv /tmp/kick_i.tmp /tmp/hotspot_ip_map.txt; }

    # Fire the "session paused" alert — admin kick is a MANUAL pause.
    # Only when a session was actually moved to paused (REM > 0). Uses the
    # session_paused event key so it can be muted from the notifications UI.
    if [ "$PAUSED" = "true" ]; then
        . /lmepisowifi/hotspot/notify_templates.sh
        _P_ACTIVE=$($BB grep -c '.' "$SESSION_DATA" 2>/dev/null)
        [ -n "$_P_ACTIVE" ] || _P_ACTIVE=0
        _P_MSG=$(tpl_render "$TPL_SESSION_PAUSED" \
            reason "Manually" \
            remainingtime "$(_fmt_secs "$REM")" \
            totaltime "$(_fmt_secs "$K_TOT")" \
            mac "$MAC" \
            activeusrcount "${_P_ACTIVE:-0}")
        ( /lmepisowifi/hotspot/notify.sh "$_P_MSG" "" session_paused "$MAC" >/dev/null 2>&1 </dev/null & )
    fi

    ok_json "{\"ok\":true,\"mac\":\"$MAC\",\"paused\":$PAUSED}"
fi

# ================================================================
# POST ?action=add_time   body: mac=xx:xx:..&minutes=N
# Extends an active or paused session by N minutes. If the device has
# no session, a fresh active one is created and its firewall rules opened.
# ================================================================
if echo "$QS" | $BB grep -q "action=add_time"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    MAC=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*mac=\([^&]*\).*/\1/p' | urldecode | $BB tr 'A-Z' 'a-z' | $BB tr -cd 'a-f0-9:')
    MINS=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*minutes=\([^&]*\).*/\1/p' | $BB tr -cd '0-9')
    [ -z "$MAC" ]  && err_json "missing_mac"
    [ -z "$MINS" ] && err_json "missing_minutes"
    [ "$MINS" -le 0 ] 2>/dev/null && err_json "bad_minutes"
    ADD=$(( MINS * 60 ))
    UPTIME=$($BB awk '{print int($1)}' /proc/uptime)
    FOUND=0

    _lock
    # Active session -> update RAM and Flash
    if [ -f "$SESSION_DATA" ] && $BB grep -q "^$MAC " "$SESSION_DATA"; then
        $BB awk -v m="$MAC" -v add="$ADD" -v up="$UPTIME" '
            $1==m {
                xe=$2; tot=$3
                if (xe=="") xe=up
                if (tot=="") tot=xe-up
                base=(xe>up?xe:up)
                print m, base+add, tot+add
                next
            }
            { print }
        ' "$SESSION_DATA" > /tmp/at_s.tmp && $BB mv /tmp/at_s.tmp "$SESSION_DATA"
        
        # Sync Flash
        NEW_EXP=$($BB grep "^$MAC " "$SESSION_DATA" | $BB awk '{print $2}')
        NEW_TOT=$($BB grep "^$MAC " "$SESSION_DATA" | $BB awk '{print $3}')
        REM=$(( NEW_EXP - UPTIME ))
        if _users_file_stage_excl "$MAC"; then
            echo "$MAC active $REM $NEW_TOT $(_fmt_secs "$REM")" >> "${USERS_FILE}.tmp"
            _users_file_commit
        fi
        FOUND=1
        
    # Paused session in users.txt -> update Flash
    elif [ -f "$USERS_FILE" ] && $BB grep -q "^$MAC paused " "$USERS_FILE"; then
        OLD_P=$($BB grep "^$MAC paused " "$USERS_FILE" | head -1)
        P_REM=$($BB echo "$OLD_P" | $BB awk '{print $3}')
        P_TOT=$($BB echo "$OLD_P" | $BB awk '{print $4}')
        [ -z "$P_TOT" ] && P_TOT=$P_REM
        N_REM=$(( P_REM + ADD ))
        N_TOT=$(( P_TOT + ADD ))
        
        if _users_file_stage_excl_paused "$MAC"; then
            echo "$MAC paused $N_REM $N_TOT $(_fmt_secs "$N_REM")" >> "${USERS_FILE}.tmp"
            _users_file_commit
        fi
        FOUND=1
    fi

    # No existing session -> create a fresh active one
    if [ "$FOUND" -eq 0 ]; then
        mkdir -p "$HDATA"; touch "$SESSION_DATA"; touch "$USERS_FILE"
        echo "$MAC $(( UPTIME + ADD )) $ADD" >> "$SESSION_DATA"
        
        if _users_file_stage_excl "$MAC"; then
            echo "$MAC active $ADD $ADD $(_fmt_secs "$ADD")" >> "${USERS_FILE}.tmp"
            _users_file_commit
        fi
        
        iptables -t nat    -I HOTSPOT     1 -m mac --mac-source "$MAC" -j RETURN 2>/dev/null
        iptables -t filter -I HOTSPOT_FWD 1 -m mac --mac-source "$MAC" -j ACCEPT 2>/dev/null
    fi
    _unlock

    CREATED="false"; [ "$FOUND" -eq 0 ] && CREATED="true"
    ok_json "{\"ok\":true,\"mac\":\"$MAC\",\"added\":$ADD,\"created\":$CREATED}"
fi

# ================================================================
# POST ?action=create_session   body: mac=xx:xx:xx:xx:xx:xx&minutes=N
# Manual admin entry: creates a brand-new ACTIVE session for a MAC
# that has no session yet. Unlike add_time (which happily extends or
# creates), this REFUSES outright if the MAC already has an active or
# paused session - use +Time on the existing row for that instead.
# ================================================================
if echo "$QS" | $BB grep -q "action=create_session"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    MAC=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*mac=\([^&]*\).*/\1/p' | urldecode | $BB tr 'A-Z' 'a-z' | $BB tr -cd 'a-f0-9:')
    MINS=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*minutes=\([^&]*\).*/\1/p' | $BB tr -cd '0-9')
    [ -z "$MAC" ]  && err_json "missing_mac"
    [ -z "$MINS" ] && err_json "missing_minutes"
    [ "$MINS" -le 0 ] 2>/dev/null && err_json "bad_minutes"

    # Manual entry has no ARP/DHCP source to sanity-check against (every
    # other action here only ever sees MACs the router itself already
    # observed), so require a strict xx:xx:xx:xx:xx:xx shape before it's
    # allowed anywhere near iptables --mac-source or the session files.
    case "$MAC" in
        [0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]) ;;
        *) err_json "bad_mac" ;;
    esac

    ADD=$(( MINS * 60 ))
    UPTIME=$($BB awk '{print int($1)}' /proc/uptime)

    _lock
    # Duplicate guard: same two places add_time checks for an existing
    # session (live RAM table, then the flash-persisted paused row).
    if [ -f "$SESSION_DATA" ] && $BB grep -q "^$MAC " "$SESSION_DATA"; then
        _unlock; err_json "session_exists"
    fi
    if [ -f "$USERS_FILE" ] && $BB grep -q "^$MAC paused " "$USERS_FILE"; then
        _unlock; err_json "session_exists"
    fi

    mkdir -p "$HDATA"; touch "$SESSION_DATA"; touch "$USERS_FILE"
    echo "$MAC $(( UPTIME + ADD )) $ADD" >> "$SESSION_DATA"

    if _users_file_stage_excl "$MAC"; then
        echo "$MAC active $ADD $ADD $(_fmt_secs "$ADD")" >> "${USERS_FILE}.tmp"
        _users_file_commit
    fi

    iptables -t nat    -I HOTSPOT     1 -m mac --mac-source "$MAC" -j RETURN 2>/dev/null
    iptables -t filter -I HOTSPOT_FWD 1 -m mac --mac-source "$MAC" -j ACCEPT 2>/dev/null
    _unlock

    ok_json "{\"ok\":true,\"mac\":\"$MAC\",\"added\":$ADD}"
fi

# ================================================================
# POST ?action=remove_time   body: mac=xx:xx:..&minutes=N
# Subtracts N minutes from an active or paused session.
# Clamps to a minimum of 60 s remaining so the session is never
# wiped accidentally — use Kick if you want to end it outright.
# ================================================================
if echo "$QS" | $BB grep -q "action=remove_time"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    MAC=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*mac=\([^&]*\).*/\1/p' | urldecode | $BB tr 'A-Z' 'a-z' | $BB tr -cd 'a-f0-9:')
    MINS=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*minutes=\([^&]*\).*/\1/p' | $BB tr -cd '0-9')
    [ -z "$MAC" ]  && err_json "missing_mac"
    [ -z "$MINS" ] && err_json "missing_minutes"
    [ "$MINS" -le 0 ] 2>/dev/null && err_json "bad_minutes"
    SUB=$(( MINS * 60 ))
    MIN_REM=60   # floor: keep at least 60 s so the watchdog doesn't expire it mid-op
    UPTIME=$($BB awk '{print int($1)}' /proc/uptime)
    FOUND=0

    _lock
    # Active session — update RAM session file
    if [ -f "$SESSION_DATA" ] && $BB grep -q "^$MAC " "$SESSION_DATA"; then
        $BB awk -v m="$MAC" -v deduct="$SUB" -v up="$UPTIME" -v minr="$MIN_REM" '
            $1==m {
                xe=$2; tot=$3
                if (xe=="") xe=up; if (tot=="") tot=xe-up
                newxe = xe - deduct; newtot = tot - deduct
                if (newxe < up + minr) newxe = up + minr
                if (newtot < minr)     newtot = minr
                print m, newxe, newtot; next
            }
            { print }
        ' "$SESSION_DATA" > /tmp/rt_s.tmp && $BB mv /tmp/rt_s.tmp "$SESSION_DATA"

        NEW_EXP=$($BB grep "^$MAC " "$SESSION_DATA" | $BB awk '{print $2}')
        NEW_TOT=$($BB grep "^$MAC " "$SESSION_DATA" | $BB awk '{print $3}')
        REM=$(( NEW_EXP - UPTIME ))
        if _users_file_stage_excl "$MAC"; then
            echo "$MAC active $REM $NEW_TOT $(_fmt_secs "$REM")" >> "${USERS_FILE}.tmp"
            _users_file_commit
        fi
        FOUND=1

    # Paused session — update flash only
    elif [ -f "$USERS_FILE" ] && $BB grep -q "^$MAC paused " "$USERS_FILE"; then
        OLD_P=$($BB grep "^$MAC paused " "$USERS_FILE" | head -1)
        P_REM=$($BB echo "$OLD_P" | $BB awk '{print $3}')
        P_TOT=$($BB echo "$OLD_P" | $BB awk '{print $4}')
        [ -z "$P_TOT" ] && P_TOT=$P_REM
        N_REM=$(( P_REM - SUB )); [ "$N_REM" -lt "$MIN_REM" ] && N_REM=$MIN_REM
        N_TOT=$(( P_TOT - SUB )); [ "$N_TOT" -lt "$MIN_REM" ] && N_TOT=$MIN_REM

        if _users_file_stage_excl_paused "$MAC"; then
            echo "$MAC paused $N_REM $N_TOT $(_fmt_secs "$N_REM")" >> "${USERS_FILE}.tmp"
            _users_file_commit
        fi
        FOUND=1
    fi
    _unlock

    [ "$FOUND" -eq 0 ] && err_json "session_not_found"
    ok_json "{\"ok\":true,\"mac\":\"$MAC\",\"removed\":$SUB}"
fi

# ================================================================
# POST ?action=remove_user   body: mac=xx:xx:..
# Permanently removes a user and all their time from the active
# session table AND the persistent database. Cannot be undone.
# ================================================================
if echo "$QS" | $BB grep -q "action=remove_user"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    MAC=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*mac=\([^&]*\).*/\1/p' | urldecode | $BB tr 'A-Z' 'a-z' | $BB tr -cd 'a-f0-9:')
    [ -z "$MAC" ] && err_json "missing_mac"
    RM_ACTIVITY="/tmp/hotspot_activity.txt"

    _lock
    [ -f "$SESSION_DATA" ] && { $BB grep -v "^$MAC " "$SESSION_DATA" > /tmp/rm_s.tmp; $BB mv /tmp/rm_s.tmp "$SESSION_DATA"; }
    _users_file_stage_excl "$MAC" && _users_file_commit
    _unlock

    # Revoke internet access (no-op if already paused/removed)
    iptables -t nat    -D HOTSPOT     -m mac --mac-source "$MAC" -j RETURN 2>/dev/null
    iptables -t filter -D HOTSPOT_FWD -m mac --mac-source "$MAC" -j ACCEPT 2>/dev/null

    # Clean up auxiliary files
    [ -f "$RM_ACTIVITY" ]         && { $BB grep -v "^$MAC " "$RM_ACTIVITY"         > /tmp/rm_a.tmp 2>/dev/null; $BB mv /tmp/rm_a.tmp "$RM_ACTIVITY"; }
    [ -f /tmp/hotspot_ip_map.txt ] && { $BB grep -v "^$MAC " /tmp/hotspot_ip_map.txt > /tmp/rm_i.tmp;           $BB mv /tmp/rm_i.tmp /tmp/hotspot_ip_map.txt; }
    [ -f "$COIN_BANK_FILE" ]       && { $BB grep -v "^$MAC " "$COIN_BANK_FILE"       > /tmp/rm_b.tmp 2>/dev/null; $BB mv /tmp/rm_b.tmp "$COIN_BANK_FILE"; }
    [ -f "$AUTO_PAUSED_FILE" ]     && { $BB grep -vx "$MAC" "$AUTO_PAUSED_FILE"      > /tmp/rm_ap.tmp 2>/dev/null; $BB mv /tmp/rm_ap.tmp "$AUTO_PAUSED_FILE"; }
    rv_clear "$MAC"

    ok_json "{\"ok\":true,\"mac\":\"$MAC\"}"
fi

# ================================================================
# GET ?action=users_export
# Streams the raw persistent users.txt database back as plain text so
# the admin can save it as a backup or move it to another box. Same
# row format action=users_import reads back in.
# ================================================================
if echo "$QS" | $BB grep -q "action=users_export"; then
    _lock
    EXPORT_DATA=$($BB cat "$USERS_FILE" 2>/dev/null)
    _unlock
    printf "Status: 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n"
    printf '%s\n' "$EXPORT_DATA"
    exit 0
fi

# ================================================================
# POST ?action=users_import   body: mode=overwrite|merge & data=<users.txt text>
# overwrite: wipes every current user (active sessions get kicked and
#            their firewall rule dropped first) and replaces the whole
#            database with the imported rows.
# merge:     keeps every current user; a MAC present in BOTH the current
#            database and the imported file is overwritten with the
#            imported file's value, everything else is left untouched.
# Every imported row lands as "paused" regardless of its original
# status - import only ever seeds a balance, it never opens a firewall
# rule on its own. A device is promoted back to active the normal way,
# through the captive portal's own login/resume flow, exactly like any
# other paused row.
# ================================================================
if echo "$QS" | $BB grep -q "action=users_import"; then
    read -n "$CONTENT_LENGTH" POST_DATA

    fget() {
        printf '%s' "$POST_DATA" \
            | $BB tr '&' '\n' \
            | $BB grep "^$1=" \
            | $BB sed 's/^[^=]*=//' \
            | urldecode \
            | head -1
    }

    MODE=$(fget mode | $BB tr -cd 'a-z')
    case "$MODE" in overwrite|merge) ;; *) err_json "bad_mode" ;; esac

    # data may be many lines - unlike fget's single-value fields this one
    # must NOT be truncated to the first line, so it's pulled out by hand.
    RAW=$(printf '%s' "$POST_DATA" | $BB tr '&' '\n' | $BB grep "^data=" | $BB sed 's/^data=//' | urldecode)
    [ -z "$RAW" ] && err_json "no_data"

    # Sanitize: keep only well-formed "mac ... remaining total ..." rows,
    # normalize the MAC to lowercase, dedup by MAC (last occurrence in the
    # uploaded file wins). Nothing past this point reads the raw upload -
    # only this filtered, validated set ever reaches users.txt.
    IMPORT_TMP=$(mktemp /tmp/users_import.XXXXXX)
    TOTAL_LINES=$(printf '%s\n' "$RAW" | $BB tr -d '\r' | $BB grep -c '[^[:space:]]')
    printf '%s\n' "$RAW" | $BB tr -d '\r' | $BB awk '
        {
            mac = tolower($1)
            if (mac !~ /^[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]$/) next
            rem = $3; tot = $4
            if (rem !~ /^[0-9]+$/ || rem+0 <= 0) next
            if (tot !~ /^[0-9]+$/ || tot+0 <= 0) tot = rem
            val[mac] = mac " " rem " " tot
        }
        END { for (m in val) print val[m] }
    ' > "$IMPORT_TMP"

    IMPORTED_COUNT=$($BB grep -c '.' "$IMPORT_TMP" 2>/dev/null); [ -z "$IMPORTED_COUNT" ] && IMPORTED_COUNT=0
    if [ "$IMPORTED_COUNT" -eq 0 ]; then
        rm -f "$IMPORT_TMP"
        err_json "no_valid_rows"
    fi
    SKIPPED_COUNT=$(( TOTAL_LINES - IMPORTED_COUNT )); [ "$SKIPPED_COUNT" -lt 0 ] && SKIPPED_COUNT=0

    _lock
    mkdir -p "$HDATA"; touch "$USERS_FILE"; touch "$SESSION_DATA"

    if [ "$MODE" = "overwrite" ]; then
        # Full reset: nothing from the current database survives, so revoke
        # every currently-active MAC's firewall rule and clear RAM state
        # before the persistent file is replaced wholesale below.
        while read -r mac expiry total; do
            [ -n "$mac" ] || continue
            iptables -t nat    -D HOTSPOT     -m mac --mac-source "$mac" -j RETURN 2>/dev/null
            iptables -t filter -D HOTSPOT_FWD -m mac --mac-source "$mac" -j ACCEPT 2>/dev/null
        done < "$SESSION_DATA"
        : > "$SESSION_DATA"
        BASE_SRC="/dev/null"
    else
        # Merge: any imported MAC that's currently active gets pulled out of
        # RAM and its rule revoked first, so a live active-in-RAM record
        # never sits alongside the freshly-imported paused row for the same
        # MAC once the database is rewritten below.
        while read -r mac expiry total; do
            [ -n "$mac" ] || continue
            if $BB grep -q "^$mac " "$IMPORT_TMP"; then
                iptables -t nat    -D HOTSPOT     -m mac --mac-source "$mac" -j RETURN 2>/dev/null
                iptables -t filter -D HOTSPOT_FWD -m mac --mac-source "$mac" -j ACCEPT 2>/dev/null
            fi
        done < "$SESSION_DATA"
        $BB awk -v importf="$IMPORT_TMP" '
            BEGIN { while ((getline line < importf) > 0) { split(line, a, " "); skip[a[1]] = 1 } }
            { if (!($1 in skip)) print }
        ' "$SESSION_DATA" > /tmp/ui_s.tmp && $BB mv /tmp/ui_s.tmp "$SESSION_DATA"
        BASE_SRC="$USERS_FILE"
    fi

    # Existing rows not being overwritten (empty set in overwrite mode),
    # followed by every imported row - written in as paused with the time
    # column recomputed fresh.
    {
        if [ "$BASE_SRC" != "/dev/null" ] && [ -f "$BASE_SRC" ]; then
            $BB awk -v importf="$IMPORT_TMP" '
                BEGIN { while ((getline line < importf) > 0) { split(line, a, " "); skip[a[1]] = 1 } }
                { if (!($1 in skip)) print }
            ' "$BASE_SRC"
        fi
        while read -r mac rem tot; do
            [ -n "$mac" ] || continue
            echo "$mac paused $rem $tot $(_fmt_secs "$rem")"
        done < "$IMPORT_TMP"
    } > "${USERS_FILE}.tmp"
    _users_file_commit
    # Imported rows are admin-supplied, never system-auto-paused — strip any
    # of these MACs out of the auto-pause marker so a stale entry from
    # before the import can't make AUTO_RESUME_ENABLED fire on them.
    if [ -f "$AUTO_PAUSED_FILE" ]; then
        $BB awk -v importf="$IMPORT_TMP" '
            BEGIN { while ((getline line < importf) > 0) { split(line, a, " "); skip[a[1]] = 1 } }
            { if (!($1 in skip)) print }
        ' "$AUTO_PAUSED_FILE" > /tmp/ui_ap.tmp 2>/dev/null && $BB mv /tmp/ui_ap.tmp "$AUTO_PAUSED_FILE"
    fi
    rm -f "$IMPORT_TMP"
    _unlock

    ok_json "{\"ok\":true,\"mode\":\"$MODE\",\"imported\":$IMPORTED_COUNT,\"skipped\":$SKIPPED_COUNT}"
fi

# ================================================================
# GET ?action=whitelist_get
# ================================================================
if echo "$QS" | $BB grep -q "action=whitelist_get"; then
    OUT="["; SEP=""
    if [ -f "$WHITELIST_FILE" ]; then
        while read -r entry; do
            case "$entry" in \#*|"") continue ;; esac
            OUT="${OUT}${SEP}\"$entry\""
            SEP=","
        done < "$WHITELIST_FILE"
    fi
    ok_json "{\"ok\":true,\"list\":${OUT}]}"
fi

# ================================================================
# POST ?action=whitelist_add  body: mac=aabbccddeeff
# ================================================================
if echo "$QS" | $BB grep -q "action=whitelist_add"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    MAC=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*mac=\([^&]*\).*/\1/p' | urldecode | $BB tr 'A-Z' 'a-z' | $BB tr -cd 'a-f0-9')
    [ -z "$MAC" ] && err_json "missing_mac"
    mkdir -p "$HDATA"; touch "$WHITELIST_FILE"
    $BB grep -qi "^${MAC}$" "$WHITELIST_FILE" || echo "$MAC" >> "$WHITELIST_FILE"
    RAW_MAC=$(printf '%s' "$MAC" | $BB sed 's/\(..\)\(..\)\(..\)\(..\)\(..\)\(..\)/\1:\2:\3:\4:\5:\6/')
    iptables -t nat    -I HOTSPOT    1 -m mac --mac-source "$RAW_MAC" -j RETURN 2>/dev/null
    iptables -t filter -I HOTSPOT_FWD 1 -m mac --mac-source "$RAW_MAC" -j ACCEPT 2>/dev/null
    ok_json "{\"ok\":true,\"mac\":\"$MAC\"}"
fi

# ================================================================
# POST ?action=whitelist_del  body: mac=aabbccddeeff
# ================================================================
if echo "$QS" | $BB grep -q "action=whitelist_del"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    MAC=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*mac=\([^&]*\).*/\1/p' | urldecode | $BB tr 'A-Z' 'a-z' | $BB tr -cd 'a-f0-9')
    [ -z "$MAC" ] && err_json "missing_mac"
    if [ -f "$WHITELIST_FILE" ]; then
        WL_RC=0
        $BB grep -iv "^${MAC}$" "$WHITELIST_FILE" > /tmp/wl_del.tmp 2>/dev/null || WL_RC=$?
        if [ "$WL_RC" -gt 1 ]; then
            rm -f /tmp/wl_del.tmp 2>/dev/null
            logger -t lmehspt "whitelist.txt: refused overwrite after read error (rc=$WL_RC) - kept existing file" 2>/dev/null
            err_json "read_error"
        fi
        $BB mv /tmp/wl_del.tmp "$WHITELIST_FILE"
    fi
    RAW_MAC=$(printf '%s' "$MAC" | $BB sed 's/\(..\)\(..\)\(..\)\(..\)\(..\)\(..\)/\1:\2:\3:\4:\5:\6/')
    iptables -t nat    -D HOTSPOT     -m mac --mac-source "$RAW_MAC" -j RETURN 2>/dev/null
    iptables -t filter -D HOTSPOT_FWD -m mac --mac-source "$RAW_MAC" -j ACCEPT 2>/dev/null
    ok_json "{\"ok\":true,\"mac\":\"$MAC\"}"
fi

# ================================================================
# GET ?action=vouchers_get
# ================================================================
if echo "$QS" | $BB grep -q "action=vouchers_get"; then
    OUT="["; SEP=""
    if [ -f "$VOUCHER_FILE" ]; then
        # Voucher format is now just: CODE DURATION (expiry removed).
        # Skip comment/blank lines and any row with a non-numeric duration
        # so the emitted JSON is always valid.
        while read -r code duration _rest; do
            case "$code"     in \#*|"") continue ;; esac
            case "$duration" in *[!0-9]*|"") continue ;; esac
            OUT="${OUT}${SEP}{\"code\":\"$code\",\"duration\":$duration}"
            SEP=","
        done < "$VOUCHER_FILE"
    fi
    ok_json "{\"ok\":true,\"vouchers\":${OUT}]}"
fi

# ================================================================
# POST ?action=voucher_add  body: code=XX&duration=3600
# ================================================================
if echo "$QS" | $BB grep -q "action=voucher_add"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    # Expiry (valid_until) removed. Sanitize CODE to alnum and DUR to digits
    # so they're safe in the grep regex / file write and never break the row.
    CODE=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*code=\([^&]*\).*/\1/p'     | urldecode | $BB tr 'a-z' 'A-Z' | $BB tr -cd 'A-Z0-9')
    DUR=$( printf '%s' "$POST_DATA" | $BB sed -n 's/.*duration=\([^&]*\).*/\1/p' | $BB tr -cd '0-9')
    [ -z "$CODE" ] && err_json "missing_code"
    [ -z "$DUR"  ] && err_json "missing_duration"
    mkdir -p "$HDATA"; touch "$VOUCHER_FILE"
    # Locked: login.sh's redemption path takes this same lock before it
    # touches VOUCHER_FILE. Without taking it here too, an admin add landing
    # mid-redemption is a lost-update race - both sides read the pre-change
    # file, so whichever mv() lands second silently reverts the other's
    # change (e.g. resurrecting a code a customer just redeemed).
    _lock
    VCH_RC=0
    $BB grep -v "^$CODE " "$VOUCHER_FILE" > /tmp/vch_add.tmp 2>/dev/null || VCH_RC=$?
    if [ "$VCH_RC" -gt 1 ]; then
        rm -f /tmp/vch_add.tmp 2>/dev/null
        logger -t lmehspt "vouchers.txt: refused overwrite after read error (rc=$VCH_RC) - kept existing file" 2>/dev/null
        err_json "read_error"
    fi
    echo "$CODE $DUR" >> /tmp/vch_add.tmp
    $BB mv /tmp/vch_add.tmp "$VOUCHER_FILE"
    sync
    _unlock
    ok_json "{\"ok\":true,\"code\":\"$CODE\"}"
fi

# ================================================================
# POST ?action=voucher_del  body: code=XX
# ================================================================
if echo "$QS" | $BB grep -q "action=voucher_del"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    CODE=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*code=\([^&]*\).*/\1/p' | urldecode | $BB tr 'a-z' 'A-Z' | $BB tr -cd 'A-Z0-9')
    [ -z "$CODE" ] && err_json "missing_code"
    # Locked: see the identical note in voucher_add above - login.sh's
    # redemption path takes this same lock, so this side needs to as well.
    _lock
    if [ -f "$VOUCHER_FILE" ] && ! _voucher_file_replace_excl "$CODE"; then
        _unlock
        err_json "read_error"
    fi
    _unlock
    ok_json "{\"ok\":true,\"code\":\"$CODE\"}"
fi

# ================================================================
# GET ?action=nodemcus_get
# Full merged registry (primary + extras) for the NodeMCUs admin page.
# ================================================================
if echo "$QS" | $BB grep -q "action=nodemcus_get"; then
    load_coin_env
    N1_TITLE="${NODEMCU_1_TITLE:-$(read_lmehspt_var NODEMCU_1_TITLE)}"
    N1_EN="${NODEMCU_1_ENABLED:-$(read_lmehspt_var NODEMCU_1_ENABLED)}"
    N1_IP="${NODEMCU_IP:-$(read_lmehspt_var NODEMCU_IP)}"
    N1_MAC="${NODEMCU_MAC:-$(read_lmehspt_var NODEMCU_MAC)}"
    N1_PORT="${NODEMCU_PORT:-$(read_lmehspt_var NODEMCU_PORT)}"
    N1_PSK="${COIN_PSK:-$(read_lmehspt_var COIN_PSK)}"
    N1_EN_BOOL="true"; [ "${N1_EN:-1}" = "0" ] && N1_EN_BOOL="false"

    # Build "id<TAB>{json}" rows for every unit, then emit them in the saved
    # display order (nodemcus_order.txt). The primary (#1) is only included
    # while it is still configured - after a primary delete its IP and MAC are
    # both cleared, and that empty state is the signal that there is no primary
    # any more (so it drops out of the table entirely).
    NM_MAP="/tmp/nm_map.$$"
    : > "$NM_MAP"
    if [ -n "$N1_IP" ] || [ -n "$N1_MAC" ]; then
        printf '1\t{"id":1,"title":"%s","ip":"%s","mac":"%s","port":"%s","psk":"%s","enabled":%s,"primary":true}\n' \
            "$(esc_json "${N1_TITLE:-Coin Slot}")" "$(esc_json "$N1_IP")" "$(esc_json "$N1_MAC")" "$(esc_json "$N1_PORT")" "$(esc_json "$N1_PSK")" "$N1_EN_BOOL" >> "$NM_MAP"
    fi

    if [ -f "$NODEMCU_EXTRA_FILE" ]; then
        while IFS='|' read -r nid ntitle nip nmac nport npsk nen; do
            case "$nid" in ''|*[!0-9]*) continue ;; esac
            EN_BOOL="true"; [ "${nen:-1}" = "0" ] && EN_BOOL="false"
            printf '%s\t{"id":%s,"title":"%s","ip":"%s","mac":"%s","port":"%s","psk":"%s","enabled":%s,"primary":false}\n' \
                "$nid" "$nid" "$(esc_json "$ntitle")" "$(esc_json "$nip")" "$(esc_json "$nmac")" "$(esc_json "$nport")" "$(esc_json "$npsk")" "$EN_BOOL" >> "$NM_MAP"
        done < "$NODEMCU_EXTRA_FILE"
    fi

    OUT=$($BB awk -F'\t' -v orderfile="$NODEMCU_ORDER_FILE" '
        BEGIN{
            n=0;
            while((getline l < orderfile) > 0){ gsub(/[^0-9]/,"",l); if(l!="") ord[n++]=l; }
            close(orderfile);
        }
        { obj[$1]=$2; nat[nn++]=$1; have[$1]=1; }
        END{
            out=""; sep="";
            for(i=0;i<n;i++){ id=ord[i]; if(have[id] && !done[id]){ out=out sep obj[id]; sep=","; done[id]=1; } }
            for(i=0;i<nn;i++){ id=nat[i]; if(!done[id]){ out=out sep obj[id]; sep=","; done[id]=1; } }
            printf "[%s]", out;
        }' "$NM_MAP")
    rm -f "$NM_MAP"
    NMAX=$(_nodemcu_pool_size)
    ok_json "{\"ok\":true,\"nodemcus\":${OUT},\"max_nodemcus\":$NMAX}"
fi

# ================================================================
# POST ?action=nodemcu_reorder  body: order=1,3,2
# Persists the display order shared by the NodeMCUs admin table and the
# captive portal's coin-slot picker (coin.sh reads the same file). Any id not
# listed here falls back to its natural position (primary first, then the
# extras file), so a partial list can never drop a unit.
# ================================================================
if echo "$QS" | $BB grep -q "action=nodemcu_reorder"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    ORD=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*order=\([^&]*\).*/\1/p' | urldecode)
    mkdir -p "$HDATA"
    printf '%s' "$ORD" | $BB tr ',' '\n' | $BB tr -cd '0-9\n' | $BB grep -v '^$' > "${NODEMCU_ORDER_FILE}.tmp" 2>/dev/null
    $BB mv "${NODEMCU_ORDER_FILE}.tmp" "$NODEMCU_ORDER_FILE" 2>/dev/null
    sync
    ok_json "{\"ok\":true}"
fi
# ================================================================
# POST ?action=nodemcu_add  body: title,ip,mac,port,psk,enabled
# Adds an additional coin acceptor unit (#2+). The primary (#1) is managed
# through action=config_set above, not here.
# ================================================================
if echo "$QS" | $BB grep -q "action=nodemcu_add"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    NTITLE=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*title=\([^&]*\).*/\1/p' | urldecode | $BB tr -d '|\r\n')
    NMACV=$(printf '%s'  "$POST_DATA" | $BB sed -n 's/.*mac=\([^&]*\).*/\1/p'   | urldecode | $BB tr 'A-F' 'a-f' | $BB tr -cd '0-9a-f')
    NPSKV=$(printf '%s'  "$POST_DATA" | $BB sed -n 's/.*psk=\([^&]*\).*/\1/p'   | urldecode | $BB tr -d '|\r\n')
    NENV=$(printf '%s'   "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')

    NTITLE=$(env_text_san "$NTITLE"); NTITLE=$(printf '%s' "$NTITLE" | $BB cut -c1-64)
    [ -z "$NTITLE" ] && NTITLE="Coin Slot"
    printf '%s' "$NMACV" | grep -qE '^[0-9a-f]{12}$' || err_json "invalid_mac"
    [ -z "$NPSKV" ]  && err_json "missing_psk"
    # PSK is a shared secret: never silently alter it, refuse unsafe characters
    # instead (they would corrupt/inject into the sourced env files).
    env_val_safe "$NPSKV" && [ "${#NPSKV}" -le 127 ] || err_json "invalid_psk"
    [ "$NENV" = "0" ] && NENV=0 || NENV=1
    NPORTV=8080   # fixed: NodeMCU firmware always listens on 8080
    load_coin_env
    # IP is auto-assigned from the pool below the DHCP start; adding is refused
    # once every usable address is taken (that cap IS the NodeMCU limit).
    NIPV=$(_next_free_nodemcu_ip)
    [ -z "$NIPV" ] && err_json "pool_full"

    mkdir -p "$HDATA"; touch "$NODEMCU_EXTRA_FILE"

    _lock
    NEXT_ID=$($BB awk -F'|' '$1 ~ /^[0-9]+$/ && $1+0>m{m=$1+0} END{print m+0}' "$NODEMCU_EXTRA_FILE" 2>/dev/null)
    [ -z "$NEXT_ID" ] && NEXT_ID=0
    [ "$NEXT_ID" -lt 1 ] && NEXT_ID=1
    NEXT_ID=$(( NEXT_ID + 1 ))

    printf '%s|%s|%s|%s|%s|%s|%s\n' "$NEXT_ID" "$NTITLE" "$NIPV" "$NMACV" "$NPORTV" "$NPSKV" "$NENV" >> "$NODEMCU_EXTRA_FILE"
    sync
    _unlock

    # Apply immediately: static DHCP lease + FORWARD isolation for the new
    # unit — same live-apply "source lmehspt.sh --lib" pattern config_set
    # already uses above for the primary node's IP/MAC changes.
    LMEHSPT_LIB_ONLY=1
    . /lmepisowifi/lmehspt.sh --lib
    [ -f /tmp/hotspot_dhcp.pid ] && kill -9 "$(cat /tmp/hotspot_dhcp.pid)" 2>/dev/null
    # This unit's MAC almost always already holds a DYNAMIC lease from before
    # it was registered here — seeing it associate with SOME address is
    # usually how its MAC got noticed in the first place. busybox udhcpd
    # keeps re-issuing whatever a MAC's existing leases-file entry says
    # regardless of the static_lease line we just added, so wipe the lease
    # DB before restarting: same fix apply_portal_ip_change relies on for
    # subnet changes.
    rm -f /tmp/udhcpd.leases
    start_dhcp
    apply_extra_nodemcu_fw
    # Flush any stale kernel ARP entry for the pool IP we just assigned —
    # _next_free_nodemcu_ip() hands out the lowest free address in the pool,
    # which may well have belonged to some OTHER device before (a removed
    # NodeMCU, or a customer's dynamic lease before this address fell inside
    # the reserved range). Without this, coin_result.sh's Guard 2 (ARP-based
    # MAC verification) keeps matching the OLD MAC still cached for this IP
    # and rejects every coin POST from the brand-new unit with "MAC
    # mismatch" until the cache entry ages out on its own — which in
    # practice meant "reboot the router" to get a newly-added NodeMCU
    # working. Same fix nodemcu_edit/config_set already apply on their own
    # IP changes just below.
    ip neigh del "$NIPV" dev "$HOTSPOT_BR" 2>/dev/null
    $BB arp -d "$NIPV" 2>/dev/null
    # Force this unit to drop its current association so it re-DHCPs right
    # away instead of sitting on its old address until its own lease/renewal
    # timer happens to fire. Only this MAC is kicked — other connected
    # customers on wlan1 are untouched.
    kick_sta_mac "$NMACV"
    ping -c 1 -W 1 "$NIPV" >/dev/null 2>&1

    ok_json "{\"ok\":true,\"id\":$NEXT_ID}"
fi

# ================================================================
# POST ?action=nodemcu_edit  body: id,title,ip,mac,port,psk,enabled
# ================================================================
if echo "$QS" | $BB grep -q "action=nodemcu_edit"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    NID=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*id=\([^&]*\).*/\1/p' | $BB tr -cd '0-9')
    [ -z "$NID" ] && err_json "missing_id"

    NTITLE=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*title=\([^&]*\).*/\1/p' | urldecode | $BB tr -d '|\r\n')
    NMACV=$(printf '%s'  "$POST_DATA" | $BB sed -n 's/.*mac=\([^&]*\).*/\1/p'   | urldecode | $BB tr 'A-F' 'a-f' | $BB tr -cd '0-9a-f')
    NPSKV=$(printf '%s'  "$POST_DATA" | $BB sed -n 's/.*psk=\([^&]*\).*/\1/p'   | urldecode | $BB tr -d '|\r\n')
    NENV=$(printf '%s'   "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')

    NTITLE=$(env_text_san "$NTITLE"); NTITLE=$(printf '%s' "$NTITLE" | $BB cut -c1-64)
    printf '%s' "$NMACV" | grep -qE '^[0-9a-f]{12}$' || err_json "invalid_mac"
    [ -z "$NPSKV" ]  && err_json "missing_psk"
    env_val_safe "$NPSKV" && [ "${#NPSKV}" -le 127 ] || err_json "invalid_psk"
    [ "$NENV" = "0" ] && NENV=0 || NENV=1
    NPORTV=8080   # fixed: NodeMCU firmware always listens on 8080
    load_coin_env

    # The IP is auto-assigned (from the DHCP pool at add time) and is NOT
    # user-editable, so an edit keeps whatever IP the unit already holds.

    # ---- Primary (#1): config vars, not the extras file ----
    if [ "$NID" = "1" ]; then
        [ -z "$NTITLE" ] && NTITLE="Coin Slot"
        OLD_NIP=$(read_lmehspt_var NODEMCU_IP)
        OLD_NMC=$(read_lmehspt_var NODEMCU_MAC)
        OLD_NEN=$(read_lmehspt_var NODEMCU_1_ENABLED)

        # NODEMCU_IP is intentionally left untouched.
        for _kv in "NODEMCU_MAC=$NMACV" "NODEMCU_PORT=$NPORTV" "NODEMCU_1_TITLE=$NTITLE" "NODEMCU_1_ENABLED=$NENV" "COIN_PSK=$NPSKV"; do
            _k=${_kv%%=*}; _v=${_kv#*=}
            save_coin_env_var "$_k" "$_v"
            set_lmehspt_var  "$_k" "$_v"
            set_globals_var  "$_k" "$_v"
        done

        NEW_NMC=$(read_lmehspt_var NODEMCU_MAC)
        NEW_NEN=$(read_lmehspt_var NODEMCU_1_ENABLED)
        if [ "$OLD_NMC" != "$NEW_NMC" ] || [ "${OLD_NEN:-1}" != "${NEW_NEN:-1}" ]; then
            [ -f /tmp/hotspot_dhcp.pid ] && kill -9 "$(cat /tmp/hotspot_dhcp.pid)" 2>/dev/null
            load_coin_env
            LMEHSPT_LIB_ONLY=1
            . /lmepisowifi/lmehspt.sh --lib
            rm -f /tmp/udhcpd.leases
            start_dhcp
            ip neigh del "$OLD_NIP" dev "$HOTSPOT_BR" 2>/dev/null
            $BB arp -d "$OLD_NIP" 2>/dev/null
            kick_sta_mac "$NEW_NMC"
            ping -c 1 -W 1 "$OLD_NIP" >/dev/null 2>&1
        fi
        touch /tmp/hotspot_qos_reload
        ok_json "{\"ok\":true}"
    fi

    # ---- Additional units (#2+): rows in NODEMCU_EXTRA_FILE ----
    [ -z "$NTITLE" ] && NTITLE="Coin Slot $NID"
    [ -f "$NODEMCU_EXTRA_FILE" ] && $BB grep -q "^${NID}|" "$NODEMCU_EXTRA_FILE" || err_json "not_found"

    _lock
    OLD_ROW=$($BB grep "^${NID}|" "$NODEMCU_EXTRA_FILE" | head -1)
    OLD_IPV=$(printf '%s' "$OLD_ROW" | awk -F'|' '{print $3}')
    OLD_MACV=$(printf '%s' "$OLD_ROW" | awk -F'|' '{print $4}')
    NIPV="$OLD_IPV"   # keep the unit's existing (auto-assigned) IP

    NM_RC=0
    $BB grep -v "^${NID}|" "$NODEMCU_EXTRA_FILE" > /tmp/nm_edit.tmp 2>/dev/null || NM_RC=$?
    if [ "$NM_RC" -gt 1 ]; then
        rm -f /tmp/nm_edit.tmp 2>/dev/null
        _unlock
        err_json "read_error"
    fi
    printf '%s|%s|%s|%s|%s|%s|%s\n' "$NID" "$NTITLE" "$NIPV" "$NMACV" "$NPORTV" "$NPSKV" "$NENV" >> /tmp/nm_edit.tmp
    $BB mv /tmp/nm_edit.tmp "$NODEMCU_EXTRA_FILE"
    sync
    _unlock

    LMEHSPT_LIB_ONLY=1
    . /lmepisowifi/lmehspt.sh --lib
    [ -f /tmp/hotspot_dhcp.pid ] && kill -9 "$(cat /tmp/hotspot_dhcp.pid)" 2>/dev/null
    rm -f /tmp/udhcpd.leases
    start_dhcp
    apply_extra_nodemcu_fw
    ip neigh del "$NIPV" dev "$HOTSPOT_BR" 2>/dev/null
    $BB arp -d "$NIPV" 2>/dev/null
    if [ "$OLD_MACV" != "$NMACV" ]; then
        kick_sta_mac "$NMACV"
    fi
    ping -c 1 -W 1 "$NIPV" >/dev/null 2>&1

    ok_json "{\"ok\":true}"
fi

# ================================================================
# GET ?action=dhcp_get  -> gateway, DHCP range, DNS, NodeMCU pool info
# ================================================================
if echo "$QS" | $BB grep -q "action=dhcp_get"; then
    load_coin_env
    D_PIP="${PORTAL_IP:-$(read_lmehspt_var PORTAL_IP)}"
    D_PFX=$(_dhcp_prefix)
    D_DS=$(_dhcp_start_octet)
    D_DE="${DHCP_END:-$(read_lmehspt_var DHCP_END)}"; case "$D_DE" in ''|*[!0-9]*) D_DE=254 ;; esac
    D_DNS="${DHCP_DNS:-$(read_lmehspt_var DHCP_DNS)}"; [ -z "$D_DNS" ] && D_DNS="1.1.1.1"
    D_MAX=$(_nodemcu_pool_size)
    D_CNT=$(_nodemcu_count)
    D_POOL=$(_nodemcu_pool_ips | $BB awk 'BEGIN{s="";sep=""}{s=s sep "\"" $0 "\"";sep=","}END{printf "[%s]", s}')
    ok_json "{\"ok\":true,\"gateway\":\"$(esc_json "$D_PIP")\",\"prefix\":\"$(esc_json "$D_PFX")\",\"dhcp_start\":\"$(esc_json "$D_PFX.$D_DS")\",\"dhcp_end\":\"$(esc_json "$D_PFX.$D_DE")\",\"dns\":\"$(esc_json "$D_DNS")\",\"nodemcu_pool\":$D_POOL,\"max_nodemcus\":$D_MAX,\"nodemcu_count\":$D_CNT}"
fi

# ================================================================
# POST ?action=dhcp_set  body: gateway, dhcp_start, dhcp_end, dns
# Writes the gateway (PORTAL_IP), the dynamic DHCP range, and DNS servers, then
# re-normalises every NodeMCU into the (possibly moved) usable pool and applies
# live. A gateway move reuses the portal-IP reload path (full rebuild); a
# range/DNS-only change uses the lighter hotspot_dhcp_reload path.
# ================================================================
if echo "$QS" | $BB grep -q "action=dhcp_set"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    dget() { printf '%s' "$POST_DATA" | $BB tr '&' '\n' | $BB grep "^$1=" | $BB sed 's/^[^=]*=//' | urldecode | head -1; }
    D_GW=$(dget gateway    | $BB tr -cd '0-9.')
    D_S=$(dget dhcp_start  | $BB tr -cd '0-9.')
    D_E=$(dget dhcp_end    | $BB tr -cd '0-9.')
    D_DNS_RAW=$(dget dns)

    _valid_ipv4 "$D_GW" || err_json "bad_gateway"
    _valid_ipv4 "$D_S"  || err_json "bad_dhcp_start"
    _valid_ipv4 "$D_E"  || err_json "bad_dhcp_end"

    NEW_PFX=$(printf '%s' "$D_GW" | $BB sed 's/\.[^.]*$//')
    GW_OCT=$(printf '%s'  "$D_GW" | $BB sed 's/.*\.//')
    S_PFX=$(printf '%s'   "$D_S"  | $BB sed 's/\.[^.]*$//'); S_OCT=$(printf '%s' "$D_S" | $BB sed 's/.*\.//')
    E_PFX=$(printf '%s'   "$D_E"  | $BB sed 's/\.[^.]*$//'); E_OCT=$(printf '%s' "$D_E" | $BB sed 's/.*\.//')

    [ "$S_PFX" = "$NEW_PFX" ] && [ "$E_PFX" = "$NEW_PFX" ] || err_json "range_wrong_subnet"
    [ "$GW_OCT" -ge 1 ] && [ "$GW_OCT" -le 254 ] || err_json "bad_gateway"
    [ "$S_OCT" -gt "$GW_OCT" ] || err_json "start_le_gateway"
    [ "$S_OCT" -le "$E_OCT" ]  || err_json "start_gt_end"
    [ "$E_OCT" -le 254 ]       || err_json "end_out_of_range"

    load_coin_env
    OLD_PIP=$(read_lmehspt_var PORTAL_IP)
    OLD_PPT=$(read_lmehspt_var PORTAL_PORT)

    NEW_POOL=$(( S_OCT - GW_OCT - 1 )); [ "$NEW_POOL" -lt 0 ] && NEW_POOL=0
    CUR_CNT=$(_nodemcu_count)
    if [ "$CUR_CNT" -gt "$NEW_POOL" ]; then
        ok_json "{\"ok\":false,\"error\":\"pool_too_small\",\"max\":$NEW_POOL,\"count\":$CUR_CNT}"
    fi

    # Normalise DNS: commas/newlines -> spaces, keep only valid IPv4 tokens.
    D_DNS=$(printf '%s' "$D_DNS_RAW" | $BB tr ',\r\n' '   ' | $BB tr -s ' ')
    _dns_ok=""
    for _d in $D_DNS; do _valid_ipv4 "$_d" && _dns_ok="${_dns_ok:+$_dns_ok }$_d"; done
    [ -z "$_dns_ok" ] && _dns_ok="1.1.1.1"
    D_DNS="$_dns_ok"

    for _kv in "DHCP_START=$S_OCT" "DHCP_END=$E_OCT" "DHCP_DNS=$D_DNS"; do
        _k=${_kv%%=*}; _v=${_kv#*=}
        save_coin_env_var "$_k" "$_v"; set_lmehspt_var "$_k" "$_v"; set_globals_var "$_k" "$_v"
    done

    GW_CHANGED=0; [ "$D_GW" != "$OLD_PIP" ] && GW_CHANGED=1
    if [ "$GW_CHANGED" = "1" ]; then
        save_coin_env_var PORTAL_IP "$D_GW"; set_lmehspt_var PORTAL_IP "$D_GW"; set_globals_var PORTAL_IP "$D_GW"
    fi

    # Update in-memory values so the pool helpers compute against the NEW
    # gateway/start when re-normalising the NodeMCU IPs.
    PORTAL_IP="$D_GW"; DHCP_START="$S_OCT"; DHCP_END="$E_OCT"
    _dhcp_renormalize_ips

    if hotspot_running; then
        if [ "$GW_CHANGED" = "1" ]; then
            printf '%s\n' "$D_GW"    > /tmp/hotspot_portal_ip_new
            printf '%s\n' "$OLD_PPT" > /tmp/hotspot_portal_port_new
            printf '%s\n' "$OLD_PIP" > /tmp/hotspot_portal_ip_old
            printf '%s\n' "$OLD_PPT" > /tmp/hotspot_portal_port_old
            touch /tmp/hotspot_portal_ip_reload
        else
            touch /tmp/hotspot_dhcp_reload
        fi
    fi
    ok_json "{\"ok\":true,\"max_nodemcus\":$NEW_POOL}"
fi

# ================================================================
# GET ?action=dhcp_leases  -> current dynamic DHCP leases on the hotspot
# subnet (NOT NodeMCU/static units — see the NodeMCUs page for those).
# Reads via `busybox dumpleases`, the same binary that wrote the file, so
# this is immune to guessing the on-disk struct layout.
# ================================================================
if echo "$QS" | $BB grep -q "action=dhcp_leases"; then
    if ! _bb_has dumpleases; then
        ok_json "{\"ok\":true,\"supported\":false,\"leases\":[]}"
    fi
    load_coin_env
    OUT="["; SEP=""
    if [ -s "$LEASES_FILE" ]; then
        STATIC_MACS=$(_static_lease_macs)
        $BB dumpleases -r -d -f "$LEASES_FILE" 2>/dev/null \
            | $BB grep -E '^([0-9a-f]{2}:){5}[0-9a-f]{2}[[:space:]]' \
            > /tmp/dhcp_leases_dump.tmp
        while IFS= read -r LN; do
            LMAC=$(printf '%s' "$LN" | $BB awk '{print $1}')
            LMAC_HEX=$(printf '%s' "$LMAC" | $BB tr -d ':')
            printf '%s\n' "$STATIC_MACS" | $BB grep -qx "$LMAC_HEX" && continue
            LIP=$(printf '%s' "$LN" | $BB awk '{print $2}')
            LTAIL=$(printf '%s' "$LN" | $BB awk '{print $NF}')
            case "$LTAIL" in
                expired)   LREM=0; LEXP=true ;;
                *[!0-9]*)  continue ;;
                *)         LREM=$LTAIL; LEXP=false ;;
            esac
            OUT="${OUT}${SEP}{\"mac\":\"$(esc_json "$LMAC")\",\"ip\":\"$(esc_json "$LIP")\",\"remaining\":$LREM,\"expired\":$LEXP}"
            SEP=","
        done < /tmp/dhcp_leases_dump.tmp
        rm -f /tmp/dhcp_leases_dump.tmp
    fi
    ok_json "{\"ok\":true,\"supported\":true,\"leases\":${OUT}]}"
fi

# ================================================================
# POST ?action=dhcp_lease_renew   body: mac, minutes
# Extends one lease's expiry and restarts udhcpd so it takes effect —
# busybox udhcpd only reads the lease file at startup, so an on-disk-only
# edit would get silently overwritten by the daemon's own next flush.
# Only the matched record's 4-byte "expires" field is modified; every
# other byte (and every other lease) is copied through untouched, and the
# target MAC is cross-checked against `dumpleases` before anything is
# written, so a layout surprise on some other busybox build fails safely
# ("not_found"/"unsupported") instead of corrupting the file. No station
# kick here on purpose — the device's association is undisturbed, only
# the server-side timer for its lease resets.
# ================================================================
if echo "$QS" | $BB grep -q "action=dhcp_lease_renew"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    RMAC=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*mac=\([^&]*\).*/\1/p' | urldecode | $BB tr 'A-Z' 'a-z' | $BB tr -cd 'a-f0-9:')
    RMIN=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*minutes=\([^&]*\).*/\1/p' | $BB tr -cd '0-9')
    case "$RMAC" in
        [0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]) ;;
        *) err_json "bad_mac" ;;
    esac
    [ -z "$RMIN" ] && err_json "missing_minutes"
    [ "$RMIN" -le 0 ] 2>/dev/null && err_json "bad_minutes"

    _bb_has dumpleases && _bb_has dd && _bb_has od || err_json "unsupported"
    [ -s "$LEASES_FILE" ] || err_json "not_found"
    H=$(_lease_header_size)
    [ "$H" = "8" ] || err_json "unsupported"   # relative-expiry math needs the written_at header

    $BB dumpleases -f "$LEASES_FILE" 2>/dev/null | $BB grep -q "^$RMAC[[:space:]]" || err_json "not_found"

    RMAC_HEX=$(printf '%s' "$RMAC" | $BB tr -d ':')
    FSZ=$($BB wc -c < "$LEASES_FILE"); N=$(( (FSZ - H) / LEASE_REC_SIZE ))
    IDX=-1; _ri=0
    while [ "$_ri" -lt "$N" ]; do
        _roff=$(( H + _ri * LEASE_REC_SIZE ))
        [ "$(_read_mac_hex "$LEASES_FILE" $(( _roff + 8 )))" = "$RMAC_HEX" ] && { IDX=$_ri; break; }
        _ri=$(( _ri + 1 ))
    done
    [ "$IDX" -ge 0 ] || err_json "not_found"

    _dhcp_lease_lock
    HI=$(_read_be32 "$LEASES_FILE" 0)
    WRITTEN_AT=$(_read_be32 "$LEASES_FILE" 4)
    if [ "$HI" != "0" ] || [ -z "$WRITTEN_AT" ]; then
        _dhcp_lease_unlock; err_json "unreadable_lease_file"
    fi
    NOW=$($BB date +%s)
    NEWVAL=$(( RMIN * 60 + (NOW - WRITTEN_AT) ))
    [ "$NEWVAL" -lt 0 ] && NEWVAL=$(( RMIN * 60 ))
    _write_be32 "$LEASES_FILE" "$(( H + IDX * LEASE_REC_SIZE ))" "$NEWVAL"

    load_coin_env
    LMEHSPT_LIB_ONLY=1
    . /lmepisowifi/lmehspt.sh --lib
    _dhcp_restart_preserving_leases
    _dhcp_lease_unlock

    ok_json "{\"ok\":true}"
fi

# ================================================================
# POST ?action=dhcp_lease_delete   body: mac
# Drops one lease record entirely (freeing its IP for reuse) and restarts
# udhcpd so it takes effect, then kicks the station off wifi so the
# device actually loses its connection rather than quietly keeping an IP
# the server no longer remembers. Every other lease is copied through
# byte-for-byte untouched — delete doesn't need to interpret the record
# at all beyond its length, so (unlike renew) it works even on the older
# no-header lease format.
# ================================================================
if echo "$QS" | $BB grep -q "action=dhcp_lease_delete"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    DMAC=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*mac=\([^&]*\).*/\1/p' | urldecode | $BB tr 'A-Z' 'a-z' | $BB tr -cd 'a-f0-9:')
    case "$DMAC" in
        [0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]) ;;
        *) err_json "bad_mac" ;;
    esac

    _bb_has dumpleases && _bb_has dd && _bb_has od || err_json "unsupported"
    [ -s "$LEASES_FILE" ] || err_json "not_found"
    H=$(_lease_header_size)
    [ -n "$H" ] || err_json "unsupported"

    DIP=$($BB dumpleases -f "$LEASES_FILE" 2>/dev/null | $BB awk -v m="$DMAC" '$1==m{print $2; exit}')
    [ -n "$DIP" ] || err_json "not_found"

    DMAC_HEX=$(printf '%s' "$DMAC" | $BB tr -d ':')
    FSZ=$($BB wc -c < "$LEASES_FILE"); N=$(( (FSZ - H) / LEASE_REC_SIZE ))
    IDX=-1; _di=0
    while [ "$_di" -lt "$N" ]; do
        _doff=$(( H + _di * LEASE_REC_SIZE ))
        [ "$(_read_mac_hex "$LEASES_FILE" $(( _doff + 8 )))" = "$DMAC_HEX" ] && { IDX=$_di; break; }
        _di=$(( _di + 1 ))
    done
    [ "$IDX" -ge 0 ] || err_json "not_found"

    _dhcp_lease_lock
    rm -f /tmp/udhcpd_leases.tmp
    [ "$H" -gt 0 ] && $BB dd if="$LEASES_FILE" of=/tmp/udhcpd_leases.tmp bs=1 count="$H" 2>/dev/null
    _di=0
    while [ "$_di" -lt "$N" ]; do
        if [ "$_di" -ne "$IDX" ]; then
            $BB dd if="$LEASES_FILE" bs=1 skip=$(( H + _di * LEASE_REC_SIZE )) count="$LEASE_REC_SIZE" 2>/dev/null >> /tmp/udhcpd_leases.tmp
        fi
        _di=$(( _di + 1 ))
    done
    $BB mv /tmp/udhcpd_leases.tmp "$LEASES_FILE"

    load_coin_env
    LMEHSPT_LIB_ONLY=1
    . /lmepisowifi/lmehspt.sh --lib
    _dhcp_restart_preserving_leases
    ip neigh del "$DIP" dev "$HOTSPOT_BR" 2>/dev/null
    $BB arp -d "$DIP" 2>/dev/null
    kick_sta_mac "$DMAC"
    ping -c 1 -W 1 "$DIP" >/dev/null 2>&1
    _dhcp_lease_unlock

    ok_json "{\"ok\":true}"
fi

# ================================================================
# POST ?action=nodemcu_del  body: id
# ================================================================
if echo "$QS" | $BB grep -q "action=nodemcu_del"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    NID=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*id=\([^&]*\).*/\1/p' | $BB tr -cd '0-9')
    [ -z "$NID" ] && err_json "missing_id"

    # ---- Deleting the primary (#1): there is no separate row to drop, so wipe
    # its config vars. No promotion happens - the box is simply left with no
    # primary coin acceptor until one is configured again (the "allow empty"
    # behaviour chosen for this build). ----
    if [ "$NID" = "1" ]; then
        load_coin_env
        OLD_NIP=$(read_lmehspt_var NODEMCU_IP)
        for _k in NODEMCU_IP NODEMCU_MAC NODEMCU_1_TITLE COIN_PSK; do
            save_coin_env_var "$_k" ""
            set_lmehspt_var  "$_k" ""
            set_globals_var  "$_k" ""
        done
        save_coin_env_var "NODEMCU_1_ENABLED" "0"
        set_lmehspt_var  "NODEMCU_1_ENABLED" "0"
        set_globals_var  "NODEMCU_1_ENABLED" "0"

        [ -f /tmp/hotspot_dhcp.pid ] && kill -9 "$(cat /tmp/hotspot_dhcp.pid)" 2>/dev/null
        load_coin_env
        LMEHSPT_LIB_ONLY=1
        . /lmepisowifi/lmehspt.sh --lib
        rm -f /tmp/udhcpd.leases
        start_dhcp
        if [ -n "$OLD_NIP" ]; then
            ip neigh del "$OLD_NIP" dev "$HOTSPOT_BR" 2>/dev/null
            $BB arp -d "$OLD_NIP" 2>/dev/null
        fi
        touch /tmp/hotspot_qos_reload
        _order_remove_id "1"
        ok_json "{\"ok\":true,\"id\":1}"
    fi

    _lock
    if [ -f "$NODEMCU_EXTRA_FILE" ] && ! _nodemcu_file_replace_excl "$NID"; then
        _unlock
        err_json "read_error"
    fi
    _unlock

    load_coin_env
    LMEHSPT_LIB_ONLY=1
    . /lmepisowifi/lmehspt.sh --lib
    [ -f /tmp/hotspot_dhcp.pid ] && kill -9 "$(cat /tmp/hotspot_dhcp.pid)" 2>/dev/null
    rm -f /tmp/udhcpd.leases
    start_dhcp
    apply_extra_nodemcu_fw

    _order_remove_id "$NID"
    ok_json "{\"ok\":true,\"id\":$NID}"
fi
# ================================================================
# POST ?action=voucher_toggle  body: enabled=1|0
# Master switch for voucher code redemption (see login.sh). When off,
# login.sh refuses all new voucher submissions with "voucher_disabled" and
# the portal hides the voucher-code input entirely — same shape as
# coin_toggle below, but persisted the three-way way (coin_config.env +
# lmehspt.sh + globals.env) like voucher_strike_set, so the setting
# actually survives a hotspot restart/reboot.
# ================================================================
if echo "$QS" | $BB grep -q "action=voucher_toggle"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    VAL=$($BB echo "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')
    if [ "$VAL" = "1" ]; then
        save_coin_env_var "VOUCHER_ENABLED" "1"
        set_lmehspt_var   "VOUCHER_ENABLED" "1"
        set_globals_var   "VOUCHER_ENABLED" "1"
        ok_json "{\"ok\":true,\"voucher_on\":true}"
    elif [ "$VAL" = "0" ]; then
        save_coin_env_var "VOUCHER_ENABLED" "0"
        set_lmehspt_var   "VOUCHER_ENABLED" "0"
        set_globals_var   "VOUCHER_ENABLED" "0"
        ok_json "{\"ok\":true,\"voucher_on\":false}"
    else
        err_json "bad_value"
    fi
fi

# ================================================================
# POST ?action=coin_toggle  body: enabled=1|0
# ================================================================
if echo "$QS" | $BB grep -q "action=coin_toggle"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    VAL=$($BB echo "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')
    if [ "$VAL" = "1" ]; then
        touch /tmp/coin_enabled
        save_coin_env_var "COIN_ENABLED" "1"
        set_lmehspt_var "COIN_ENABLED" "1"
        ok_json "{\"ok\":true,\"coin_on\":true}"
    else
        rm -f /tmp/coin_enabled
        save_coin_env_var "COIN_ENABLED" "0"
        set_lmehspt_var "COIN_ENABLED" "0"
        ok_json "{\"ok\":true,\"coin_on\":false}"
    fi
fi

# ================================================================
# POST ?action=lan_isolate_set   body: enabled=1|0
# Instantly applies or removes LAN isolation rules for both the hotspot
# bridge (br1) and the repurposed WAN interface (if currently active).
# Saves the new value to coin_config.env, lmehspt.sh, and globals.env so
# the watchdog picks it up on its next tick.
# ================================================================
if echo "$QS" | $BB grep -q "action=lan_isolate_set"; then
    read -n "${CONTENT_LENGTH:-0}" POST_DATA
    VAL=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')
    load_coin_env
    HBR="${HOTSPOT_BR:-$(read_lmehspt_var HOTSPOT_BR)}"
    HBR="${HBR:-br1}"
    _W2P="8080"
    # Resolve repurposed WAN interface(s) — /tmp/repurpose_active is a
    # shared registry, one interface per line, since multiple interfaces
    # can be repurposed as DHCP-client WAN at once (empty when the feature
    # is not active for any interface).
    _RWAN_LIST=$($BB cat /tmp/repurpose_active 2>/dev/null | $BB grep -E '^[a-z0-9._-]+$')
    if [ "$VAL" = "1" ]; then
        # ── Enable: apply hotspot isolation ──────────────────────────────────
        _old_lan=$(cat /tmp/hotspot_lan_isolate.mark 2>/dev/null)
        [ -n "$_old_lan" ] && iptables -t filter -D FORWARD -i "$HBR" -d "$_old_lan" -j DROP 2>/dev/null
        _lan_gw=$($BB route -n 2>/dev/null | $BB awk 'NR>1&&$1=="0.0.0.0"&&$2!="0.0.0.0"{print $2;exit}')
        [ -z "$_lan_gw" ] && _lan_gw="192.168.18.1"
        _lan_subnet=$(printf '%s' "$_lan_gw" | $BB sed 's/\.[^.]*$/.0\/24/')
        iptables -t filter -I FORWARD 1 -i "$HBR" -d "$_lan_subnet" -j DROP
        printf '%s\n' "$_lan_subnet" > /tmp/hotspot_lan_isolate.mark
        iptables -t filter -D INPUT -i "$HBR" -p tcp --dport "$_W2P" -j ACCEPT 2>/dev/null
        iptables -t filter -I INPUT 1 -i "$HBR" -p tcp --dport "$_W2P" -j ACCEPT
        # ── Enable: apply repurposed WAN isolation (for every active iface) ───
        if [ -n "$_RWAN_LIST" ]; then
            echo "$_RWAN_LIST" | while IFS= read -r _rwan; do
                [ -z "$_rwan" ] && continue
                iptables -t filter -D FORWARD -i "$_rwan" -o br0 -j DROP 2>/dev/null
                iptables -t filter -I FORWARD 1 -i "$_rwan" -o br0 -j DROP
                iptables -t filter -D INPUT -i "$_rwan" -p tcp --dport "$_W2P" -j ACCEPT 2>/dev/null
                iptables -t filter -I INPUT 1 -i "$_rwan" -p tcp --dport "$_W2P" -j ACCEPT
            done
        fi
        save_coin_env_var "LAN_ISOLATE" "1"
        set_lmehspt_var   "LAN_ISOLATE" "1"
        set_globals_var   "LAN_ISOLATE" "1"
        ok_json '{"ok":true,"lan_isolate":true}'
    else
        # ── Disable: remove hotspot isolation ────────────────────────────────
        _old_lan=$(cat /tmp/hotspot_lan_isolate.mark 2>/dev/null)
        [ -n "$_old_lan" ] && iptables -t filter -D FORWARD -i "$HBR" -d "$_old_lan" -j DROP 2>/dev/null
        rm -f /tmp/hotspot_lan_isolate.mark
        iptables -t filter -D INPUT -i "$HBR" -p tcp --dport "$_W2P" -j ACCEPT 2>/dev/null
        # ── Disable: remove repurposed WAN isolation (for every active iface) ─
        if [ -n "$_RWAN_LIST" ]; then
            echo "$_RWAN_LIST" | while IFS= read -r _rwan; do
                [ -z "$_rwan" ] && continue
                iptables -t filter -D FORWARD -i "$_rwan" -o br0 -j DROP 2>/dev/null
                iptables -t filter -D INPUT -i "$_rwan" -p tcp --dport "$_W2P" -j ACCEPT 2>/dev/null
            done
        fi
        save_coin_env_var "LAN_ISOLATE" "0"
        set_lmehspt_var   "LAN_ISOLATE" "0"
        set_globals_var   "LAN_ISOLATE" "0"
        ok_json '{"ok":true,"lan_isolate":false}'
    fi
fi

# ================================================================
# POST ?action=mac_fix_set   body: enabled=1|0
# Toggles the cookie-based MAC-randomization session-continuity fix (see
# /lmepisowifi/hotspot/macfix.sh). Unlike anti-tether/LAN-isolate there's no
# firewall chain to build or tear down here — it only changes how the
# portal's own CGI scripts (login.sh/status.sh/logout.sh) look up a
# returning device — so this just persists the flag across all three
# config tiers, same as every other simple on/off toggle.
# ================================================================
if echo "$QS" | $BB grep -q "action=mac_fix_set"; then
    read -n "${CONTENT_LENGTH:-0}" POST_DATA
    VAL=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')
    case "$VAL" in
        1)
            save_coin_env_var "MAC_RANDOMIZATION_FIX" "1"
            set_lmehspt_var   "MAC_RANDOMIZATION_FIX" "1"
            set_globals_var   "MAC_RANDOMIZATION_FIX" "1"
            ok_json '{"ok":true,"mac_randomization_fix":true}'
            ;;
        0)
            save_coin_env_var "MAC_RANDOMIZATION_FIX" "0"
            set_lmehspt_var   "MAC_RANDOMIZATION_FIX" "0"
            set_globals_var   "MAC_RANDOMIZATION_FIX" "0"
            ok_json '{"ok":true,"mac_randomization_fix":false}'
            ;;
        *) err_json "bad_value" ;;
    esac
fi

# ================================================================
# POST ?action=hotspot_isolate_set   body: enabled=1|0
# Instantly applies or removes client-to-client isolation on the hotspot
# bridge (see HOTSPOT_ISOLATE in defaults.env / apply_hotspot_isolate() in
# lmehspt.sh for the full rationale — this is the network-level backstop
# for the fact that MAC_RANDOMIZATION_FIX's cookie above travels over
# plain HTTP on shared WiFi). Uses the same mark-file format as
# lmehspt.sh's own apply/teardown, so whichever runs next — this request,
# or the watchdog's own next tick — tears down exactly what was actually
# applied rather than assuming.
# ================================================================
if echo "$QS" | $BB grep -q "action=hotspot_isolate_set"; then
    read -n "${CONTENT_LENGTH:-0}" POST_DATA
    VAL=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')
    load_coin_env
    HBR="${HOTSPOT_BR:-$(read_lmehspt_var HOTSPOT_BR)}"
    HBR="${HBR:-br1}"
    _HI_MARK="/tmp/hotspot_isolate.mark"
    if [ -f "$_HI_MARK" ]; then
        while IFS='|' read -r _tool _a _b; do
            [ -n "$_tool" ] || continue
            case "$_tool" in
                ebtables) ebtables -D FORWARD --logical-in "$_a" --logical-out "$_a" -j DROP 2>/dev/null ;;
                physdev)  iptables -t filter -D FORWARD -m physdev --physdev-in "$_a" --physdev-out "$_b" -j DROP 2>/dev/null ;;
            esac
        done < "$_HI_MARK"
    fi
    : > "$_HI_MARK"
    case "$VAL" in
        1)
            if (ebtables --version >/dev/null 2>&1 || $BB ebtables --version >/dev/null 2>&1) \
                && ebtables -I FORWARD 1 --logical-in "$HBR" --logical-out "$HBR" -j DROP 2>/dev/null \
                && ebtables -L FORWARD 2>/dev/null | $BB grep -q "$HBR"; then
                # Inserted at position 1 (see lmehspt.sh's apply_hotspot_isolate
                # for the full rationale) and confirmed via -L, not just a
                # clean exit code.
                printf 'ebtables|%s|\n' "$HBR" >> "$_HI_MARK"
            else
                _hi_ports=""
                for ifpath in /sys/class/net/"$HBR"/brif/*; do
                    [ -e "$ifpath" ] || continue
                    _hi_ports="$_hi_ports $($BB basename "$ifpath")"
                done
                for _hi_a in $_hi_ports; do
                    for _hi_b in $_hi_ports; do
                        [ "$_hi_a" = "$_hi_b" ] && continue
                        iptables -t filter -I FORWARD 1 -m physdev --physdev-in "$_hi_a" --physdev-out "$_hi_b" -j DROP 2>/dev/null \
                            && printf 'physdev|%s|%s\n' "$_hi_a" "$_hi_b" >> "$_HI_MARK"
                    done
                done
            fi
            save_coin_env_var "HOTSPOT_ISOLATE" "1"
            set_lmehspt_var   "HOTSPOT_ISOLATE" "1"
            set_globals_var   "HOTSPOT_ISOLATE" "1"
            ok_json '{"ok":true,"hotspot_isolate":true}'
            ;;
        0)
            save_coin_env_var "HOTSPOT_ISOLATE" "0"
            set_lmehspt_var   "HOTSPOT_ISOLATE" "0"
            set_globals_var   "HOTSPOT_ISOLATE" "0"
            ok_json '{"ok":true,"hotspot_isolate":false}'
            ;;
        *) err_json "bad_value" ;;
    esac
fi

# ================================================================
# POST ?action=pause_on_boot_set   body: enabled=1|0
# Toggles whether the boot-time sync (BOOT_MARKER block in lmehspt.sh)
# converts any users.txt row still "active" from before a reboot into
# "paused". Same save_coin_env_var/set_lmehspt_var/set_globals_var pattern
# as every other simple on/off toggle here — no firewall chain or
# running-daemon effect to apply live, this only changes what the boot
# sequence does the *next* time the box actually reboots.
# ================================================================
if echo "$QS" | $BB grep -q "action=pause_on_boot_set"; then
    read -n "${CONTENT_LENGTH:-0}" POST_DATA
    VAL=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')
    case "$VAL" in
        1)
            save_coin_env_var "PAUSE_ON_BOOT" "1"
            set_lmehspt_var   "PAUSE_ON_BOOT" "1"
            set_globals_var   "PAUSE_ON_BOOT" "1"
            ok_json '{"ok":true,"pause_on_boot":true}'
            ;;
        0)
            save_coin_env_var "PAUSE_ON_BOOT" "0"
            set_lmehspt_var   "PAUSE_ON_BOOT" "0"
            set_globals_var   "PAUSE_ON_BOOT" "0"
            ok_json '{"ok":true,"pause_on_boot":false}'
            ;;
        *) err_json "bad_value" ;;
    esac
fi

# ================================================================
# POST ?action=coin_internet_set   body: enabled=1|0
# When on, coin.sh's "start" action refuses to open a brand new coin
# session while the router has no internet connectivity (an in-flight
# session someone already paid for is never interrupted by this — see
# coin.sh's own comments). Same simple three-tier persistence as every
# other on/off toggle here.
# ================================================================
if echo "$QS" | $BB grep -q "action=coin_internet_set"; then
    read -n "${CONTENT_LENGTH:-0}" POST_DATA
    VAL=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')
    case "$VAL" in
        1)
            save_coin_env_var "COIN_REQUIRE_INTERNET" "1"
            set_lmehspt_var   "COIN_REQUIRE_INTERNET" "1"
            set_globals_var   "COIN_REQUIRE_INTERNET" "1"
            ok_json '{"ok":true,"coin_require_internet":true}'
            ;;
        0)
            save_coin_env_var "COIN_REQUIRE_INTERNET" "0"
            set_lmehspt_var   "COIN_REQUIRE_INTERNET" "0"
            set_globals_var   "COIN_REQUIRE_INTERNET" "0"
            ok_json '{"ok":true,"coin_require_internet":false}'
            ;;
        *) err_json "bad_value" ;;
    esac
fi

# ================================================================
# POST ?action=voucher_internet_set   body: enabled=1|0
# When on, login.sh refuses to redeem (burn) a voucher code while the
# router has no internet connectivity — returns error "no_internet"
# instead. Resuming an already-paused session is unaffected.
# ================================================================
if echo "$QS" | $BB grep -q "action=voucher_internet_set"; then
    read -n "${CONTENT_LENGTH:-0}" POST_DATA
    VAL=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')
    case "$VAL" in
        1)
            save_coin_env_var "VOUCHER_REQUIRE_INTERNET" "1"
            set_lmehspt_var   "VOUCHER_REQUIRE_INTERNET" "1"
            set_globals_var   "VOUCHER_REQUIRE_INTERNET" "1"
            ok_json '{"ok":true,"voucher_require_internet":true}'
            ;;
        0)
            save_coin_env_var "VOUCHER_REQUIRE_INTERNET" "0"
            set_lmehspt_var   "VOUCHER_REQUIRE_INTERNET" "0"
            set_globals_var   "VOUCHER_REQUIRE_INTERNET" "0"
            ok_json '{"ok":true,"voucher_require_internet":false}'
            ;;
        *) err_json "bad_value" ;;
    esac
fi

# ================================================================
# POST ?action=voucher_strike_set   body: enabled=1|0
# Master switch for the wrong-voucher anti-troll strike system (see
# login.sh). When on, login.sh temporarily suspends further voucher
# attempts from a device after VOUCHER_STRIKE_THRESHOLD wrong codes in a
# row, for VOUCHER_COOLDOWN seconds — same shape as the coin acceptor's
# own anti-griefing strike system. Same simple three-tier persistence as
# every other on/off toggle here.
# ================================================================
if echo "$QS" | $BB grep -q "action=voucher_strike_set"; then
    read -n "${CONTENT_LENGTH:-0}" POST_DATA
    VAL=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')
    case "$VAL" in
        1)
            save_coin_env_var "VOUCHER_STRIKE_ENABLED" "1"
            set_lmehspt_var   "VOUCHER_STRIKE_ENABLED" "1"
            set_globals_var   "VOUCHER_STRIKE_ENABLED" "1"
            ok_json '{"ok":true,"voucher_strike_enabled":true}'
            ;;
        0)
            save_coin_env_var "VOUCHER_STRIKE_ENABLED" "0"
            set_lmehspt_var   "VOUCHER_STRIKE_ENABLED" "0"
            set_globals_var   "VOUCHER_STRIKE_ENABLED" "0"
            ok_json '{"ok":true,"voucher_strike_enabled":false}'
            ;;
        *) err_json "bad_value" ;;
    esac
fi

# ================================================================
# POST ?action=coin_strike_set   body: enabled=1|0
# Master switch for the coin acceptor's own anti-griefing strike system
# (see coin.sh / coin_result.sh). When off, repeated empty coin sessions
# never accumulate strikes or trigger a suspension — the coin acceptor
# itself stays on and works normally, only this specific check is
# skipped. On by default, matching the system's original always-on
# behavior. Same simple three-tier persistence as every other toggle.
# ================================================================
if echo "$QS" | $BB grep -q "action=coin_strike_set"; then
    read -n "${CONTENT_LENGTH:-0}" POST_DATA
    VAL=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')
    case "$VAL" in
        1)
            save_coin_env_var "COIN_STRIKE_ENABLED" "1"
            set_lmehspt_var   "COIN_STRIKE_ENABLED" "1"
            set_globals_var   "COIN_STRIKE_ENABLED" "1"
            ok_json '{"ok":true,"coin_strike_enabled":true}'
            ;;
        0)
            save_coin_env_var "COIN_STRIKE_ENABLED" "0"
            set_lmehspt_var   "COIN_STRIKE_ENABLED" "0"
            set_globals_var   "COIN_STRIKE_ENABLED" "0"
            ok_json '{"ok":true,"coin_strike_enabled":false}'
            ;;
        *) err_json "bad_value" ;;
    esac
fi

# ================================================================
# POST ?action=coin_queue_set   body: enabled=1|0
# Master switch for the Insert Coin waiting line (see coin.sh's "start"
# action). On by default: a client who finds the slot busy is placed in
# line and notified when it's their turn. When off, a busy slot is reported
# immediately as "Coin slot is in use, try again later." and no one is
# queued. Same simple three-tier persistence as every other on/off toggle.
# ================================================================
if echo "$QS" | $BB grep -q "action=coin_queue_set"; then
    read -n "${CONTENT_LENGTH:-0}" POST_DATA
    VAL=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')
    case "$VAL" in
        1)
            save_coin_env_var "COIN_QUEUE_ENABLED" "1"
            set_lmehspt_var   "COIN_QUEUE_ENABLED" "1"
            set_globals_var   "COIN_QUEUE_ENABLED" "1"
            ok_json '{"ok":true,"coin_queue_enabled":true}'
            ;;
        0)
            save_coin_env_var "COIN_QUEUE_ENABLED" "0"
            set_lmehspt_var   "COIN_QUEUE_ENABLED" "0"
            set_globals_var   "COIN_QUEUE_ENABLED" "0"
            ok_json '{"ok":true,"coin_queue_enabled":false}'
            ;;
        *) err_json "bad_value" ;;
    esac
fi

# ================================================================
# POST ?action=nodemcu_reset  body: id (also handles action=coin_reset)
# Factory resets any NodeMCU unit (#1 or #2+) back into PisoWifi-Setup AP:
#   1. GET /nonce         → fresh single-use nonce
#   2. GET /reset?token   → token = md5(PSK:nonce:reset)
# ================================================================
if echo "$QS" | $BB grep -E -q "action=(nodemcu_reset|coin_reset)"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    NID=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*id=\([^&]*\).*/\1/p' | $BB tr -cd '0-9')
    [ -z "$NID" ] && NID="1"

    _nodemcu_conn "$NID"
    [ -n "$NIP" ] && [ -n "$CPSK" ] || err_json "coin_not_configured"

    # Step 1: Get a fresh one-time nonce from NodeMCU
    NONCE_RESP=$(wget -q -T 5 -O - "http://${NIP}:${NPT}/nonce" 2>/dev/null)
    NONCE=$($BB echo "$NONCE_RESP" | $BB grep -o '"nonce":"[^"]*"' | awk -F'"' '{print $4}')
    [ -n "$NONCE" ] || err_json "nodemcu_offline"

    # Step 2: Sign — md5(PSK:nonce:reset)
    TOKEN=$(printf '%s' "${CPSK}:${NONCE}:reset" | md5sum | awk '{print $1}')

    # Step 3: Send signed reset request
    RESP=$(wget -q -T 5 -O - "http://${NIP}:${NPT}/reset?token=${TOKEN}" 2>/dev/null)
    printf '%s' "$RESP" | $BB grep -q '"ok":true' || err_json "reset_failed"

    ok_json "{\"ok\":true,\"id\":$NID,\"msg\":\"NodeMCU wiped and rebooting into setup AP\"}"
fi

# ================================================================
# POST ?action=nodemcu_reboot  body: id
# Sends an authenticated reboot command to any NodeMCU unit (#1 or #2+):
#   1. GET /nonce          → fresh single-use nonce
#   2. GET /reboot?token   → token = md5(PSK:nonce:reboot)
# ================================================================
if echo "$QS" | $BB grep -q "action=nodemcu_reboot"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    NID=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*id=\([^&]*\).*/\1/p' | $BB tr -cd '0-9')
    [ -z "$NID" ] && err_json "missing_id"

    _nodemcu_conn "$NID"
    [ -n "$NIP" ] && [ -n "$CPSK" ] || err_json "coin_not_configured"

    # Step 1: Get fresh one-time nonce
    NONCE_RESP=$(wget -q -T 5 -O - "http://${NIP}:${NPT}/nonce" 2>/dev/null)
    NONCE=$($BB echo "$NONCE_RESP" | $BB grep -o '"nonce":"[^"]*"' | awk -F'"' '{print $4}')
    [ -n "$NONCE" ] || err_json "nodemcu_offline"

    # Step 2: Sign — md5(PSK:nonce:reboot)
    TOKEN=$(printf '%s' "${CPSK}:${NONCE}:reboot" | md5sum | awk '{print $1}')

    # Step 3: Send signed request
    RESP=$(wget -q -T 5 -O - "http://${NIP}:${NPT}/reboot?token=${TOKEN}" 2>/dev/null)
    if printf '%s' "$RESP" | $BB grep -q '"error":"busy"'; then
        err_json "busy"
    fi
    printf '%s' "$RESP" | $BB grep -q '"ok":true' || err_json "reboot_failed"

    ok_json "{\"ok\":true,\"id\":$NID,\"msg\":\"NodeMCU is rebooting\"}"
fi

# ================================================================
# GET ?action=nodemcu_status  body/query: id
# Queries live firmware version and actual CPU frequency from the unit:
# ================================================================
if echo "$QS" | $BB grep -q "action=nodemcu_status"; then
    NID=$(printf '%s' "$QS" | $BB sed -n 's/.*id=\([^&]*\).*/\1/p' | $BB tr -cd '0-9')
    [ -z "$NID" ] && NID="1"

    _nodemcu_conn "$NID"
    [ -n "$NIP" ] || err_json "not_found"

    RESP=$(wget -q -T 2 -O - "http://${NIP}:${NPT}/version" 2>/dev/null)
    if [ -n "$RESP" ] && printf '%s' "$RESP" | $BB grep -q '"ok":true'; then
        ok_json "$RESP"
    else
        ok_json "{\"ok\":false,\"online\":false}"
    fi
fi

# ================================================================
# POST ?action=nodemcu_setfreq  body: id, freq (80 or 160)
# Pushes a signed CPU-frequency change to one NodeMCU unit and reboots it
# to apply it. Same two-step signed handshake as action=coin_reset above,
# just targeting the firmware's /setfreq endpoint instead of /reset, and
# resolved against ANY configured unit (not just the primary) via
# _nodemcu_conn — see that function above for the id|title|ip|mac|port|psk|
# enabled row format for units #2+.
#   1. GET /nonce                → fresh single-use nonce
#   2. GET /setfreq?freq&token   → token = md5(PSK:nonce:freq:setfreq)
# ================================================================
if echo "$QS" | $BB grep -q "action=nodemcu_setfreq"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    NID=$(printf '%s'  "$POST_DATA" | $BB sed -n 's/.*id=\([^&]*\).*/\1/p'   | $BB tr -cd '0-9')
    FREQ=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*freq=\([^&]*\).*/\1/p' | $BB tr -cd '0-9')
    [ -z "$NID" ] && err_json "missing_id"
    [ "$FREQ" = "80" ] || [ "$FREQ" = "160" ] || err_json "bad_freq"

    _nodemcu_conn "$NID"
    [ -n "$NIP" ] && [ -n "$CPSK" ] || err_json "coin_not_configured"

    # Step 1: fresh one-time nonce
    NONCE_RESP=$(wget -q -T 5 -O - "http://${NIP}:${NPT}/nonce" 2>/dev/null)
    NONCE=$($BB echo "$NONCE_RESP" | $BB grep -o '"nonce":"[^"]*"' | awk -F'"' '{print $4}')
    [ -n "$NONCE" ] || err_json "nodemcu_offline"

    # Step 2: sign — md5(PSK:nonce:freq:setfreq)
    TOKEN=$(printf '%s' "${CPSK}:${NONCE}:${FREQ}:setfreq" | md5sum | awk '{print $1}')

    # Step 3: send signed request
    RESP=$(wget -q -T 5 -O - "http://${NIP}:${NPT}/setfreq?freq=${FREQ}&token=${TOKEN}" 2>/dev/null)
    if printf '%s' "$RESP" | $BB grep -q '"error":"busy"'; then
        err_json "busy"
    fi
    printf '%s' "$RESP" | $BB grep -q '"ok":true' || err_json "setfreq_failed"

    ok_json "{\"ok\":true,\"id\":$NID,\"freq\":$FREQ,\"msg\":\"NodeMCU rebooting at ${FREQ}MHz\"}"
fi

# ── WAN port safety check ─────────────────────────────────────────────────────
# PON_MODE=0 (RJ45 Ethernet WAN) puts the vendor WAN on the RJ45 LAN port picked
# by WAN_PHY_PORT: 0=ge1/eth0.2.0  1=ge2/eth0.3.0  2=ge3/eth0.4.0  3=ge4/eth0.5.0.
# lmehspt.sh skips that port at runtime; the Interfaces page must not offer it.
# Keep in sync with wan_claimed_lan_iface() in lmehspt.sh.
_wan_mib_val() {
    mib get "$1" 2>/dev/null | $BB grep '=' | $BB head -1 | $BB cut -d= -f2- | $BB tr -d ' \t\r\n'
}
wan_claimed_lan_iface() {
    local _pm _pp
    _pm=$(_wan_mib_val PON_MODE)
    [ "$_pm" = "0" ] || return 0
    _pp=$(_wan_mib_val WAN_PHY_PORT)
    case "$_pp" in
        0|1|2|3) echo "eth0.$((_pp + 2)).0" ;;
    esac
    return 0
}

# ================================================================
# GET ?action=ifaces_get
# Returns available network interfaces + current config + live bridge members
# ================================================================
if echo "$QS" | $BB grep -q "action=ifaces_get"; then
    load_coin_env
    HBR="${HOTSPOT_BR:-$(read_lmehspt_var HOTSPOT_BR)}"
    HBR="${HBR:-br1}"
    HIF="${HOTSPOT_INTERFACES:-$(read_lmehspt_var HOTSPOT_INTERFACES)}"
    PIP="${PORTAL_IP:-$(read_lmehspt_var PORTAL_IP)}"
    PPT="${PORTAL_PORT:-$(read_lmehspt_var PORTAL_PORT)}"

    HSP_RUNNING="false"; hotspot_running && HSP_RUNNING="true"

    # Port the vendor WAN has claimed (PON_MODE=0 + WAN_PHY_PORT), if any
    WAN_PORT_IF=$(wan_claimed_lan_iface)

    # --- Bridge members (live kernel state) ---
    BRIDGE_MEMBERS="["
    BM_SEP=""
    for ifpath in /sys/class/net/"$HBR"/brif/*; do
        [ -e "$ifpath" ] || continue
        bm=$(basename "$ifpath")
        bm_mac=$(cat "/sys/class/net/$bm/address" 2>/dev/null)
        bm_op=$(cat "/sys/class/net/$bm/operstate" 2>/dev/null)
        bm_up="false"
        [ "$bm_op" = "up" ] && bm_up="true"
        BRIDGE_MEMBERS="${BRIDGE_MEMBERS}${BM_SEP}{\"name\":\"$bm\",\"mac\":\"${bm_mac:-}\",\"up\":$bm_up}"
        BM_SEP=","
    done
    BRIDGE_MEMBERS="${BRIDGE_MEMBERS}]"

    # --- All available interfaces (filter lo/br/sit/ip6/ppp/etc.) ---
    IFACE_LIST="["
    IF_SEP=""
    for ifpath in /sys/class/net/*; do
        iface=$(basename "$ifpath")
        case "$iface" in
            lo|br*|sit*|ip6*|ppp*|tunl*|gre*|dummy*|mon.*|nas*|eth0|pwlan0) continue ;;
            eth0.*)
                case "$iface" in
                    eth0.2.0|eth0.3.0) ;;
                    *) continue ;;
                esac
                ;;
            wlan*)
                [ "$(wlan_iface_disabled "$iface")" = "1" ] && continue
                [ "$(wlan_iface_is_client "$iface")" = "1" ] && continue
                ;;
        esac
        mac=$(cat "/sys/class/net/$iface/address" 2>/dev/null)
        op=$(cat  "/sys/class/net/$iface/operstate" 2>/dev/null)
        type_f=$(cat "/sys/class/net/$iface/type" 2>/dev/null)
        iface_type=""
        case "$iface" in wlan*) iface_type="WLAN" ;; eth*)  iface_type="Ethernet" ;; esac
        is_up="false"; [ "$op" = "up" ] && is_up="true"
        # Check if it's in the bridge right now
        in_bridge="false"
        [ -e "/sys/class/net/$HBR/brif/$iface" ] && in_bridge="true"
        is_wan="false"
        [ -n "$WAN_PORT_IF" ] && [ "$iface" = "$WAN_PORT_IF" ] && is_wan="true"
        IFACE_LIST="${IFACE_LIST}${IF_SEP}{\"name\":\"$iface\",\"mac\":\"${mac:-}\",\"type\":\"$iface_type\",\"up\":$is_up,\"in_bridge\":$in_bridge,\"wan_port\":$is_wan}"
        IF_SEP=","
    done
    IFACE_LIST="${IFACE_LIST}]"

    ok_json "{\"ok\":true,
\"hotspot_br\":\"$(esc_json "$HBR")\",
\"hotspot_interfaces\":\"$(esc_json "$HIF")\",
\"portal_ip\":\"$(esc_json "$PIP")\",
\"portal_port\":\"$(esc_json "$PPT")\",
\"hotspot_running\":$HSP_RUNNING,
\"wan_port_iface\":\"$(esc_json "$WAN_PORT_IF")\",
\"bridge_members\":$BRIDGE_MEMBERS,
\"interfaces\":$IFACE_LIST}"
fi

# ================================================================
# POST ?action=ifaces_set  (form-encoded body)
# Updates HOTSPOT_BR, HOTSPOT_INTERFACES, PORTAL_IP, PORTAL_PORT
# ================================================================
if echo "$QS" | $BB grep -q "action=ifaces_set"; then
    read -n "$CONTENT_LENGTH" POST_DATA

    fget() {
        printf '%s' "$POST_DATA" \
            | $BB tr '&' '\n' \
            | $BB grep "^$1=" \
            | $BB sed 's/^[^=]*=//' \
            | urldecode \
            | head -1
    }

    BR=$(fget hotspot_br); IF=$(fget hotspot_interfaces)
    PIP=$(fget portal_ip);  PPT=$(fget portal_port)

    [ -z "$BR" ] && err_json "missing_hotspot_br"
    [ -z "$IF" ] && err_json "missing_hotspot_interfaces"
    # Interface names go unquoted into brctl/iptables/ip and into the sourced
    # env files: kernel ifname charset only, <=15 chars each (IFNAMSIZ).
    env_val_safe "$BR" && printf '%s' "$BR" | $BB grep -qE '^[A-Za-z0-9._-]{1,15}$' \
        || err_json "invalid_hotspot_br"
    env_val_safe "$IF" && printf '%s' "$IF" | $BB grep -qE '^[A-Za-z0-9._-]{1,15}( [A-Za-z0-9._-]{1,15})*$' \
        || err_json "invalid_hotspot_interfaces"
    # Refuse to newly bind the RJ45 port the vendor WAN is running on — the
    # hotspot and the system would fight over it. A port that was already
    # configured before it became the WAN is allowed through unchanged: the
    # runtime guard in lmehspt.sh skips it, and keeping it listed lets it
    # rejoin the hotspot automatically if the WAN moves back to fiber.
    _wan_if=$(wan_claimed_lan_iface)
    if [ -n "$_wan_if" ]; then
        case " $IF " in
            *" $_wan_if "*)
                case " $(read_lmehspt_var HOTSPOT_INTERFACES) " in
                    *" $_wan_if "*) ;;
                    *) err_json "wan_port_in_use" ;;
                esac
                ;;
        esac
    fi
    [ -z "$PIP" ] || { env_val_safe "$PIP" && _valid_ipv4 "$PIP"; } || err_json "invalid_portal_ip"
    [ -z "$PPT" ] || { env_val_safe "$PPT" && printf '%s' "$PPT" | $BB grep -qE '^[0-9]{1,5}$' \
        && [ "$PPT" -ge 1 ] && [ "$PPT" -le 65535 ]; } || err_json "invalid_portal_port"

    # Capture current values before overwriting — needed to detect changes
    OLD_PIP=$(read_lmehspt_var PORTAL_IP)
    OLD_PPT=$(read_lmehspt_var PORTAL_PORT)

    set_lmehspt_var "HOTSPOT_BR"         "$BR"
    set_lmehspt_var "HOTSPOT_INTERFACES" "$IF"
    set_globals_var "HOTSPOT_BR"         "$BR"
    set_globals_var "HOTSPOT_INTERFACES" "$IF"
    save_coin_env_var "HOTSPOT_BR"         "$BR"
    save_coin_env_var "HOTSPOT_INTERFACES" "$IF"

    [ -n "$PIP" ] && {
        set_lmehspt_var   "PORTAL_IP" "$PIP"
        save_coin_env_var "PORTAL_IP" "$PIP"
        set_globals_var   "PORTAL_IP" "$PIP"
    }
    [ -n "$PPT" ] && {
        set_lmehspt_var   "PORTAL_PORT" "$PPT"
        save_coin_env_var "PORTAL_PORT" "$PPT"
        set_globals_var   "PORTAL_PORT" "$PPT"
    }

    # Trigger a live portal IP/port apply when either value changed and
    # the hotspot watchdog is currently running.  The watchdog picks up
    # /tmp/hotspot_portal_ip_reload on its next tick (≤1 s) and calls
    # apply_portal_ip_change() which rebuilds firewall, DHCP, httpd, and
    # redirect.sh without requiring a full hotspot restart.
    _pip_changed=0; _ppt_changed=0
    [ -n "$PIP" ] && [ "$PIP" != "$OLD_PIP" ] && _pip_changed=1
    [ -n "$PPT" ] && [ "$PPT" != "$OLD_PPT" ] && _ppt_changed=1
    if hotspot_running && { [ "$_pip_changed" = "1" ] || [ "$_ppt_changed" = "1" ]; }; then
        printf '%s\n' "${PIP:-$OLD_PIP}" > /tmp/hotspot_portal_ip_new
        printf '%s\n' "${PPT:-$OLD_PPT}" > /tmp/hotspot_portal_port_new
        # Also stash the pre-change values. save_coin_env_var() above already
        # rewrote /tmp/coin_config.env with the NEW port, and the watchdog
        # re-sources that file every tick — so by the time it processes this
        # reload, its own $PORTAL_PORT may already equal the new port. Without
        # these _old files it has no reliable way left to know what to kill.
        printf '%s\n' "$OLD_PIP" > /tmp/hotspot_portal_ip_old
        printf '%s\n' "$OLD_PPT" > /tmp/hotspot_portal_port_old
        touch /tmp/hotspot_portal_ip_reload
    fi

    touch /tmp/hotspot_qos_reload
    ok_json "{\"ok\":true}"
fi

# ================================================================
# GET ?action=income   -> daily / monthly / yearly / total income
# ================================================================
if echo "$QS" | $BB grep -q "action=income_reset"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    WHICH=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*which=\([^&]*\).*/\1/p' | $BB tr -cd 'a-z')
    case "$WHICH" in
        daily|monthly|yearly|total|all) ;;
        *) err_json "bad_which" ;;
    esac
    OUT=$(/lmepisowifi/hotspot/income.sh reset "$WHICH" 2>/dev/null)
    [ -n "$OUT" ] || err_json "reset_failed"
    ok_json "$OUT"
fi

if echo "$QS" | $BB grep -q "action=income"; then
    OUT=$(/lmepisowifi/hotspot/income.sh get 2>/dev/null)
    [ -n "$OUT" ] || OUT='{"daily":0,"monthly":0,"yearly":0,"total":0,"day":"","month":"","year":"","synced":false}'
    ok_json "$OUT"
fi

# ================================================================
# GET ?action=notify_get   -> current Telegram/Discord alert config
# ================================================================
if echo "$QS" | $BB grep -q "action=notify_get"; then
    NF="$HDATA/notify.env"
    NOTIFY_ENABLED=0
    TG_BOT_TOKEN=""; TG_CHAT_ID=""; DISCORD_WEBHOOK=""
    NOTIFY_TG_ENABLED=""; NOTIFY_DISCORD_ENABLED=""
    # Per-event flags default to enabled (unset -> "1") so existing configs
    # keep every alert firing until the admin explicitly mutes one.
    NOTIFY_EVT_NEW_SALE=1; NOTIFY_EVT_COINS_INSERTED=1; NOTIFY_EVT_ANTI_TROLL=1
    NOTIFY_EVT_SESSION_EXPIRED=1; NOTIFY_EVT_SESSION_PAUSED=1; NOTIFY_EVT_SESSION_RESUMED=1
    NOTIFY_EVT_VOUCHER_REDEEMED=1; NOTIFY_EVT_DAILY_REPORT=1
    NOTIFY_EVT_MONTHLY_REPORT=1; NOTIFY_EVT_YEARLY_REPORT=1; NOTIFY_EVT_COIN_ERRORS=1
    NOTIFY_DEDUP_WINDOW=30
    [ -f "$NF" ] && . "$NF" 2>/dev/null
    EN_STR="false"; [ "${NOTIFY_ENABLED:-0}" = "1" ] && EN_STR="true"
    # A provider is "enabled" (and, per notify.sh, actually fires) when its
    # own flag is explicitly set, OR — if it was never explicitly set —
    # when its required fields are already filled in. Telegram and Discord
    # are independent: both can report true and both will send together.
    case "${NOTIFY_TG_ENABLED:-}" in
        0) TG_EN="false" ;;
        1) TG_EN="true" ;;
        *) if [ -n "$TG_BOT_TOKEN" ] && [ -n "$TG_CHAT_ID" ]; then TG_EN="true"; else TG_EN="false"; fi ;;
    esac
    case "${NOTIFY_DISCORD_ENABLED:-}" in
        0) DC_EN="false" ;;
        1) DC_EN="true" ;;
        *) if [ -n "$DISCORD_WEBHOOK" ]; then DC_EN="true"; else DC_EN="false"; fi ;;
    esac
    case "${NOTIFY_DEDUP_WINDOW:-30}" in ''|*[!0-9]*) DDW=30 ;; *) DDW="$NOTIFY_DEDUP_WINDOW" ;; esac
    # Emit each event flag as a JSON boolean ("1" -> true, anything else -> false)
    _evb() { [ "${1:-1}" = "1" ] && printf 'true' || printf 'false'; }
    ok_json "{\"enabled\":$EN_STR,\"tg_enabled\":$TG_EN,\"discord_enabled\":$DC_EN,\"tg_bot_token\":\"$(esc_json "$TG_BOT_TOKEN")\",\"tg_chat_id\":\"$(esc_json "$TG_CHAT_ID")\",\"discord_webhook\":\"$(esc_json "$DISCORD_WEBHOOK")\",\"dedup_window\":$DDW,\"events\":{\
\"new_sale\":$(_evb "$NOTIFY_EVT_NEW_SALE"),\
\"coins_inserted\":$(_evb "$NOTIFY_EVT_COINS_INSERTED"),\
\"anti_troll\":$(_evb "$NOTIFY_EVT_ANTI_TROLL"),\
\"session_expired\":$(_evb "$NOTIFY_EVT_SESSION_EXPIRED"),\
\"session_paused\":$(_evb "$NOTIFY_EVT_SESSION_PAUSED"),\
\"session_resumed\":$(_evb "$NOTIFY_EVT_SESSION_RESUMED"),\
\"voucher_redeemed\":$(_evb "$NOTIFY_EVT_VOUCHER_REDEEMED"),\
\"daily_report\":$(_evb "$NOTIFY_EVT_DAILY_REPORT"),\
\"monthly_report\":$(_evb "$NOTIFY_EVT_MONTHLY_REPORT"),\
\"yearly_report\":$(_evb "$NOTIFY_EVT_YEARLY_REPORT"),\
\"coin_errors\":$(_evb "$NOTIFY_EVT_COIN_ERRORS")}}"
fi

# ================================================================
# POST ?action=notify_set   (form-encoded) -> save alert config
# ================================================================
if echo "$QS" | $BB grep -q "action=notify_set"; then
    read -n "$CONTENT_LENGTH" POST_DATA

    fget() {
        printf '%s' "$POST_DATA" \
            | $BB tr '&' '\n' \
            | $BB grep "^$1=" \
            | $BB sed 's/^[^=]*=//' \
            | urldecode \
            | head -1
    }
    # Strip chars that could break the sourced env file / inject commands.
    san() { printf '%s' "$1" | $BB tr -d '\r\n"\\$\140'; }

    EN=$(fget enabled)
    TGEN=$(fget tg_enabled); DCEN=$(fget discord_enabled)
    TGT=$(san "$(fget tg_bot_token)")
    TGC=$(san "$(fget tg_chat_id)")
    DWH=$(san "$(fget discord_webhook)")

    case "$EN"   in 1|true|on|yes) EN=1 ;; *) EN=0 ;; esac
    # Explicit per-provider switches - always written as a definite 1/0 from
    # here on (never left blank/"auto"), since the admin panel always sends
    # both fields. A pre-dual-provider notify.env with neither key set yet
    # stays in "auto" mode (see notify.sh/notify_get) only until the first
    # Save through this action.
    case "$TGEN" in 1|true|on|yes) TGEN=1 ;; *) TGEN=0 ;; esac
    case "$DCEN" in 1|true|on|yes) DCEN=1 ;; *) DCEN=0 ;; esac

    # Anti-spam cooldown window (seconds). Non-numeric -> default 30;
    # clamp to a sane 0..3600 so a typo can't wedge notifications for hours.
    DDW=$(fget dedup_window | $BB tr -cd '0-9')
    [ -z "$DDW" ] && DDW=30
    [ "$DDW" -gt 3600 ] 2>/dev/null && DDW=3600

    # Per-event mute flags. A missing field defaults to enabled ("1") so a
    # form that doesn't send them (older UI) never accidentally mutes events.
    evt_flag() { case "$(fget "$1")" in 0|false|off|no) printf 0 ;; *) printf 1 ;; esac; }
    EVT_NEW_SALE=$(evt_flag evt_new_sale)
    EVT_COINS_INSERTED=$(evt_flag evt_coins_inserted)
    EVT_ANTI_TROLL=$(evt_flag evt_anti_troll)
    EVT_SESSION_EXPIRED=$(evt_flag evt_session_expired)
    EVT_SESSION_PAUSED=$(evt_flag evt_session_paused)
    EVT_SESSION_RESUMED=$(evt_flag evt_session_resumed)
    EVT_VOUCHER_REDEEMED=$(evt_flag evt_voucher_redeemed)
    EVT_DAILY_REPORT=$(evt_flag evt_daily_report)
    EVT_MONTHLY_REPORT=$(evt_flag evt_monthly_report)
    EVT_YEARLY_REPORT=$(evt_flag evt_yearly_report)
    EVT_COIN_ERRORS=$(evt_flag evt_coin_errors)

    mkdir -p "$HDATA"
    {
        echo "NOTIFY_ENABLED=\"$EN\""
        echo "NOTIFY_TG_ENABLED=\"$TGEN\""
        echo "NOTIFY_DISCORD_ENABLED=\"$DCEN\""
        echo "TG_BOT_TOKEN=\"$TGT\""
        echo "TG_CHAT_ID=\"$TGC\""
        echo "DISCORD_WEBHOOK=\"$DWH\""
        echo "NOTIFY_DEDUP_WINDOW=\"$DDW\""
        echo "NOTIFY_EVT_NEW_SALE=\"$EVT_NEW_SALE\""
        echo "NOTIFY_EVT_COINS_INSERTED=\"$EVT_COINS_INSERTED\""
        echo "NOTIFY_EVT_ANTI_TROLL=\"$EVT_ANTI_TROLL\""
        echo "NOTIFY_EVT_SESSION_EXPIRED=\"$EVT_SESSION_EXPIRED\""
        echo "NOTIFY_EVT_SESSION_PAUSED=\"$EVT_SESSION_PAUSED\""
        echo "NOTIFY_EVT_SESSION_RESUMED=\"$EVT_SESSION_RESUMED\""
        echo "NOTIFY_EVT_VOUCHER_REDEEMED=\"$EVT_VOUCHER_REDEEMED\""
        echo "NOTIFY_EVT_DAILY_REPORT=\"$EVT_DAILY_REPORT\""
        echo "NOTIFY_EVT_MONTHLY_REPORT=\"$EVT_MONTHLY_REPORT\""
        echo "NOTIFY_EVT_YEARLY_REPORT=\"$EVT_YEARLY_REPORT\""
        echo "NOTIFY_EVT_COIN_ERRORS=\"$EVT_COIN_ERRORS\""
    } > "$HDATA/notify.env.tmp"
    $BB mv "$HDATA/notify.env.tmp" "$HDATA/notify.env"
    ok_json "{\"ok\":true}"
fi

# ================================================================
# POST ?action=notify_test   -> send a test alert with saved config
# ================================================================
if echo "$QS" | $BB grep -q "action=notify_test"; then
    [ -f "$HDATA/notify.env" ] || err_json "not_configured"
    . /lmepisowifi/hotspot/notify_templates.sh
    ( /lmepisowifi/hotspot/notify.sh "$(tpl_render "$TPL_TEST_ALERT")" force >/dev/null 2>&1 </dev/null & )
    ok_json "{\"ok\":true}"
fi

# ================================================================
# GET ?action=notify_templates_get  -> current message templates
# (falls back to built-in defaults for anything not customized)
# ================================================================
if echo "$QS" | $BB grep -q "action=notify_templates_get"; then
    . /lmepisowifi/hotspot/notify_templates.sh
    ok_json "{\"templates\":{\
\"new_sale\":\"$(esc_json "$TPL_NEW_SALE")\",\
\"coins_inserted\":\"$(esc_json "$TPL_COINS_INSERTED")\",\
\"anti_troll\":\"$(esc_json "$TPL_ANTI_TROLL")\",\
\"session_expired\":\"$(esc_json "$TPL_SESSION_EXPIRED")\",\
\"session_paused\":\"$(esc_json "$TPL_SESSION_PAUSED")\",\
\"session_resumed\":\"$(esc_json "$TPL_SESSION_RESUMED")\",\
\"voucher_redeemed\":\"$(esc_json "$TPL_VOUCHER_REDEEMED")\",\
\"daily_report\":\"$(esc_json "$TPL_DAILY_REPORT")\",\
\"monthly_report\":\"$(esc_json "$TPL_MONTHLY_REPORT")\",\
\"yearly_report\":\"$(esc_json "$TPL_YEARLY_REPORT")\",\
\"test_alert\":\"$(esc_json "$TPL_TEST_ALERT")\"\
}}"
fi

# ================================================================
# POST ?action=notify_templates_set  (form-encoded) -> save customized
# message templates. Any field left blank reverts that event to its
# built-in default (handled by notify_templates.sh at render time).
# ================================================================
if echo "$QS" | $BB grep -q "action=notify_templates_set"; then
    read -n "$CONTENT_LENGTH" POST_DATA

    fget() {
        printf '%s' "$POST_DATA" \
            | $BB tr '&' '\n' \
            | $BB grep "^$1=" \
            | $BB sed 's/^[^=]*=//' \
            | urldecode \
            | head -1
    }
    # Strip CR/LF, quotes, backslashes, $ and backticks so the saved value
    # can't break out of the sourced env file or inject shell commands.
    # Templates still support multi-line layout via the %0A token.
    san() { printf '%s' "$1" | $BB tr -d '\r\n"\\$\140'; }

    mkdir -p "$HDATA"
    {
        echo "TPL_NEW_SALE=\"$(san "$(fget new_sale)")\""
        echo "TPL_COINS_INSERTED=\"$(san "$(fget coins_inserted)")\""
        echo "TPL_ANTI_TROLL=\"$(san "$(fget anti_troll)")\""
        echo "TPL_SESSION_EXPIRED=\"$(san "$(fget session_expired)")\""
        echo "TPL_SESSION_PAUSED=\"$(san "$(fget session_paused)")\""
        echo "TPL_SESSION_RESUMED=\"$(san "$(fget session_resumed)")\""
        echo "TPL_VOUCHER_REDEEMED=\"$(san "$(fget voucher_redeemed)")\""
        echo "TPL_DAILY_REPORT=\"$(san "$(fget daily_report)")\""
        echo "TPL_MONTHLY_REPORT=\"$(san "$(fget monthly_report)")\""
        echo "TPL_YEARLY_REPORT=\"$(san "$(fget yearly_report)")\""
        echo "TPL_TEST_ALERT=\"$(san "$(fget test_alert)")\""
    } > "$HDATA/notify_templates.env.tmp"
    $BB mv "$HDATA/notify_templates.env.tmp" "$HDATA/notify_templates.env"
    ok_json "{\"ok\":true}"
fi

# ================================================================
# POST ?action=notify_templates_reset  -> restore all templates to
# their built-in defaults (deletes the override file)
# ================================================================
if echo "$QS" | $BB grep -q "action=notify_templates_reset"; then
    rm -f "$HDATA/notify_templates.env"
    ok_json "{\"ok\":true}"
fi

# ================================================================
# GET ?action=bot_templates_get  -> current router-bot command-response
# templates (falls back to built-in defaults for anything not customized).
# Separate file/action from notify_templates_* above -- saving the "Bot
# Command Responses" card can never clobber the "Message Templates" card
# or vice versa.
# ================================================================
if echo "$QS" | $BB grep -q "action=bot_templates_get"; then
    . /lmepisowifi/hotspot/notify_templates.sh
    ok_json "{\"templates\":{\
\"cmd_status\":\"$(esc_json "$TPL_CMD_STATUS")\",\
\"cmd_reboot\":\"$(esc_json "$TPL_CMD_REBOOT")\",\
\"cmd_hotspotstats_notinstalled\":\"$(esc_json "$TPL_CMD_HOTSPOTSTATS_NOTINSTALLED")\",\
\"cmd_hotspotstats\":\"$(esc_json "$TPL_CMD_HOTSPOTSTATS")\",\
\"cmd_activeusers_empty\":\"$(esc_json "$TPL_CMD_ACTIVEUSERS_EMPTY")\",\
\"cmd_users_empty\":\"$(esc_json "$TPL_CMD_USERS_EMPTY")\",\
\"cmd_kick_usage\":\"$(esc_json "$TPL_CMD_KICK_USAGE")\",\
\"cmd_kick_ok\":\"$(esc_json "$TPL_CMD_KICK_OK")\",\
\"cmd_kick_none\":\"$(esc_json "$TPL_CMD_KICK_NONE")\",\
\"cmd_addtime_usage\":\"$(esc_json "$TPL_CMD_ADDTIME_USAGE")\",\
\"cmd_addtime_created\":\"$(esc_json "$TPL_CMD_ADDTIME_CREATED")\",\
\"cmd_addtime_ok\":\"$(esc_json "$TPL_CMD_ADDTIME_OK")\",\
\"cmd_removetime_usage\":\"$(esc_json "$TPL_CMD_REMOVETIME_USAGE")\",\
\"cmd_removetime_none\":\"$(esc_json "$TPL_CMD_REMOVETIME_NONE")\",\
\"cmd_removetime_ok\":\"$(esc_json "$TPL_CMD_REMOVETIME_OK")\",\
\"cmd_badmac\":\"$(esc_json "$TPL_CMD_BADMAC")\",\
\"cmd_badminutes\":\"$(esc_json "$TPL_CMD_BADMINUTES")\",\
\"cmd_unknown\":\"$(esc_json "$TPL_CMD_UNKNOWN")\",\
\"cmd_unauthorized\":\"$(esc_json "$TPL_CMD_UNAUTHORIZED")\"\
}}"
fi

# ================================================================
# POST ?action=bot_templates_set  (form-encoded) -> save customized
# router-bot command responses. Any field left blank reverts that
# response to its built-in default (handled by notify_templates.sh at
# render time). Takes effect the next time the bot is (re)started --
# same as any other telegram_bot.env-adjacent change.
# ================================================================
if echo "$QS" | $BB grep -q "action=bot_templates_set"; then
    read -n "$CONTENT_LENGTH" POST_DATA

    fget() {
        printf '%s' "$POST_DATA" \
            | $BB tr '&' '\n' \
            | $BB grep "^$1=" \
            | $BB sed 's/^[^=]*=//' \
            | urldecode \
            | head -1
    }
    # Same sanitizer as notify_templates_set -- strips CR/LF, quotes,
    # backslashes, $ and backticks so a saved value can't break out of the
    # sourced env file or inject shell commands. Still supports multi-line
    # layout via the %0A token.
    san() { printf '%s' "$1" | $BB tr -d '\r\n"\\$\140'; }

    mkdir -p "$HDATA"
    {
        echo "TPL_CMD_STATUS=\"$(san "$(fget cmd_status)")\""
        echo "TPL_CMD_REBOOT=\"$(san "$(fget cmd_reboot)")\""
        echo "TPL_CMD_HOTSPOTSTATS_NOTINSTALLED=\"$(san "$(fget cmd_hotspotstats_notinstalled)")\""
        echo "TPL_CMD_HOTSPOTSTATS=\"$(san "$(fget cmd_hotspotstats)")\""
        echo "TPL_CMD_ACTIVEUSERS_EMPTY=\"$(san "$(fget cmd_activeusers_empty)")\""
        echo "TPL_CMD_USERS_EMPTY=\"$(san "$(fget cmd_users_empty)")\""
        echo "TPL_CMD_KICK_USAGE=\"$(san "$(fget cmd_kick_usage)")\""
        echo "TPL_CMD_KICK_OK=\"$(san "$(fget cmd_kick_ok)")\""
        echo "TPL_CMD_KICK_NONE=\"$(san "$(fget cmd_kick_none)")\""
        echo "TPL_CMD_ADDTIME_USAGE=\"$(san "$(fget cmd_addtime_usage)")\""
        echo "TPL_CMD_ADDTIME_CREATED=\"$(san "$(fget cmd_addtime_created)")\""
        echo "TPL_CMD_ADDTIME_OK=\"$(san "$(fget cmd_addtime_ok)")\""
        echo "TPL_CMD_REMOVETIME_USAGE=\"$(san "$(fget cmd_removetime_usage)")\""
        echo "TPL_CMD_REMOVETIME_NONE=\"$(san "$(fget cmd_removetime_none)")\""
        echo "TPL_CMD_REMOVETIME_OK=\"$(san "$(fget cmd_removetime_ok)")\""
        echo "TPL_CMD_BADMAC=\"$(san "$(fget cmd_badmac)")\""
        echo "TPL_CMD_BADMINUTES=\"$(san "$(fget cmd_badminutes)")\""
        echo "TPL_CMD_UNKNOWN=\"$(san "$(fget cmd_unknown)")\""
        echo "TPL_CMD_UNAUTHORIZED=\"$(san "$(fget cmd_unauthorized)")\""
    } > "$HDATA/bot_templates.env.tmp"
    $BB mv "$HDATA/bot_templates.env.tmp" "$HDATA/bot_templates.env"
    ok_json "{\"ok\":true}"
fi

# ================================================================
# POST ?action=bot_templates_reset  -> restore all router-bot command
# responses to their built-in defaults (deletes the override file)
# ================================================================
if echo "$QS" | $BB grep -q "action=bot_templates_reset"; then
    rm -f "$HDATA/bot_templates.env"
    ok_json "{\"ok\":true}"
fi

# Where the router-bot code lives on this device. Merged into notify.sh
# (run as `notify.sh --bot`) rather than a standalone script — kept as
# one constant used by both actions below, update here if that changes.
TGBOT_SCRIPT="/lmepisowifi/hotspot/notify.sh"
TGBOT_ENV="$HDATA/telegram_bot.env"
TGBOT_STARTUP="/lmepisowifi/www2/sh/startup.sh"

# Write / update a key in telegram_bot.env. Adds the key if absent,
# replaces it if present; creates the file if it doesn't exist yet (e.g.
# the bot has never been started, so notify.sh's own first-run heredoc
# hasn't fired). Same add-or-replace pattern as set_globals_var above,
# just pointed at $TGBOT_ENV.
set_tgbot_var() {
    local var="$1" val="$2"
    local esc
    env_val_safe "$val" || return 1
    mkdir -p "$HDATA" 2>/dev/null
    touch "$TGBOT_ENV" 2>/dev/null
    esc=$(printf '%s' "$val" | $BB sed 's/[\\/&]/\\&/g')
    if $BB grep -q "^${var}=" "$TGBOT_ENV" 2>/dev/null; then
        $BB sed -i "s|^${var}=.*|${var}=\"${esc}\"|" "$TGBOT_ENV"
    else
        printf '%s="%s"\n' "$var" "$val" >> "$TGBOT_ENV"
    fi
}

# Boot-marker plumbing for the router-bot switch, so it survives a
# reboot -- same BEGIN_X/END_X convention www2/sh/startup.sh already uses
# for Tailscale/WAN-repurpose/IP-ACL (see tailscale_ctl.sh's
# add_boot_marker/remove_boot_marker). ota.sh's merge_startup_markers()
# discovers any BEGIN_/END_ pair automatically, so this survives an OTA
# update too without needing to be registered anywhere else.
_tgbot_has_marker() {
    [ -f "$TGBOT_STARTUP" ] && $BB grep -q 'BEGIN_TELEGRAM_BOT' "$TGBOT_STARTUP"
}

_tgbot_set_marker() {
    [ -f "$TGBOT_STARTUP" ] || return 0
    $BB awk -v line="$1" '
        /BEGIN_TELEGRAM_BOT/ { print; if (line != "") print line; inblk = 1; next }
        /END_TELEGRAM_BOT/   { inblk = 0; print; next }
        inblk { next }
        { print }
    ' "$TGBOT_STARTUP" > "$TGBOT_STARTUP.tmp" 2>/dev/null && $BB mv "$TGBOT_STARTUP.tmp" "$TGBOT_STARTUP"
}

add_tgbot_boot_marker() {
    [ -f "$TGBOT_STARTUP" ] || return 0
    if _tgbot_has_marker; then
        _tgbot_set_marker '( /lmepisowifi/hotspot/notify.sh --bot-autostart ) &'
    else
        printf '\n# --- BEGIN_TELEGRAM_BOT ---\n( /lmepisowifi/hotspot/notify.sh --bot-autostart ) &\n# --- END_TELEGRAM_BOT ---\n' >> "$TGBOT_STARTUP"
    fi
}

remove_tgbot_boot_marker() {
    _tgbot_has_marker || return 0
    _tgbot_set_marker ''
}

# Pull the raw "name|description|handler" lines out of CMD_REGISTRY in
# the bot script itself (not hand-duplicated here), so this list can
# never drift from what the bot actually runs.
_tgbot_registry() {
    $BB sed -n '/^CMD_REGISTRY="/,/"[[:space:]]*$/p' "$TGBOT_SCRIPT" \
        | $BB sed '1s/^CMD_REGISTRY="//; $s/"[[:space:]]*$//'
}

# ================================================================
# GET ?action=telegram_cmds_get  -> router-bot command list + enabled
# state. A command's enabled state comes from telegram_bot.env's
# CMD_ENABLED_* flags -- unset/missing defaults to enabled, same
# convention as NOTIFY_EVT_* above, so a config predating a newly
# added command still runs it.
# ================================================================
if echo "$QS" | $BB grep -q "action=telegram_cmds_get"; then
    if [ ! -f "$TGBOT_SCRIPT" ]; then
        ok_json "{\"installed\":false,\"running\":false,\"commands\":[]}"
    fi

    [ -f "$TGBOT_ENV" ] && . "$TGBOT_ENV" 2>/dev/null

    _cmd_en() {
        local key flag
        key=$(echo "$1" | $BB tr 'a-z' 'A-Z' | $BB tr -cd 'A-Z0-9_')
        eval "flag=\"\${CMD_ENABLED_${key}:-1}\""
        [ "$flag" = "0" ] && printf 'false' || printf 'true'
    }

    OUT="" FIRST=1
    while IFS='|' read -r NAME DESC HANDLER; do
        [ -z "$NAME" ] && continue
        if [ "$FIRST" = "1" ]; then FIRST=0; else OUT="${OUT},"; fi
        OUT="${OUT}{\"name\":\"$(esc_json "$NAME")\",\"description\":\"$(esc_json "$DESC")\",\"enabled\":$(_cmd_en "$NAME")}"
    done <<EOF
$(_tgbot_registry)
EOF
    RUNNING="false"; bot_running && RUNNING="true"
    ok_json "{\"installed\":true,\"running\":$RUNNING,\"commands\":[$OUT]}"
fi

# ================================================================
# POST ?action=telegram_bot_toggle   body: enabled=1|0
# Starts/stops the interactive Telegram command-router bot in the
# background (`notify.sh --bot`), tracked via /tmp/telegram_bot.pid —
# same pidfile pattern as hotspot_start/hotspot_stop above. Also persists
# the switch (BOT_AUTOSTART in telegram_bot.env) and adds/removes a boot
# marker in www2/sh/startup.sh that calls `notify.sh --bot-autostart` —
# same mechanism the Tailscale switch uses — so a device that reboots
# with the bot on comes back up with it running instead of needing a
# manual re-toggle.
# ================================================================
if echo "$QS" | $BB grep -q "action=telegram_bot_toggle"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    VAL=$($BB echo "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')

    if [ "$VAL" = "1" ]; then
        [ -f "$TGBOT_SCRIPT" ] || err_json "bot_not_installed"
        set_tgbot_var "BOT_AUTOSTART" "1"
        add_tgbot_boot_marker
        if bot_running; then
            ok_json "{\"ok\":true,\"running\":true,\"msg\":\"already running\"}"
        fi
        "$TGBOT_SCRIPT" --bot >/tmp/telegram_bot_start.log 2>&1 &
        echo $! > /tmp/telegram_bot.pid
        $BB sleep 1
        RUNNING="false"; bot_running && RUNNING="true"
        ok_json "{\"ok\":true,\"running\":$RUNNING}"
    elif [ "$VAL" = "0" ]; then
        set_tgbot_var "BOT_AUTOSTART" "0"
        remove_tgbot_boot_marker
        if [ -f /tmp/telegram_bot.pid ]; then
            kill -9 "$(cat /tmp/telegram_bot.pid)" 2>/dev/null
            rm -f /tmp/telegram_bot.pid
        fi
        ok_json "{\"ok\":true,\"running\":false}"
    else
        err_json "bad_value"
    fi
fi

# ================================================================
# POST ?action=telegram_cmds_set  (form-encoded) -> save which router-
# bot commands are enabled. Expects cmd_enabled_<name>=1|0 per command.
# Only ever writes CMD_ENABLED_* -- the BOT_TOKEN / ALLOWED_USER_IDS
# lines already in telegram_bot.env are read back and re-written
# unchanged, since this page doesn't manage bot credentials.
# ================================================================
if echo "$QS" | $BB grep -q "action=telegram_cmds_set"; then
    [ -f "$TGBOT_SCRIPT" ] || err_json "bot_not_installed"
    read -n "$CONTENT_LENGTH" POST_DATA

    fget() {
        printf '%s' "$POST_DATA" \
            | $BB tr '&' '\n' \
            | $BB grep "^$1=" \
            | $BB sed 's/^[^=]*=//' \
            | urldecode \
            | head -1
    }

    BOT_TOKEN=""; ALLOWED_USER_IDS=""; BOT_AUTOSTART="0"
    [ -f "$TGBOT_ENV" ] && . "$TGBOT_ENV" 2>/dev/null

    mkdir -p "$HDATA"
    {
        echo "BOT_TOKEN=\"$BOT_TOKEN\""
        echo "ALLOWED_USER_IDS=\"$ALLOWED_USER_IDS\""
        echo "BOT_AUTOSTART=\"$BOT_AUTOSTART\""
        while IFS='|' read -r NAME DESC HANDLER; do
            [ -z "$NAME" ] && continue
            KEY=$(echo "$NAME" | $BB tr 'a-z' 'A-Z' | $BB tr -cd 'A-Z0-9_')
            [ -n "$KEY" ] || continue
            case "$(fget "cmd_enabled_${NAME}")" in
                0|false|off|no) VAL=0 ;;
                *) VAL=1 ;;
            esac
            echo "CMD_ENABLED_${KEY}=\"$VAL\""
        done <<EOF
$(_tgbot_registry)
EOF
    } > "$TGBOT_ENV.tmp"
    $BB mv "$TGBOT_ENV.tmp" "$TGBOT_ENV"
    ok_json "{\"ok\":true}"
fi

# ================================================================
# GET ?action=hotspot_stats  -> running state + session count + income
# ================================================================
if echo "$QS" | $BB grep -q "action=hotspot_stats"; then
    _running=false
    hotspot_running && _running=true
    _sessions=0
    if [ -f "$SESSION_DATA" ]; then
        _sessions=$($BB grep -c '.' "$SESSION_DATA" 2>/dev/null)
        [ -n "$_sessions" ] || _sessions=0
    fi
    _income=$(/lmepisowifi/hotspot/income.sh get 2>/dev/null)
    [ -n "$_income" ] || _income='{"daily":0,"monthly":0,"yearly":0,"total":0,"synced":false}'
    ok_json "{\"running\":${_running},\"sessions\":${_sessions},\"income\":${_income}}"
fi

# ================================================================
# GET ?action=portal_disk_space  -> UBIFS size/used/avail/usable bytes
# usable_bytes = avail_bytes − 3 MB reserve (0 when at or below floor)
# ================================================================
if echo "$QS" | $BB grep -q "action=portal_disk_space"; then
    _dfline=$($BB df -k /lmepisowifi 2>/dev/null | $BB awk 'NR==2')
    _dfl=$( echo "$_dfline" | $BB awk '{print $2+0}')
    _dfu=$( echo "$_dfline" | $BB awk '{print $3+0}')
    _dfa=$( echo "$_dfline" | $BB awk '{print $4+0}')
    _sz_b=$(( ${_dfl:-0} * 1024 ))
    _used_b=$(( ${_dfu:-0} * 1024 ))
    _avail_b=$(( ${_dfa:-0} * 1024 ))
    _reserve_b=3145728
    _usable_b=$(( _avail_b - _reserve_b ))
    [ "$_usable_b" -lt 0 ] && _usable_b=0
    ok_json "{\"ok\":true,\"size_bytes\":${_sz_b},\"used_bytes\":${_used_b},\"avail_bytes\":${_avail_b},\"usable_bytes\":${_usable_b},\"reserve_bytes\":${_reserve_b}}"
fi

# ================================================================
# GET ?action=portal_get  -> title, brand, logo, promos[]
# ================================================================
if echo "$QS" | $BB grep -q "action=portal_get"; then
    PCFG="$HDATA/portal.env"
    PORTAL_TITLE="lmepisowifi"; PORTAL_BRAND="beta"; PORTAL_LOGO="/img/favicon.ico"
    PORTAL_FOOTER="Your device is identified by MAC address. Vouchers are single-use."
    [ -f "$PCFG" ] && . "$PCFG" 2>/dev/null
    # Build promos JSON — detect which promo1..5 files exist
    _pj=""
    for _n in 1 2 3 4 5; do
        for _e in jpg jpeg png gif webp; do
            if [ -f "/lmepisowifi/hotspot/img/promo${_n}.${_e}" ]; then
                _pj="${_pj},\"/img/promo${_n}.${_e}\""
                break
            fi
        done
    done
    # Build audio paths — detect bg_music, coin_sound, and insert_bg_music
    _bg=""; _cs=""; _ins_bg=""
    for _e in mp3 ogg wav; do
        if [ -f "/lmepisowifi/hotspot/audio/bg_music.${_e}" ]; then
            _bg="/audio/bg_music.${_e}"; break
        fi
    done
    for _e in mp3 ogg wav; do
        if [ -f "/lmepisowifi/hotspot/audio/coin_sound.${_e}" ]; then
            _cs="/audio/coin_sound.${_e}"; break
        fi
    done
    for _e in mp3 ogg wav; do
        if [ -f "/lmepisowifi/hotspot/audio/insert_bg_music.${_e}" ]; then
            _ins_bg="/audio/insert_bg_music.${_e}"; break
        fi
    done
    ok_json "{\"ok\":true,\"title\":\"$(esc_json "$PORTAL_TITLE")\",\"brand\":\"$(esc_json "$PORTAL_BRAND")\",\"logo\":\"$(esc_json "$PORTAL_LOGO")\",\"promos\":[${_pj#,}],\"bg_music\":\"$(esc_json "$_bg")\",\"coin_sound\":\"$(esc_json "$_cs")\",\"insert_bg_music\":\"$(esc_json "$_ins_bg")\",\"footer\":\"$(esc_json "$PORTAL_FOOTER")\"}"
fi

# ================================================================
# POST ?action=portal_set  body: title=&brand=&reset_logo=0|1
# Writes title/brand to portal.env; optionally resets logo to default
# ================================================================
if echo "$QS" | $BB grep -q "action=portal_set"; then
    read -n "$CONTENT_LENGTH" POST_DATA

    fget() {
        printf '%s' "$POST_DATA" \
            | $BB tr '&' '\n' \
            | $BB grep "^$1=" \
            | $BB sed 's/^[^=]*=//' \
            | urldecode \
            | head -1
    }
    san_txt() { printf '%s' "$1" | $BB tr -d '\r\n\\"\\`$<>|;&'; }

    PCFG="$HDATA/portal.env"
    PORTAL_TITLE="lmepisowifi"; PORTAL_BRAND="beta"; PORTAL_LOGO="/img/favicon.ico"
    PORTAL_FOOTER="Your device is identified by MAC address. Vouchers are single-use."
    [ -f "$PCFG" ] && . "$PCFG" 2>/dev/null

    NEW_TITLE=$(san_txt "$(fget title)" | $BB cut -c1-64)
    NEW_BRAND=$(san_txt "$(fget brand)" | $BB cut -c1-32)
    NEW_FOOTER=$(san_txt "$(fget footer)" | $BB cut -c1-200)
    RESET_LOGO=$(fget reset_logo)
    [ -n "$NEW_TITLE" ] && PORTAL_TITLE="$NEW_TITLE"
    [ -n "$NEW_BRAND" ] && PORTAL_BRAND="$NEW_BRAND"
    # Allow explicitly clearing footer by sending an empty string
    _footer_raw=$(fget footer)
    [ -n "$_footer_raw" ] && PORTAL_FOOTER="$NEW_FOOTER" || PORTAL_FOOTER=""
    [ "$RESET_LOGO" = "1" ] && { PORTAL_LOGO="/img/favicon.ico"; rm -f /lmepisowifi/hotspot/img/portal_logo.* 2>/dev/null; }

    mkdir -p "$HDATA"
    { printf 'PORTAL_TITLE="%s"\n' "$PORTAL_TITLE"
      printf 'PORTAL_BRAND="%s"\n' "$PORTAL_BRAND"
      printf 'PORTAL_LOGO="%s"\n'  "$PORTAL_LOGO"
      printf 'PORTAL_FOOTER="%s"\n' "$PORTAL_FOOTER"; } > "$PCFG.tmp"
    $BB mv "$PCFG.tmp" "$PCFG"
    ok_json "{\"ok\":true}"
fi

# ================================================================
# POST ?action=portal_upload
# body: img_slot=logo|promo1..promo5 & img_ext=jpg|png|... & img_data=<base64>
# logo   -> saves portal_logo.<ext>, updates portal.env PORTAL_LOGO
# promoN -> saves promoN.<ext> (removes old promoN.* first), no portal.env change
# ================================================================
if echo "$QS" | $BB grep -q "action=portal_upload"; then
    read -n "$CONTENT_LENGTH" POST_DATA

    fget() {
        printf '%s' "$POST_DATA" \
            | $BB tr '&' '\n' \
            | $BB grep "^$1=" \
            | $BB sed 's/^[^=]*=//' \
            | urldecode \
            | head -1
    }

    SLOT=$(fget img_slot | $BB tr -cd 'a-z0-9')
    EXT=$( fget img_ext  | $BB tr -cd 'a-z0-9' | $BB cut -c1-5)
    
    # Bypassing the slow character-by-character awk urldecode for the massive base64 payload.
    # Base64 only percent-encodes +, /, and = which we can decode instantly using sed.
    B64=$(printf '%s' "$POST_DATA" \
        | $BB tr '&' '\n' \
        | $BB grep "^img_data=" \
        | $BB sed 's/^img_data=//; s/%2B/+/g; s/%2F/\//g; s/%3D/=/g; s/%2b/+/g; s/%2f/\//g; s/%3d/=/g')

    case "$SLOT" in logo|promo1|promo2|promo3|promo4|promo5) ;; *) err_json "bad_slot" ;; esac
    case "$EXT"  in jpg|jpeg|png|ico|gif|webp) ;; *) err_json "bad_ext" ;; esac
    [ -z "$B64" ] && err_json "no_data"

    case "$SLOT" in
        logo)
            DEST="/lmepisowifi/hotspot/img/portal_logo.${EXT}"
            ;;
        promo*)
            PNUM="${SLOT#promo}"
            # Remove any existing promo with a different extension before saving
            rm -f "/lmepisowifi/hotspot/img/promo${PNUM}".*  2>/dev/null
            DEST="/lmepisowifi/hotspot/img/promo${PNUM}.${EXT}"
            ;;
    esac

    # Disk-space guard: reject before writing if the file would breach the 3 MB floor
    # B64 chars × 3/4 ≈ decoded bytes (slight overestimate — safe to use for comparison)
    _img_avkb=$($BB df -k /lmepisowifi 2>/dev/null | $BB awk 'NR==2 {print $4+0}')
    _img_avail=$(( ${_img_avkb:-0} * 1024 ))
    _img_b64len=$(printf '%s' "$B64" | $BB wc -c | $BB tr -cd '0-9')
    _img_fsize=$(( (${_img_b64len:-0} * 3 + 3) / 4 ))
    [ $(( _img_avail - _img_fsize )) -lt 3145728 ] && err_json "insufficient_space"

    if ! printf '%s' "$B64" | $BB base64 -d > "${DEST}.tmp" 2>/dev/null; then
        printf '%s' "$B64" | openssl enc -d -base64 -A > "${DEST}.tmp" 2>/dev/null \
            || { rm -f "${DEST}.tmp"; err_json "decode_failed"; }
    fi
    $BB mv "${DEST}.tmp" "$DEST"

    # Only logo upload needs portal.env update
    if [ "$SLOT" = "logo" ]; then
        IMG_PATH="/img/portal_logo.${EXT}"
        PCFG="$HDATA/portal.env"
        PORTAL_TITLE="lmepisowifi"; PORTAL_BRAND="beta"; PORTAL_LOGO="/img/favicon.ico"
        [ -f "$PCFG" ] && . "$PCFG" 2>/dev/null
        PORTAL_LOGO="$IMG_PATH"
        mkdir -p "$HDATA"
        { printf 'PORTAL_TITLE="%s"\n' "$PORTAL_TITLE"
          printf 'PORTAL_BRAND="%s"\n' "$PORTAL_BRAND"
          printf 'PORTAL_LOGO="%s"\n'  "$PORTAL_LOGO"; } > "$PCFG.tmp"
        $BB mv "$PCFG.tmp" "$PCFG"
        ok_json "{\"ok\":true,\"path\":\"$(esc_json "$IMG_PATH")\"}"
    else
        IMG_PATH="/img/promo${PNUM}.${EXT}"
        ok_json "{\"ok\":true,\"path\":\"$(esc_json "$IMG_PATH")\"}"
    fi
fi

# ================================================================
# POST ?action=portal_clear_promo  body: promo_slot=promo1..promo5
# Removes the promo image file(s) for the given slot
# ================================================================
if echo "$QS" | $BB grep -q "action=portal_clear_promo"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    fget() {
        printf '%s' "$POST_DATA" \
            | $BB tr '&' '\n' \
            | $BB grep "^$1=" \
            | $BB sed 's/^[^=]*=//' \
            | urldecode \
            | head -1
    }
    SLOT=$(fget promo_slot | $BB tr -cd 'a-z0-9')
    case "$SLOT" in promo1|promo2|promo3|promo4|promo5) ;; *) err_json "bad_slot" ;; esac
    PNUM="${SLOT#promo}"
    rm -f "/lmepisowifi/hotspot/img/promo${PNUM}".* 2>/dev/null
    ok_json "{\"ok\":true}"
fi

# ================================================================
# POST ?action=portal_audio_upload
# body: audio_slot=bg_music|coin_sound & audio_ext=mp3|ogg|wav & audio_data=<base64>
# Saves audio to /lmepisowifi/hotspot/audio/<slot>.<ext>
# ================================================================
if echo "$QS" | $BB grep -q "action=portal_audio_upload"; then
    read -n "$CONTENT_LENGTH" POST_DATA

    fget() {
        printf '%s' "$POST_DATA" \
            | $BB tr '&' '\n' \
            | $BB grep "^$1=" \
            | $BB sed 's/^[^=]*=//' \
            | urldecode \
            | head -1
    }

    SLOT=$(fget audio_slot | $BB tr -cd 'a-z_')
    EXT=$( fget audio_ext  | $BB tr -cd 'a-z0-9' | $BB cut -c1-4)

    # Base64: only +, /, = and = need re-encoding
    B64=$(printf '%s' "$POST_DATA" \
        | $BB tr '&' '\n' \
        | $BB grep "^audio_data=" \
        | $BB sed 's/^audio_data=//; s/%2B/+/g; s/%2F/\//g; s/%3D/=/g; s/%2b/+/g; s/%2f/\//g; s/%3d/=/g')

    case "$SLOT" in bg_music|coin_sound|insert_bg_music) ;; *) err_json "bad_slot" ;; esac
    case "$EXT"  in mp3|ogg|wav)         ;; *) err_json "bad_ext"  ;; esac
    [ -z "$B64" ] && err_json "no_data"

    mkdir -p /lmepisowifi/hotspot/audio
    # Remove any existing file for this slot (different extension)
    rm -f "/lmepisowifi/hotspot/audio/${SLOT}".* 2>/dev/null
    DEST="/lmepisowifi/hotspot/audio/${SLOT}.${EXT}"

    # Disk-space guard: reject before writing if the file would breach the 3 MB floor
    _aud_avkb=$($BB df -k /lmepisowifi 2>/dev/null | $BB awk 'NR==2 {print $4+0}')
    _aud_avail=$(( ${_aud_avkb:-0} * 1024 ))
    _aud_b64len=$(printf '%s' "$B64" | $BB wc -c | $BB tr -cd '0-9')
    _aud_fsize=$(( (${_aud_b64len:-0} * 3 + 3) / 4 ))
    [ $(( _aud_avail - _aud_fsize )) -lt 3145728 ] && err_json "insufficient_space"

    if ! printf '%s' "$B64" | $BB base64 -d > "${DEST}.tmp" 2>/dev/null; then
        printf '%s' "$B64" | openssl enc -d -base64 -A > "${DEST}.tmp" 2>/dev/null \
            || { rm -f "${DEST}.tmp"; err_json "decode_failed"; }
    fi
    $BB mv "${DEST}.tmp" "$DEST"

    ok_json "{\"ok\":true,\"path\":\"/audio/${SLOT}.${EXT}\"}"
fi

# ================================================================
# POST ?action=portal_audio_clear  body: audio_slot=bg_music|coin_sound
# Removes the audio file for the given slot
# ================================================================
if echo "$QS" | $BB grep -q "action=portal_audio_clear"; then
    read -n "$CONTENT_LENGTH" POST_DATA
    fget() {
        printf '%s' "$POST_DATA" \
            | $BB tr '&' '\n' \
            | $BB grep "^$1=" \
            | $BB sed 's/^[^=]*=//' \
            | urldecode \
            | head -1
    }
    SLOT=$(fget audio_slot | $BB tr -cd 'a-z_')
    case "$SLOT" in bg_music|coin_sound|insert_bg_music) ;; *) err_json "bad_slot" ;; esac
    rm -f "/lmepisowifi/hotspot/audio/${SLOT}".* 2>/dev/null
    ok_json "{\"ok\":true}"
fi

# ================================================================
# POST ?action=anti_tether_set   body: enabled=1|0
# Enables or disables anti-tethering (TTL-based blocking of shared
# sessions).  The iptables chain is managed directly so the change
# takes effect immediately without a hotspot restart.
# ================================================================
if echo "$QS" | $BB grep -q "action=anti_tether_set"; then
    read -n "${CONTENT_LENGTH:-0}" POST_DATA
    VAL=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')
    HBR="${HOTSPOT_BR:-$(read_lmehspt_var HOTSPOT_BR)}"
    HBR="${HBR:-br1}"
    AT_CHAIN="HOTSPOT_AT"
    if [ "$VAL" = "1" ]; then
        # Build/refresh the chain
        iptables -t mangle -N "$AT_CHAIN" 2>/dev/null
        iptables -t mangle -F "$AT_CHAIN" 2>/dev/null
        # Try xt_ttl; fall back to u32 matching of TTL byte (offset 0x8, top byte)
        iptables -t mangle -A "$AT_CHAIN" -m ttl --ttl-lt 64 -j DROP 2>/dev/null || \
            iptables -t mangle -A "$AT_CHAIN" -m u32 --u32 "0x8 >> 24 & 0xFF = 0:63" -j DROP 2>/dev/null
        iptables -t mangle -D FORWARD -i "$HBR" -j "$AT_CHAIN" 2>/dev/null
        iptables -t mangle -I FORWARD 1 -i "$HBR" -j "$AT_CHAIN" 2>/dev/null
        save_coin_env_var "ANTI_TETHER" "1"
        set_lmehspt_var   "ANTI_TETHER" "1"
        ok_json "{\"ok\":true,\"anti_tether\":true}"
    else
        # Tear down the chain
        iptables -t mangle -D FORWARD -i "$HBR" -j "$AT_CHAIN" 2>/dev/null
        iptables -t mangle -F "$AT_CHAIN" 2>/dev/null
        iptables -t mangle -X "$AT_CHAIN" 2>/dev/null
        save_coin_env_var "ANTI_TETHER" "0"
        set_lmehspt_var   "ANTI_TETHER" "0"
        ok_json "{\"ok\":true,\"anti_tether\":false}"
    fi
fi

# ================================================================
# Custom portal CSS
#
# hotspot/index.html loads the operator's CSS from /cgi-bin/portal_css.sh as
# its OWN stylesheet, after the built-in styles. Because it is a separate
# stylesheet, a syntax error in it can only ever hurt the custom rules
# themselves, never the stock look. It lives in hotspot_data/ (not hotspot/)
# so OTA / module reinstalls, which re-lay hotspot/, leave it alone.
#
#   GET  ?action=portal_css_info            -> {ok,has_css,enabled,has_prev,bytes,max_bytes}
#   GET  ?action=portal_css_get             -> the saved CSS (text/plain)
#   POST ?action=portal_css_save    body: css_b64=<base64>&css_len=<bytes>
#                                           validate -> back up old -> save
#   POST ?action=portal_css_draft   body: css_b64=<base64>&css_len=<bytes>
#                                           validate -> stage in RAM for the
#                                           admin live preview only
#   POST ?action=portal_css_enable  body: enabled=1|0   (keeps the file)
#   POST ?action=portal_css_revert          swap saved <-> previous (undoable)
#   POST ?action=portal_css_reset           stock look; old CSS kept as previous
# ================================================================
PCSS_FILE="$HDATA/portal_custom.css"
PCSS_PREV="$HDATA/portal_custom.css.prev"
PCSS_OFF="$HDATA/portal_custom.off"
PCSS_DRAFT="/tmp/portal_css_draft.css"
PCSS_MAX=24576

# portal_css_validate FILE
# Prints one "line N: problem" per issue (at most 6) and returns 1 when the CSS
# must be rejected; prints nothing and returns 0 when it is fine.
#
# This is about accidents, not hostile admins: the portal is a walled garden,
# so the realistic ways to wreck it are a pasted `@import url(https://fonts...)`
# (blocks rendering until it times out), an external background image, or an
# unclosed brace that silently swallows every rule after it. Comments and
# string contents are skipped, so none of those can hide in (or be tripped by)
# them.
portal_css_validate() {
    _pv_f="$1"
    _pv_sz=$($BB wc -c < "$_pv_f" 2>/dev/null | $BB tr -cd '0-9')
    [ -n "$_pv_sz" ] || { echo "could not read the CSS"; return 1; }
    if [ "$_pv_sz" -gt "$PCSS_MAX" ]; then
        echo "CSS is ${_pv_sz} bytes; the limit is ${PCSS_MAX}"
        return 1
    fi
    # Control characters other than TAB/LF/CR (NUL, ESC...) never belong here
    _pv_clean=$($BB tr -d '\000-\010\013\014\016-\037' < "$_pv_f" 2>/dev/null | $BB wc -c | $BB tr -cd '0-9')
    if [ "$_pv_clean" != "$_pv_sz" ]; then
        echo "CSS contains control characters"
        return 1
    fi
    _pv_out=$($BB awk '
    function err(n, m) {
        if (ne < 6) { ne++; msgs[ne] = "line " n ": " m }
    }
    BEGIN { incom = 0; q = ""; depth = 0; ne = 0; sq = "\047" }
    {
        line = $0; n = length(line); code = ""; plain = ""; i = 1
        while (i <= n) {
            c = substr(line, i, 1)
            if (incom) {
                if (c == "*" && substr(line, i + 1, 1) == "/") { incom = 0; i += 2 } else i++
                continue
            }
            if (q != "") {
                plain = plain c
                if (c == "\\") { plain = plain substr(line, i + 1, 1); i += 2; continue }
                if (c == q) { q = ""; code = code c }
                i++
                continue
            }
            if (c == "/" && substr(line, i + 1, 1) == "*") { incom = 1; comstart = NR; i += 2; continue }
            if (c == "\"" || c == sq) { q = c; code = code c; plain = plain c; i++; continue }
            code = code c; plain = plain c; i++
        }
        q = ""    # CSS strings cannot run past the end of a line

        # --- braces (on code only: comments and string contents removed)
        for (i = 1; i <= length(code); i++) {
            c = substr(code, i, 1)
            if (c == "{") depth++
            else if (c == "}") {
                depth--
                if (depth < 0) { err(NR, "unexpected closing brace (no matching opening brace)"); depth = 0 }
            }
        }

        # --- things that fetch from, or script against, the outside world
        lc = tolower(code)
        if (index(lc, "@import"))
            err(NR, "@import is not allowed (a blocked or slow external file stalls the whole portal); paste the rules in directly")
        if (match(lc, /@[ \t]*\\/))
            err(NR, "escaped at-rules are not allowed")
        if (index(lc, "image-set("))
            err(NR, "image-set() is not allowed; use url(/img/...)")
        if (index(lc, "expression(") || index(lc, "javascript:") || index(lc, "vbscript:") || index(lc, "behavior:") || index(lc, "-moz-binding"))
            err(NR, "script-capable CSS is not allowed")

        # --- url(): only the portal own /img/ and /graphics/ files, or inline data: URIs
        pl = tolower(plain); pos = 1
        while ((k = index(substr(pl, pos), "url(")) > 0) {
            s = pos + k + 3
            rest = substr(plain, s)
            sub(/^[ \t]+/, "", rest)
            f = substr(rest, 1, 1)
            if (f == "\"" || f == sq) {
                rest = substr(rest, 2); e = index(rest, f)
                arg = (e > 0) ? substr(rest, 1, e - 1) : rest
            } else {
                e = index(rest, ")")
                arg = (e > 0) ? substr(rest, 1, e - 1) : rest
                sub(/[ \t]+$/, "", arg)
            }
            la = tolower(arg); ok = 0
            if (substr(la, 1, 5) == "/img/" || substr(la, 1, 10) == "/graphics/") ok = 1
            else if (substr(la, 1, 11) == "data:image/") ok = 1
            else if (substr(la, 1, 5) == "data:" && index(la, "font")) ok = 1
            else if (substr(la, 1, 1) == "#") ok = 1
            if (!ok) {
                shown = substr(arg, 1, 40); gsub(/["\\]/, "", shown)
                err(NR, "url(" shown ") is not allowed; use a file under /img/ or /graphics/ (e.g. /img/promo1.png) or an inline data:image URI")
            }
            pos = s
        }
    }
    END {
        if (incom) err(comstart, "comment is never closed (missing */)")
        if (depth > 0) err(NR, depth " opening brace(s) never closed")
        for (i = 1; i <= ne; i++) print msgs[i]
    }' "$_pv_f" 2>/dev/null)
    if [ -n "$_pv_out" ]; then
        printf '%s\n' "$_pv_out"
        return 1
    fi
    return 0
}

# Same JSON-array-body formatter for validator output lines
_pcss_details_json() {
    printf '%s\n' "$1" | $BB awk 'BEGIN{ORS=""} { gsub(/\\/, "\\\\"); gsub(/"/, "\\\""); printf "%s\"%s\"", (NR>1 ? "," : ""), $0 }'
}

# Decodes POST css_b64 into $1 (a RAM temp file), cross-checks the byte count
# against the client-sent css_len (a transfer cut short by the body-size clamp
# would otherwise decode to a *valid-looking but truncated* stylesheet), then
# validates it. Calls err_json (and exits) on any problem.
_pcss_read_post() {
    _pr_out="$1"; _pr_allow_empty="$2"
    read -n "$CONTENT_LENGTH" POST_DATA
    _pr_b64=$(printf '%s' "$POST_DATA" \
        | $BB tr '&' '\n' \
        | $BB grep "^css_b64=" \
        | $BB sed 's/^css_b64=//; s/%2B/+/g; s/%2F/\//g; s/%3D/=/g; s/%2b/+/g; s/%2f/\//g; s/%3d/=/g' \
        | head -1)
    _pr_len=$(printf '%s' "$POST_DATA" | $BB tr '&' '\n' | $BB grep "^css_len=" | $BB sed 's/^css_len=//' | $BB tr -cd '0-9' | head -1)
    if [ -z "$_pr_b64" ]; then
        if [ "$_pr_allow_empty" = "1" ] && [ "${_pr_len:-x}" = "0" ]; then
            : > "$_pr_out"
            return 0
        fi
        err_json "no_data"
    fi
    if ! printf '%s' "$_pr_b64" | $BB base64 -d > "$_pr_out" 2>/dev/null; then
        printf '%s' "$_pr_b64" | openssl enc -d -base64 -A > "$_pr_out" 2>/dev/null \
            || { rm -f "$_pr_out"; err_json "decode_failed"; }
    fi
    _pr_got=$($BB wc -c < "$_pr_out" 2>/dev/null | $BB tr -cd '0-9')
    if [ -z "$_pr_len" ] || [ "$_pr_got" != "$_pr_len" ]; then
        rm -f "$_pr_out"
        err_json "size_mismatch"
    fi
    $BB tr -d '\r' < "$_pr_out" > "$_pr_out.n" 2>/dev/null && $BB mv -f "$_pr_out.n" "$_pr_out"
    _pr_det=$(portal_css_validate "$_pr_out") || {
        rm -f "$_pr_out"
        ok_json "{\"ok\":false,\"error\":\"invalid_css\",\"details\":[$(_pcss_details_json "$_pr_det")]}"
    }
    # Whitespace-only CSS is not CSS (use reset to go back to the stock look)
    if [ "$_pr_allow_empty" != "1" ] && [ -z "$($BB tr -d ' \t\n' < "$_pr_out" 2>/dev/null)" ]; then
        rm -f "$_pr_out"
        err_json "empty_css"
    fi
    return 0
}

case "$QS" in
*action=portal_css_info*)
    _pc_has=0; _pc_en=1; _pc_prev=0; _pc_bytes=0
    [ -f "$PCSS_FILE" ] && { _pc_has=1; _pc_bytes=$($BB wc -c < "$PCSS_FILE" 2>/dev/null | $BB tr -cd '0-9'); }
    [ -e "$PCSS_OFF" ]  && _pc_en=0
    [ -f "$PCSS_PREV" ] && _pc_prev=1
    ok_json "{\"ok\":true,\"has_css\":${_pc_has},\"enabled\":${_pc_en},\"has_prev\":${_pc_prev},\"bytes\":${_pc_bytes:-0},\"max_bytes\":${PCSS_MAX}}"
    ;;

*action=portal_css_get*)
    printf "Status: 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nCache-Control: no-store\r\n\r\n"
    [ -f "$PCSS_FILE" ] && $BB cat "$PCSS_FILE" 2>/dev/null
    exit 0
    ;;

*action=portal_css_draft*)
    _pc_in="/tmp/portal_css_in.$$"
    _pcss_read_post "$_pc_in" 1
    $BB mv -f "$_pc_in" "$PCSS_DRAFT" 2>/dev/null || { rm -f "$_pc_in"; err_json "write_failed"; }
    ok_json "{\"ok\":true}"
    ;;

*action=portal_css_save*)
    _pc_in="/tmp/portal_css_in.$$"
    _pcss_read_post "$_pc_in" 0
    _pc_sz=$($BB wc -c < "$_pc_in" 2>/dev/null | $BB tr -cd '0-9')

    mkdir -p "$HDATA"
    # Disk-space guard: same 3 MB floor as the image/audio uploads. Needs room
    # for the new file AND the copy kept as "previous".
    _pc_avkb=$($BB df -k /lmepisowifi 2>/dev/null | $BB awk 'NR==2 {print $4+0}')
    _pc_avail=$(( ${_pc_avkb:-0} * 1024 ))
    if [ $(( _pc_avail - _pc_sz * 2 )) -lt 3145728 ]; then
        rm -f "$_pc_in"; err_json "insufficient_space"
    fi

    # Write beside the target, then verify it is complete BEFORE it can replace
    # anything (a write that hit ENOSPC mid-way must never be promoted).
    $BB cp -f "$_pc_in" "$PCSS_FILE.tmp" 2>/dev/null
    _pc_wsz=$($BB wc -c < "$PCSS_FILE.tmp" 2>/dev/null | $BB tr -cd '0-9')
    if [ "$_pc_wsz" != "$_pc_sz" ]; then
        rm -f "$_pc_in" "$PCSS_FILE.tmp"; err_json "write_incomplete"
    fi
    rm -f "$_pc_in"

    # Keep the version being replaced (only when it actually differs) so
    # "Undo" has something to go back to.
    if [ -f "$PCSS_FILE" ] && [ "$($BB cat "$PCSS_FILE" 2>/dev/null)" != "$($BB cat "$PCSS_FILE.tmp" 2>/dev/null)" ]; then
        $BB cp -f "$PCSS_FILE" "$PCSS_PREV.tmp" 2>/dev/null
        if [ "$($BB wc -c < "$PCSS_PREV.tmp" 2>/dev/null | $BB tr -cd '0-9')" = "$($BB wc -c < "$PCSS_FILE" 2>/dev/null | $BB tr -cd '0-9')" ]; then
            $BB mv -f "$PCSS_PREV.tmp" "$PCSS_PREV"
        else
            rm -f "$PCSS_PREV.tmp"
        fi
    fi
    $BB mv -f "$PCSS_FILE.tmp" "$PCSS_FILE" 2>/dev/null || { rm -f "$PCSS_FILE.tmp"; err_json "write_failed"; }
    rm -f "$PCSS_OFF" "$PCSS_DRAFT" 2>/dev/null     # saving switches it on and retires the draft
    ok_json "{\"ok\":true,\"bytes\":${_pc_sz}}"
    ;;

*action=portal_css_enable*)
    read -n "${CONTENT_LENGTH:-0}" POST_DATA
    _pc_val=$(printf '%s' "$POST_DATA" | $BB sed -n 's/.*enabled=\([^&]*\).*/\1/p')
    if [ "$_pc_val" = "1" ]; then
        rm -f "$PCSS_OFF" 2>/dev/null
    else
        mkdir -p "$HDATA"
        : > "$PCSS_OFF" 2>/dev/null || err_json "write_failed"
    fi
    ok_json "{\"ok\":true,\"enabled\":$([ "$_pc_val" = "1" ] && echo 1 || echo 0)}"
    ;;

*action=portal_css_revert*)
    [ -f "$PCSS_PREV" ] || err_json "no_previous"
    # 3-way swap so Undo is itself undoable. If power dies mid-swap the worst
    # case is no portal_custom.css at all (= stock look); .prev/.swap survive.
    [ -f "$PCSS_FILE" ] && $BB mv -f "$PCSS_FILE" "$PCSS_FILE.swap"
    $BB mv -f "$PCSS_PREV" "$PCSS_FILE" 2>/dev/null || err_json "write_failed"
    [ -f "$PCSS_FILE.swap" ] && $BB mv -f "$PCSS_FILE.swap" "$PCSS_PREV"
    rm -f "$PCSS_OFF" 2>/dev/null
    ok_json "{\"ok\":true}"
    ;;

*action=portal_css_reset*)
    # Back to the stock look. The CSS is moved to "previous", not deleted, so
    # a misclick on Reset is one Undo away from being fixed.
    [ -f "$PCSS_FILE" ] && $BB mv -f "$PCSS_FILE" "$PCSS_PREV" 2>/dev/null
    rm -f "$PCSS_OFF" "$PCSS_DRAFT" 2>/dev/null
    ok_json "{\"ok\":true}"
    ;;
esac

# ================================================================
# Fallback
# ================================================================
printf "Status: 400 Bad Request\r\nContent-Type: application/json\r\n\r\n{\"ok\":false,\"error\":\"unknown_action\"}"
